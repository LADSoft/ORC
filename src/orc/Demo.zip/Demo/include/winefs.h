/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#ifndef __WINEFS_H__
#define __WINEFS_H__

#pragma once

typedef struct _CERTIFICATE_BLOB {
    DWORD   dwCertEncodingType;
    DWORD   cbData;
    PBYTE    pbData;

} EFS_CERTIFICATE_BLOB, *PEFS_CERTIFICATE_BLOB;

typedef struct _EFS_HASH_BLOB {

    DWORD   cbData;
    PBYTE    pbData;
} EFS_HASH_BLOB, *PEFS_HASH_BLOB;

typedef struct _ENCRYPTION_CERTIFICATE {
    DWORD cbTotalLength;
    SID * pUserSid;
    PEFS_CERTIFICATE_BLOB pCertBlob;
} ENCRYPTION_CERTIFICATE, *PENCRYPTION_CERTIFICATE;

#define MAX_SID_SIZE 256

typedef struct _ENCRYPTION_CERTIFICATE_HASH {
    DWORD cbTotalLength;
    SID * pUserSid;
    PEFS_HASH_BLOB  pHash;
    LPWSTR lpDisplayInformation;
} ENCRYPTION_CERTIFICATE_HASH, *PENCRYPTION_CERTIFICATE_HASH;

typedef struct _ENCRYPTION_CERTIFICATE_HASH_LIST {
    DWORD nCert_Hash;
    PENCRYPTION_CERTIFICATE_HASH * pUsers;
} ENCRYPTION_CERTIFICATE_HASH_LIST, *PENCRYPTION_CERTIFICATE_HASH_LIST;

typedef struct _ENCRYPTION_CERTIFICATE_LIST {
    DWORD nUsers;
    PENCRYPTION_CERTIFICATE * pUsers;
} ENCRYPTION_CERTIFICATE_LIST, *PENCRYPTION_CERTIFICATE_LIST;

WINADVAPI
DWORD
WINAPI
QueryUsersOnEncryptedFile(
     LPCWSTR lpFileName,
     PENCRYPTION_CERTIFICATE_HASH_LIST * pUsers
    );

WINADVAPI
DWORD
WINAPI
QueryRecoveryAgentsOnEncryptedFile(
     LPCWSTR lpFileName,
     PENCRYPTION_CERTIFICATE_HASH_LIST * pRecoveryAgents
    );

WINADVAPI
DWORD
WINAPI
RemoveUsersFromEncryptedFile(
     LPCWSTR lpFileName,
     PENCRYPTION_CERTIFICATE_HASH_LIST pHashes
    );

WINADVAPI
DWORD
WINAPI
AddUsersToEncryptedFile(
     LPCWSTR lpFileName,
     PENCRYPTION_CERTIFICATE_LIST pUsers
    );

WINADVAPI
DWORD
WINAPI
SetUserFileEncryptionKey(
    PENCRYPTION_CERTIFICATE pEncryptionCertificate
    );

WINADVAPI
VOID
WINAPI
FreeEncryptionCertificateHashList(
    PENCRYPTION_CERTIFICATE_HASH_LIST pHashes
    );

WINADVAPI
BOOL
WINAPI
EncryptionDisable(
    LPCWSTR DirPath,
    BOOL Disable
    );

#endif // __WINEFS_H__

