/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#pragma once

#ifndef _INC_STRING
#define _INC_STRING

#if !defined(_WIN32)
#error ERROR: Only Win32 target supported!
#endif

#ifndef _CRTIMP
#ifdef  _DLL
#define _CRTIMP __declspec(dllimport)
#else   /* ndef _DLL */
#define _CRTIMP
#endif  /* _DLL */
#endif  /* _CRTIMP */

#if !defined(__cdecl)
#define __cdecl
#endif

#ifndef _SIZE_T_DEFINED
typedef _W64 unsigned int   size_t;
#define _SIZE_T_DEFINED
#endif

#ifndef _WCHAR_T_DEFINED
typedef unsigned short wchar_t;
#define _WCHAR_T_DEFINED
#endif

#ifndef _NLSCMP_DEFINED
#define _NLSCMPERROR    2147483647
#define _NLSCMP_DEFINED
#endif

#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef _MEMCPY_INLINE_
void *  __cdecl memcpy(void *, const void *, size_t);
#endif
int     __cdecl memcmp(const void *, const void *, size_t);
void *  __cdecl memset(void *, int, size_t);
char *  __cdecl _strset(char *, int);
char *  __cdecl strcpy(char *, const char *);
char *  __cdecl strcat(char *, const char *);
int     __cdecl strcmp(const char *, const char *);
size_t  __cdecl strlen(const char *);
_CRTIMP void *  __cdecl _memccpy(void *, const void *, int, size_t);
_CRTIMP void *  __cdecl memchr(const void *, int, size_t);
_CRTIMP int     __cdecl _memicmp(const void *, const void *, size_t);
_CRTIMP void *  __cdecl memmove(void *, const void *, size_t);
_CRTIMP char *  __cdecl strchr(const char *, int);
_CRTIMP int     __cdecl _strcmpi(const char *, const char *);
_CRTIMP int     __cdecl _stricmp(const char *, const char *);
_CRTIMP int     __cdecl strcoll(const char *, const char *);
_CRTIMP int     __cdecl _stricoll(const char *, const char *);
_CRTIMP int     __cdecl _strncoll(const char *, const char *, size_t);
_CRTIMP int     __cdecl _strnicoll(const char *, const char *, size_t);
_CRTIMP size_t  __cdecl strcspn(const char *, const char *);
_CRTIMP char *  __cdecl _strdup(const char *);
_CRTIMP char *  __cdecl _strerror(const char *);
_CRTIMP char *  __cdecl strerror(int);
_CRTIMP char *  __cdecl _strlwr(char *);
_CRTIMP char *  __cdecl strncat(char *, const char *, size_t);
_CRTIMP int     __cdecl strncmp(const char *, const char *, size_t);
_CRTIMP int     __cdecl _strnicmp(const char *, const char *, size_t);
_CRTIMP char *  __cdecl strncpy(char *, const char *, size_t);
_CRTIMP char *  __cdecl _strnset(char *, int, size_t);
_CRTIMP char *  __cdecl strpbrk(const char *, const char *);
_CRTIMP char *  __cdecl strrchr(const char *, int);
_CRTIMP char *  __cdecl _strrev(char *);
_CRTIMP size_t  __cdecl strspn(const char *, const char *);
_CRTIMP char *  __cdecl strstr(const char *, const char *);
_CRTIMP char *  __cdecl strtok(char *, const char *);
_CRTIMP char *  __cdecl _strupr(char *);
_CRTIMP size_t  __cdecl strxfrm (char *, const char *, size_t);

#if     !__STDC__

_CRTIMP void * __cdecl memccpy(void *, const void *, int, size_t);
_CRTIMP int __cdecl memicmp(const void *, const void *, size_t);
_CRTIMP int __cdecl strcmpi(const char *, const char *);
_CRTIMP int __cdecl stricmp(const char *, const char *);
_CRTIMP char * __cdecl strdup(const char *);
_CRTIMP char * __cdecl strlwr(char *);
_CRTIMP int __cdecl strnicmp(const char *, const char *, size_t);
_CRTIMP char * __cdecl strnset(char *, int, size_t);
_CRTIMP char * __cdecl strrev(char *);
        char * __cdecl strset(char *, int);
_CRTIMP char * __cdecl strupr(char *);

#endif  /* !__STDC__ */

#ifndef _WSTRING_DEFINED

_CRTIMP wchar_t * __cdecl wcscat(wchar_t *, const wchar_t *);
_CRTIMP wchar_t * __cdecl wcschr(const wchar_t *, wchar_t);
_CRTIMP int __cdecl wcscmp(const wchar_t *, const wchar_t *);
_CRTIMP wchar_t * __cdecl wcscpy(wchar_t *, const wchar_t *);
_CRTIMP size_t __cdecl wcscspn(const wchar_t *, const wchar_t *);
_CRTIMP size_t __cdecl wcslen(const wchar_t *);
_CRTIMP wchar_t * __cdecl wcsncat(wchar_t *, const wchar_t *, size_t);
_CRTIMP int __cdecl wcsncmp(const wchar_t *, const wchar_t *, size_t);
_CRTIMP wchar_t * __cdecl wcsncpy(wchar_t *, const wchar_t *, size_t);
_CRTIMP wchar_t * __cdecl wcspbrk(const wchar_t *, const wchar_t *);
_CRTIMP wchar_t * __cdecl wcsrchr(const wchar_t *, wchar_t);
_CRTIMP size_t __cdecl wcsspn(const wchar_t *, const wchar_t *);
_CRTIMP wchar_t * __cdecl wcsstr(const wchar_t *, const wchar_t *);
_CRTIMP wchar_t * __cdecl wcstok(wchar_t *, const wchar_t *);
_CRTIMP wchar_t * __cdecl _wcserror(int);
_CRTIMP wchar_t * __cdecl __wcserror(const wchar_t *);
_CRTIMP wchar_t * __cdecl _wcsdup(const wchar_t *);
_CRTIMP int __cdecl _wcsicmp(const wchar_t *, const wchar_t *);
_CRTIMP int __cdecl _wcsnicmp(const wchar_t *, const wchar_t *, size_t);
_CRTIMP wchar_t * __cdecl _wcsnset(wchar_t *, wchar_t, size_t);
_CRTIMP wchar_t * __cdecl _wcsrev(wchar_t *);
_CRTIMP wchar_t * __cdecl _wcsset(wchar_t *, wchar_t);
_CRTIMP wchar_t * __cdecl _wcslwr(wchar_t *);
_CRTIMP wchar_t * __cdecl _wcsupr(wchar_t *);
_CRTIMP size_t __cdecl wcsxfrm(wchar_t *, const wchar_t *, size_t);
_CRTIMP int __cdecl wcscoll(const wchar_t *, const wchar_t *);
_CRTIMP int __cdecl _wcsicoll(const wchar_t *, const wchar_t *);
_CRTIMP int __cdecl _wcsncoll(const wchar_t *, const wchar_t *, size_t);
_CRTIMP int __cdecl _wcsnicoll(const wchar_t *, const wchar_t *, size_t);

#if     !__STDC__
// old names
#define wcswcs wcsstr

_CRTIMP wchar_t * __cdecl wcsdup(const wchar_t *);
_CRTIMP int __cdecl wcsicmp(const wchar_t *, const wchar_t *);
_CRTIMP int __cdecl wcsnicmp(const wchar_t *, const wchar_t *, size_t);
_CRTIMP wchar_t * __cdecl wcsnset(wchar_t *, wchar_t, size_t);
_CRTIMP wchar_t * __cdecl wcsrev(wchar_t *);
_CRTIMP wchar_t * __cdecl wcsset(wchar_t *, wchar_t);
_CRTIMP wchar_t * __cdecl wcslwr(wchar_t *);
_CRTIMP wchar_t * __cdecl wcsupr(wchar_t *);
_CRTIMP int __cdecl wcsicoll(const wchar_t *, const wchar_t *);

#endif  /* !__STDC__ */

#define _WSTRING_DEFINED
#endif

#if _DBG_MEMCPY_INLINE_ && !defined(_MEMCPY_INLINE_) && !defined(_CRTBLD)
#define _MEMCPY_INLINE_
__forceinline
void *
__cdecl 
memcpy_inline (
    void *dst,
    const void *src,
    size_t size
    )
{
 
    if (((char *)dst > (char *)src) &&
        ((char *)dst < ((char *)src + size))) {
        __debugbreak();
    }
    return memcpy(dst, src, size);
}
#define memcpy memcpy_inline
#endif

#ifdef  _UNICODE


#else
#define _TEOF       EOF

#define _T(x)		x
#define __T(x)      x


/* Program */

#define _tmain      main
#define _tWinMain   WinMain
#define _tenviron  _environ
#define __targv     __argv

/* Formatted i/o */

#define _tprintf    printf
#define _tcprintf   _cprintf
#define _ftprintf   fprintf
#define _stprintf   sprintf
#define _sctprintf  _scprintf
#define _sntprintf  _snprintf
#define _vtprintf   vprintf
#define _vftprintf  vfprintf
#define _vstprintf  vsprintf
#define _vsctprintf _vscprintf
#define _vsntprintf _vsnprintf
#define _tscanf     scanf
#define _tcscanf    _cscanf
#define _ftscanf    fscanf
#define _stscanf    sscanf
#define _sntscanf   _snscanf


/* Unformatted i/o */

#define _fgettc     fgetc
#define _fgettchar  _fgetchar
#define _fgetts     fgets
#define _fputtc     fputc
#define _fputtchar  _fputchar
#define _fputts     fputs
#define _cputts     _cputs
#define _gettc      getc
#define _gettch     _getch
#define _gettche    _getche
#define _gettchar   getchar
#define _getts      gets
#define _cgetts     _cgets
#define _puttc      putc
#define _puttchar   putchar
#define _puttch     _putch
#define _putts      puts
#define _ungettc    ungetc
#define _ungettch   _ungetch


/* String conversion functions */

#define _tcstod     strtod
#define _tcstol     strtol
#define _tcstoul    strtoul
#define _tstof      atof
#define _tstol      atol
#define _tstoi      atoi
#define _tstoi64    _atoi64

#define _itot       _itoa
#define _ltot       _ltoa
#define _ultot      _ultoa
#define _ttoi       atoi
#define _ttol       atol

#define _ttoi64     _atoi64
#define _tcstoi64   _strtoi64
#define _tcstoui64  _strtoui64
#define _i64tot     _i64toa
#define _ui64tot    _ui64toa

/* String functions */

/* Note that _mbscat, _mbscpy and _mbsdup are functionally equivalent to 
   strcat, strcpy and strdup, respectively. */

#define _tcscat     strcat
#define _tcscpy     strcpy
#define _tcsdup     _strdup

#define _tcslen     strlen
#define _tcsxfrm    strxfrm
#define _tcserror   strerror
#define __tcserror  _strerror

/* Execute functions */

#define _texecl     _execl
#define _texecle    _execle
#define _texeclp    _execlp
#define _texeclpe   _execlpe
#define _texecv     _execv
#define _texecve    _execve
#define _texecvp    _execvp
#define _texecvpe   _execvpe
#define _tspawnl    _spawnl
#define _tspawnle   _spawnle
#define _tspawnlp   _spawnlp
#define _tspawnlpe  _spawnlpe
#define _tspawnv    _spawnv
#define _tspawnve   _spawnve
#define _tspawnvp   _spawnvp
#define _tspawnvpe  _spawnvpe
#define _tsystem    system

/* Time functions */

#define _tasctime   asctime
#define _tctime     ctime
#define _tctime64   _ctime64
#define _tstrdate   _strdate
#define _tstrtime   _strtime
#define _tutime     _utime
#define _tutime64   _utime64
#define _tcsftime   strftime

/* Directory functions */

#define _tchdir     _chdir
#define _tgetcwd    _getcwd
#define _tgetdcwd   _getdcwd
#define _tmkdir     _mkdir
#define _trmdir     _rmdir

/* Environment/Path functions */

#define _tfullpath  _fullpath
#define _tgetenv    getenv
#define _tmakepath  _makepath
#define _tpgmptr    _pgmptr
#define _tputenv    _putenv
#define _tsearchenv _searchenv
#define _tsplitpath _splitpath

/* Stdio functions */

#define _tfdopen    _fdopen
#define _tfsopen    _fsopen
#define _tfopen     fopen
#define _tfreopen   freopen
#define _tperror    perror
#define _tpopen     _popen
#define _ttempnam   _tempnam
#define _ttmpnam    tmpnam

/* Io functions */

#define _tchmod     _chmod
#define _tcreat     _creat
#define _tfindfirst _findfirst
#define _tfindfirst64   _findfirst64
#define _tfindfirsti64  _findfirsti64
#define _tfindnext  _findnext
#define _tfindnext64    _findnext64
#define _tfindnexti64   _findnexti64
#define _tmktemp    _mktemp

#define _topen      _open
#define _taccess    _access

#define _tremove    remove
#define _trename    rename
#define _tsopen     _sopen
#define _tunlink    _unlink

#define _tfinddata_t    _finddata_t
#define _tfinddata64_t  __finddata64_t
#define _tfinddatai64_t _finddatai64_t

/* ctype functions */

#define _istascii   isascii
#define _istcntrl   iscntrl
#define _istxdigit  isxdigit

/* Stat functions */

#define _tstat      _stat
#define _tstat64    _stat64
#define _tstati64   _stati64


/* Setlocale functions */

#define _tsetlocale setlocale

#ifdef  _MBCS

#ifdef  _MB_MAP_DIRECT

/* use mb functions directly - types must match */

/* String functions */

#define _tcschr     _mbschr
#define _tcscspn    _mbscspn
#define _tcsncat    _mbsnbcat
#define _tcsncpy    _mbsnbcpy
#define _tcspbrk    _mbspbrk
#define _tcsrchr    _mbsrchr
#define _tcsspn     _mbsspn
#define _tcsstr     _mbsstr
#define _tcstok     _mbstok

#define _tcsnset    _mbsnbset
#define _tcsrev     _mbsrev
#define _tcsset     _mbsset

#define _tcscmp     _mbscmp
#define _tcsicmp    _mbsicmp
#define _tcsnccmp   _mbsncmp
#define _tcsncmp    _mbsnbcmp
#define _tcsncicmp  _mbsnicmp
#define _tcsnicmp   _mbsnbicmp

#define _tcscoll    _mbscoll
#define _tcsicoll   _mbsicoll
#define _tcsnccoll  _mbsncoll
#define _tcsncoll   _mbsnbcoll
#define _tcsncicoll _mbsnicoll
#define _tcsnicoll  _mbsnbicoll


/* "logical-character" mappings */

#define _tcsclen    _mbslen
#define _tcsnccat   _mbsncat
#define _tcsnccpy   _mbsncpy
#define _tcsncset   _mbsnset


/* MBCS-specific mappings */

#define _tcsdec     _mbsdec
#define _tcsinc     _mbsinc
#define _tcsnbcnt   _mbsnbcnt
#define _tcsnccnt   _mbsnccnt
#define _tcsnextc   _mbsnextc
#define _tcsninc    _mbsninc
#define _tcsspnp    _mbsspnp

#define _tcslwr     _mbslwr
#define _tcsupr     _mbsupr

#define _tclen      _mbclen
#define _tccpy      _mbccpy

#define _tccmp(_cpuc1,_cpuc2)   _tcsnccmp(_cpuc1,_cpuc2,1)


#else /* _MB_MAP_DIRECT */

_CRTIMP char * __cdecl _tcschr(const char *, unsigned int);
_CRTIMP size_t __cdecl _tcscspn(const char *, const char *);
_CRTIMP char * __cdecl _tcsncat(char *, const char *, size_t);
_CRTIMP char * __cdecl _tcsncpy(char *, const char *, size_t);
_CRTIMP char * __cdecl _tcspbrk(const char *, const char *);
_CRTIMP char * __cdecl _tcsrchr(const char *, int);
_CRTIMP size_t __cdecl _tcsspn(const char *, const char *);
_CRTIMP char * __cdecl _tcsstr(const char *, const char *);
_CRTIMP char * __cdecl _tcstok(char *, const char *);

_CRTIMP char * __cdecl _tcsnset(char *, unsigned int, size_t);
_CRTIMP char * __cdecl _tcsrev(char *);
_CRTIMP char * __cdecl _tcsset(char *, unsigned int);

_CRTIMP int __cdecl _tcscmp(const char *, const char *);
_CRTIMP int __cdecl _tcsicmp(const char *, const char *);
_CRTIMP int __cdecl _tcsnccmp(const char *, const char *, size_t);
_CRTIMP int __cdecl _tcsncmp(const char *, const char *, size_t);
_CRTIMP int __cdecl _tcsncicmp(const char *, const char *, size_t);
_CRTIMP int __cdecl _tcsnicmp(const char *, const char *, size_t);

_CRTIMP int __cdecl _tcscoll(const char *, const char *);
_CRTIMP int __cdecl _tcsicoll(const char *, const char *);
_CRTIMP int __cdecl _tcsnccoll(const char *, const char *, size_t);
_CRTIMP int __cdecl _tcsncoll(const char *, const char *, size_t);
_CRTIMP int __cdecl _tcsncicoll(const char *, const char *, size_t);
_CRTIMP int __cdecl _tcsnicoll(const char *, const char *, size_t);


/* "logical-character" mappings */

_CRTIMP size_t __cdecl _tcsclen(const char *);
_CRTIMP char * __cdecl _tcsnccat(char *, const char *, size_t);
_CRTIMP char * __cdecl _tcsnccpy(char *, const char *, size_t);
_CRTIMP char * __cdecl _tcsncset(char *, unsigned int, size_t);


/* MBCS-specific mappings */

_CRTIMP char * __cdecl _tcsdec(const char *, const char *);
_CRTIMP char * __cdecl _tcsinc(const char *);
_CRTIMP size_t __cdecl _tcsnbcnt(const char *, size_t);
_CRTIMP size_t __cdecl _tcsnccnt(const char *, size_t);
_CRTIMP unsigned int __cdecl _tcsnextc (const char *);
_CRTIMP char * __cdecl _tcsninc(const char *, size_t);
_CRTIMP char * __cdecl _tcsspnp(const char *, const char *);

_CRTIMP char * __cdecl _tcslwr(char *);
_CRTIMP char * __cdecl _tcsupr(char *);

_CRTIMP size_t __cdecl _tclen(const char *);
_CRTIMP void __cdecl _tccpy(char *, const char *);

#endif  /* _MB_MAP_DIRECT */
#else   /* !_MBCS */
/* String functions */

#define _tcschr     strchr
#define _tcscspn    strcspn
#define _tcsncat    strncat
#define _tcsncpy    strncpy
#define _tcspbrk    strpbrk
#define _tcsrchr    strrchr
#define _tcsspn     strspn
#define _tcsstr     strstr
#define _tcstok     strtok

#define _tcsnset    _strnset
#define _tcsrev     _strrev
#define _tcsset     _strset

#define _tcscmp     strcmp
#define _tcsicmp    _stricmp
#define _tcsnccmp   strncmp
#define _tcsncmp    strncmp
#define _tcsncicmp  _strnicmp
#define _tcsnicmp   _strnicmp

#define _tcscoll    strcoll
#define _tcsicoll   _stricoll
#define _tcsnccoll  _strncoll
#define _tcsncoll   _strncoll
#define _tcsncicoll _strnicoll
#define _tcsnicoll  _strnicoll


/* "logical-character" mappings */

#define _tcsclen    strlen
#define _tcsnccat   strncat
#define _tcsnccpy   strncpy
#define _tcsncset   _strnset


/* MBCS-specific functions */

#define _tcsdec     _strdec
#define _tcsinc     _strinc
#define _tcsnbcnt   _strncnt
#define _tcsnccnt   _strncnt
#define _tcsnextc   _strnextc
#define _tcsninc    _strninc
#define _tcsspnp    _strspnp

#define _tcslwr     _strlwr
#define _tcsupr     _strupr
#define _tcsxfrm    strxfrm

#define _istlead(_c)    (0)
#define _istleadbyte(_c)    (0)

#endif  /* _MBCS */

#endif

























#endif  /* _INC_STRING */

