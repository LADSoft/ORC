/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#ifndef __WINCRYPT_H__
#define __WINCRYPT_H__

#pragma warning(push)
#pragma warning(disable:4201)

#pragma once

#ifndef _HRESULT_DEFINED
#define _HRESULT_DEFINED
typedef LONG HRESULT;

#endif // !_HRESULT_DEFINED

#ifndef WINADVAPI
#define WINADVAPI
#endif

#ifndef WINAPI
#define WINAPI __stdcall
#endif

#ifndef CALLBACK
#define CALLBACK __stdcall
#endif

#ifndef DECLSPEC_IMPORT
#define DECLSPEC_IMPORT
#endif

#ifndef CONST
#define CONST const
#endif

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif

#ifndef OPTIONAL
#define OPTIONAL
#endif

#if !defined(_CRYPT32_)
#define WINCRYPT32API DECLSPEC_IMPORT
#else
#define WINCRYPT32API
#endif

#define GET_ALG_CLASS(x)                (x & (7 << 13))
#define GET_ALG_TYPE(x)                 (x & (15 << 9))
#define GET_ALG_SID(x)                  (x & (511))

#define ALG_CLASS_ANY                   (0)
#define ALG_CLASS_SIGNATURE             (1 << 13)
#define ALG_CLASS_MSG_ENCRYPT           (2 << 13)
#define ALG_CLASS_DATA_ENCRYPT          (3 << 13)
#define ALG_CLASS_HASH                  (4 << 13)
#define ALG_CLASS_KEY_EXCHANGE          (5 << 13)
#define ALG_CLASS_ALL                   (7 << 13)

// Algorithm types
#define ALG_TYPE_ANY                    (0)
#define ALG_TYPE_DSS                    (1 << 9)
#define ALG_TYPE_RSA                    (2 << 9)
#define ALG_TYPE_BLOCK                  (3 << 9)
#define ALG_TYPE_STREAM                 (4 << 9)
#define ALG_TYPE_DH                     (5 << 9)
#define ALG_TYPE_SECURECHANNEL          (6 << 9)
#define ALG_SID_ANY                     (0)
#define ALG_SID_RSA_ANY                 0
#define ALG_SID_RSA_PKCS                1
#define ALG_SID_RSA_MSATWORK            2
#define ALG_SID_RSA_ENTRUST             3
#define ALG_SID_RSA_PGP                 4
#define ALG_SID_DSS_ANY                 0
#define ALG_SID_DSS_PKCS                1
#define ALG_SID_DSS_DMS                 2
#define ALG_SID_DES                     1
#define ALG_SID_3DES                    3
#define ALG_SID_DESX                    4
#define ALG_SID_IDEA                    5
#define ALG_SID_CAST                    6
#define ALG_SID_SAFERSK64               7
#define ALG_SID_SAFERSK128              8
#define ALG_SID_3DES_112                9
#define ALG_SID_CYLINK_MEK              12
#define ALG_SID_RC5                     13
#define ALG_SID_SKIPJACK                10
#define ALG_SID_TEK                     11

#define CRYPT_MODE_CBCI                 6
#define CRYPT_MODE_CFBP                 7
#define CRYPT_MODE_OFBP                 8
#define CRYPT_MODE_CBCOFM               9
#define CRYPT_MODE_CBCOFMI              10

#define ALG_SID_RC2                     2
#define ALG_SID_RC4                     1
#define ALG_SID_SEAL                    2
#define ALG_SID_DH_SANDF                1
#define ALG_SID_DH_EPHEM                2
#define ALG_SID_AGREED_KEY_ANY          3
#define ALG_SID_KEA                     4
#define ALG_SID_MD2                     1
#define ALG_SID_MD4                     2
#define ALG_SID_MD5                     3
#define ALG_SID_SHA                     4
#define ALG_SID_SHA1                    4
#define ALG_SID_MAC                     5
#define ALG_SID_RIPEMD                  6
#define ALG_SID_RIPEMD160               7
#define ALG_SID_SSL3SHAMD5              8
#define ALG_SID_HMAC                    9
#define	ALG_SID_TLS1PRF					10
#define ALG_SID_SSL3_MASTER             1
#define ALG_SID_SCHANNEL_MASTER_HASH    2
#define ALG_SID_SCHANNEL_MAC_KEY        3
#define ALG_SID_PCT1_MASTER             4
#define ALG_SID_SSL2_MASTER             5
#define ALG_SID_TLS1_MASTER             6
#define ALG_SID_SCHANNEL_ENC_KEY        7
#define ALG_SID_EXAMPLE                 80
#ifndef ALGIDDEF
#define ALGIDDEF
typedef unsigned int ALG_ID;
#endif

#define CALG_MD2                (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_MD2)
#define CALG_MD4                (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_MD4)
#define CALG_MD5                (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_MD5)
#define CALG_SHA                (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_SHA)
#define CALG_SHA1               (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_SHA1)
#define CALG_MAC                (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_MAC)
#define CALG_RSA_SIGN           (ALG_CLASS_SIGNATURE | ALG_TYPE_RSA | ALG_SID_RSA_ANY)
#define CALG_DSS_SIGN           (ALG_CLASS_SIGNATURE | ALG_TYPE_DSS | ALG_SID_DSS_ANY)
#define CALG_RSA_KEYX           (ALG_CLASS_KEY_EXCHANGE|ALG_TYPE_RSA|ALG_SID_RSA_ANY)
#define CALG_DES                (ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_DES)
#define CALG_3DES_112           (ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_3DES_112)
#define CALG_3DES               (ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_3DES)
#define CALG_DESX               (ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_DESX)
#define CALG_RC2				(ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_RC2)
#define CALG_RC4				(ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_STREAM|ALG_SID_RC4)
#define CALG_SEAL				(ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_STREAM|ALG_SID_SEAL)
#define CALG_DH_SF              (ALG_CLASS_KEY_EXCHANGE|ALG_TYPE_DH|ALG_SID_DH_SANDF)
#define CALG_DH_EPHEM			(ALG_CLASS_KEY_EXCHANGE|ALG_TYPE_DH|ALG_SID_DH_EPHEM)
#define CALG_AGREEDKEY_ANY		(ALG_CLASS_KEY_EXCHANGE|ALG_TYPE_DH|ALG_SID_AGREED_KEY_ANY)
#define CALG_KEA_KEYX			(ALG_CLASS_KEY_EXCHANGE|ALG_TYPE_DH|ALG_SID_KEA)
#define CALG_HUGHES_MD5         (ALG_CLASS_KEY_EXCHANGE|ALG_TYPE_ANY|ALG_SID_MD5)
#define CALG_SKIPJACK			(ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_SKIPJACK)
#define CALG_TEK				(ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_TEK)
#define CALG_CYLINK_MEK         (ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_CYLINK_MEK)
#define CALG_SSL3_SHAMD5        (ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_SSL3SHAMD5)
#define CALG_SSL3_MASTER        (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_SSL3_MASTER)
#define CALG_SCHANNEL_MASTER_HASH   (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_SCHANNEL_MASTER_HASH)
#define CALG_SCHANNEL_MAC_KEY   (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_SCHANNEL_MAC_KEY)
#define CALG_SCHANNEL_ENC_KEY   (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_SCHANNEL_ENC_KEY)
#define CALG_PCT1_MASTER        (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_PCT1_MASTER)
#define CALG_SSL2_MASTER        (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_SSL2_MASTER)
#define CALG_TLS1_MASTER        (ALG_CLASS_MSG_ENCRYPT|ALG_TYPE_SECURECHANNEL|ALG_SID_TLS1_MASTER)
#define CALG_RC5                (ALG_CLASS_DATA_ENCRYPT|ALG_TYPE_BLOCK|ALG_SID_RC5)
#define CALG_HMAC				(ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_HMAC)
#define CALG_TLS1PRF			(ALG_CLASS_HASH | ALG_TYPE_ANY | ALG_SID_TLS1PRF)

#define	SIGNATURE_RESOURCE_NUMBER	0x29A

typedef struct _VTableProvStruc {
    DWORD   Version;
    FARPROC FuncVerifyImage;
    FARPROC FuncReturnhWnd;
    DWORD   dwProvType;
    BYTE	*pbContextInfo;
    DWORD	cbContextInfo;
    LPSTR   pszProvName;
} VTableProvStruc, *PVTableProvStruc;

typedef ULONG_PTR HCRYPTPROV;
typedef ULONG_PTR HCRYPTKEY;
typedef ULONG_PTR HCRYPTHASH;

#define CRYPT_VERIFYCONTEXT     0xF0000000
#define CRYPT_NEWKEYSET         0x00000008
#define CRYPT_DELETEKEYSET      0x00000010
#define CRYPT_MACHINE_KEYSET    0x00000020
#define CRYPT_SILENT            0x00000040
#define CRYPT_EXPORTABLE        0x00000001
#define CRYPT_USER_PROTECTED    0x00000002
#define CRYPT_CREATE_SALT       0x00000004
#define CRYPT_UPDATE_KEY        0x00000008
#define CRYPT_NO_SALT           0x00000010
#define CRYPT_PREGEN            0x00000040
#define CRYPT_RECIPIENT         0x00000010
#define CRYPT_INITIATOR         0x00000040
#define CRYPT_ONLINE            0x00000080
#define CRYPT_SF                0x00000100
#define CRYPT_CREATE_IV         0x00000200
#define CRYPT_KEK               0x00000400
#define CRYPT_DATA_KEY          0x00000800
#define	CRYPT_VOLATILE          0x00001000
#define	CRYPT_SGCKEY            0x00002000

#define RSA1024BIT_KEY          0x04000000

// dwFlags definitions for CryptDeriveKey
#define	CRYPT_SERVER			0x00000400

#define KEY_LENGTH_MASK         0xFFFF0000

// dwFlag definitions for CryptExportKey
#define CRYPT_Y_ONLY            0x00000001
#define CRYPT_SSL2_FALLBACK     0x00000002
#define CRYPT_DESTROYKEY        0x00000004
#define CRYPT_OAEP              0x00000040
#define CRYPT_BLOB_VER3         0x00000080
#define CRYPT_SECRETDIGEST      0x00000001
#define CRYPT_LITTLE_ENDIAN     0x00000001
#define	CRYPT_NOHASHOID         0x00000001
#define	CRYPT_TYPE2_FORMAT      0x00000002
#define	CRYPT_X931_FORMAT       0x00000004
#define CRYPT_MACHINE_DEFAULT   0x00000001
#define CRYPT_USER_DEFAULT      0x00000002
#define CRYPT_DELETE_DEFAULT    0x00000004

#define SIMPLEBLOB              0x1
#define PUBLICKEYBLOB           0x6
#define PRIVATEKEYBLOB          0x7
#define PLAINTEXTKEYBLOB        0x8
#define OPAQUEKEYBLOB           0x9
#define PUBLICKEYBLOBEX         0xA
#define SYMMETRICWRAPKEYBLOB    0xB

#define AT_KEYEXCHANGE          1
#define AT_SIGNATURE            2

#define CRYPT_USERDATA          1

#define KP_IV                   1
#define KP_SALT                 2
#define KP_PADDING              3
#define KP_MODE                 4
#define KP_MODE_BITS            5
#define KP_PERMISSIONS          6
#define KP_ALGID                7
#define KP_BLOCKLEN             8
#define KP_KEYLEN               9
#define KP_SALT_EX              10
#define KP_P                    11
#define KP_G                    12
#define KP_Q                    13
#define KP_X                    14
#define KP_Y                    15
#define KP_RA                   16
#define KP_RB                   17
#define KP_INFO                 18
#define KP_EFFECTIVE_KEYLEN     19
#define KP_SCHANNEL_ALG	        20
#define KP_CLIENT_RANDOM		21
#define KP_SERVER_RANDOM		22
#define	KP_RP					23
#define	KP_PRECOMP_MD5			24
#define	KP_PRECOMP_SHA			25
#define KP_CERTIFICATE          26
#define KP_CLEAR_KEY            27
#define KP_PUB_EX_LEN           28
#define KP_PUB_EX_VAL           29
#define KP_KEYVAL				30
#define KP_ADMIN_PIN            31
#define KP_KEYEXCHANGE_PIN      32
#define KP_SIGNATURE_PIN        33
#define	KP_PREHASH              34

#define	KP_OAEP_PARAMS          36
#define	KP_CMS_KEY_INFO			37
#define	KP_CMS_DH_KEY_INFO      38
#define KP_PUB_PARAMS           39
#define KP_VERIFY_PARAMS        40
#define KP_HIGHEST_VERSION      41

#define PKCS5_PADDING           1
#define RANDOM_PADDING			2
#define	ZERO_PADDING			3

#define CRYPT_MODE_CBC          1
#define CRYPT_MODE_ECB          2
#define CRYPT_MODE_OFB          3
#define CRYPT_MODE_CFB          4
#define CRYPT_MODE_CTS          5

#define CRYPT_ENCRYPT           0x0001
#define CRYPT_DECRYPT           0x0002
#define CRYPT_EXPORT            0x0004
#define CRYPT_READ              0x0008
#define CRYPT_WRITE             0x0010
#define CRYPT_MAC               0x0020
#define CRYPT_EXPORT_KEY        0x0040
#define CRYPT_IMPORT_KEY        0x0080

#define HP_ALGID                0x0001
#define HP_HASHVAL              0x0002
#define HP_HASHSIZE             0x0004
#define HP_HMAC_INFO            0x0005
#define HP_TLS1PRF_LABEL        0x0006
#define HP_TLS1PRF_SEED         0x0007

#define CRYPT_FAILED            FALSE
#define CRYPT_SUCCEED           TRUE

#define RCRYPT_SUCCEEDED(rt)     ((rt) == CRYPT_SUCCEED)
#define RCRYPT_FAILED(rt)        ((rt) == CRYPT_FAILED)

#define PP_ENUMALGS             1
#define PP_ENUMCONTAINERS       2
#define PP_IMPTYPE              3
#define PP_NAME                 4
#define PP_VERSION              5
#define PP_CONTAINER            6
#define PP_CHANGE_PASSWORD      7
#define PP_KEYSET_SEC_DESCR     8
#define PP_CERTCHAIN            9
#define PP_KEY_TYPE_SUBTYPE     10
#define PP_PROVTYPE             16
#define PP_KEYSTORAGE           17
#define PP_APPLI_CERT           18
#define PP_SYM_KEYSIZE          19
#define PP_SESSION_KEYSIZE      20
#define PP_UI_PROMPT            21
#define PP_ENUMALGS_EX          22
#define PP_ENUMMANDROOTS		25
#define PP_ENUMELECTROOTS		26
#define	PP_KEYSET_TYPE			27
#define PP_ADMIN_PIN            31
#define PP_KEYEXCHANGE_PIN      32
#define PP_SIGNATURE_PIN        33
#define PP_SIG_KEYSIZE_INC      34
#define PP_KEYX_KEYSIZE_INC     35
#define PP_UNIQUE_CONTAINER     36
#define PP_SGC_INFO             37
#define PP_USE_HARDWARE_RNG     38
#define	PP_KEYSPEC              39
#define	PP_ENUMEX_SIGNING_PROT  40

#define CRYPT_FIRST             1
#define CRYPT_NEXT              2
#define CRYPT_SGC_ENUM			4

#define CRYPT_IMPL_HARDWARE     1
#define CRYPT_IMPL_SOFTWARE     2
#define CRYPT_IMPL_MIXED        3
#define CRYPT_IMPL_UNKNOWN      4
#define CRYPT_IMPL_REMOVABLE    8

#define CRYPT_SEC_DESCR         0x00000001
#define CRYPT_PSTORE            0x00000002
#define CRYPT_UI_PROMPT         0x00000004

#define CRYPT_FLAG_PCT1         0x0001
#define CRYPT_FLAG_SSL2         0x0002
#define CRYPT_FLAG_SSL3         0x0004
#define CRYPT_FLAG_TLS1         0x0008
#define CRYPT_FLAG_IPSEC        0x0010
#define CRYPT_FLAG_SIGNING      0x0020

#define CRYPT_SGC               0x0001
#define CRYPT_FASTSGC           0x0002

#define PP_CLIENT_HWND          1
#define PP_CONTEXT_INFO			11
#define	PP_KEYEXCHANGE_KEYSIZE	12
#define	PP_SIGNATURE_KEYSIZE    13
#define PP_KEYEXCHANGE_ALG      14
#define PP_SIGNATURE_ALG        15
#define PP_DELETEKEY            24
#define PROV_RSA_FULL           1
#define PROV_RSA_SIG            2
#define PROV_DSS                3
#define PROV_FORTEZZA           4
#define PROV_MS_EXCHANGE        5
#define PROV_SSL                6
#define PROV_RSA_SCHANNEL       12
#define PROV_DSS_DH             13
#define PROV_EC_ECDSA_SIG       14
#define PROV_EC_ECNRA_SIG       15
#define PROV_EC_ECDSA_FULL      16
#define PROV_EC_ECNRA_FULL      17
#define PROV_DH_SCHANNEL        18
#define PROV_SPYRUS_LYNKS       20
#define PROV_RNG                21
#define PROV_INTEL_SEC          22

#define PROV_STT_MER                    7
#define PROV_STT_ACQ                    8
#define PROV_STT_BRND                   9
#define PROV_STT_ROOT                   10
#define PROV_STT_ISS                    11

#define MS_DEF_PROV_A       "Microsoft Base Cryptographic Provider v1.0"
#define MS_DEF_PROV_W       L"Microsoft Base Cryptographic Provider v1.0"
#ifdef UNICODE
#define MS_DEF_PROV         MS_DEF_PROV_W
#else
#define MS_DEF_PROV         MS_DEF_PROV_A
#endif

#define MS_ENHANCED_PROV_A       "Microsoft Enhanced Cryptographic Provider v1.0"
#define MS_ENHANCED_PROV_W       L"Microsoft Enhanced Cryptographic Provider v1.0"
#ifdef UNICODE
#define MS_ENHANCED_PROV         MS_ENHANCED_PROV_W
#else
#define MS_ENHANCED_PROV         MS_ENHANCED_PROV_A
#endif

#define MS_STRONG_PROV_A       "Microsoft Strong Cryptographic Provider"
#define MS_STRONG_PROV_W       L"Microsoft Strong Cryptographic Provider"
#ifdef UNICODE
#define MS_STRONG_PROV         MS_STRONG_PROV_W
#else
#define MS_STRONG_PROV           MS_STRONG_PROV_A
#endif

#define MS_DEF_RSA_SIG_PROV_A    "Microsoft RSA Signature Cryptographic Provider"
#define MS_DEF_RSA_SIG_PROV_W    L"Microsoft RSA Signature Cryptographic Provider"
#ifdef UNICODE
#define MS_DEF_RSA_SIG_PROV      MS_DEF_RSA_SIG_PROV_W
#else
#define MS_DEF_RSA_SIG_PROV      MS_DEF_RSA_SIG_PROV_A
#endif

#define MS_DEF_RSA_SCHANNEL_PROV_A  "Microsoft RSA SChannel Cryptographic Provider"
#define MS_DEF_RSA_SCHANNEL_PROV_W  L"Microsoft RSA SChannel Cryptographic Provider"
#ifdef UNICODE
#define MS_DEF_RSA_SCHANNEL_PROV         MS_DEF_RSA_SCHANNEL_PROV_W
#else
#define MS_DEF_RSA_SCHANNEL_PROV         MS_DEF_RSA_SCHANNEL_PROV_A
#endif

#define MS_DEF_DSS_PROV_A        "Microsoft Base DSS Cryptographic Provider"
#define MS_DEF_DSS_PROV_W        L"Microsoft Base DSS Cryptographic Provider"
#ifdef UNICODE
#define MS_DEF_DSS_PROV          MS_DEF_DSS_PROV_W
#else
#define MS_DEF_DSS_PROV          MS_DEF_DSS_PROV_A
#endif

#define MS_DEF_DSS_DH_PROV_A    "Microsoft Base DSS and Diffie-Hellman Cryptographic Provider"
#define MS_DEF_DSS_DH_PROV_W    L"Microsoft Base DSS and Diffie-Hellman Cryptographic Provider"
#ifdef UNICODE
#define MS_DEF_DSS_DH_PROV      MS_DEF_DSS_DH_PROV_W
#else
#define MS_DEF_DSS_DH_PROV      MS_DEF_DSS_DH_PROV_A
#endif

#define MS_ENH_DSS_DH_PROV_A    "Microsoft Enhanced DSS and Diffie-Hellman Cryptographic Provider"
#define MS_ENH_DSS_DH_PROV_W    L"Microsoft Enhanced DSS and Diffie-Hellman Cryptographic Provider"
#ifdef UNICODE
#define MS_ENH_DSS_DH_PROV      MS_ENH_DSS_DH_PROV_W
#else
#define MS_ENH_DSS_DH_PROV      MS_ENH_DSS_DH_PROV_A
#endif

#define MS_DEF_DH_SCHANNEL_PROV_A  "Microsoft DH SChannel Cryptographic Provider"
#define MS_DEF_DH_SCHANNEL_PROV_W  L"Microsoft DH SChannel Cryptographic Provider"
#ifdef UNICODE
#define MS_DEF_DH_SCHANNEL_PROV         MS_DEF_DH_SCHANNEL_PROV_W
#else
#define MS_DEF_DH_SCHANNEL_PROV         MS_DEF_DH_SCHANNEL_PROV_A
#endif

#define MS_SCARD_PROV_A  "Microsoft Base Smart Card Crypto Provider"
#define MS_SCARD_PROV_W  L"Microsoft Base Smart Card Crypto Provider"
#ifdef UNICODE
#define MS_SCARD_PROV MS_SCARD_PROV_W
#else
#define MS_SCARD_PROV MS_SCARD_PROV_A
#endif

#define MAXUIDLEN               64

#define EXPO_OFFLOAD_REG_VALUE "ExpoOffload"
#define EXPO_OFFLOAD_FUNC_NAME "OffloadModExpo"

#define szKEY_CRYPTOAPI_PRIVATE_KEY_OPTIONS \
    "Software\\Policies\\Microsoft\\Cryptography" 
#define szFORCE_KEY_PROTECTION             "ForceKeyProtection"
#define dwFORCE_KEY_PROTECTION_DISABLED     0x0
#define dwFORCE_KEY_PROTECTION_USER_SELECT  0x1
#define dwFORCE_KEY_PROTECTION_HIGH         0x2
 
#define szKEY_CACHE_ENABLED     "CachePrivateKeys"
#define szKEY_CACHE_SECONDS     "PrivateKeyLifetimeSeconds"

#define CUR_BLOB_VERSION        2

typedef struct _CMS_KEY_INFO {
    DWORD	dwVersion;
    ALG_ID  Algid;
    BYTE    *pbOID;
    DWORD   cbOID;
} CMS_KEY_INFO, *PCMS_KEY_INFO;

typedef struct _HMAC_Info {
    ALG_ID  HashAlgid;
    BYTE    *pbInnerString;
    DWORD   cbInnerString;
    BYTE    *pbOuterString;
    DWORD   cbOuterString;
} HMAC_INFO, *PHMAC_INFO;

typedef struct _SCHANNEL_ALG {
    DWORD   dwUse;
    ALG_ID  Algid;
    DWORD   cBits;
    DWORD   dwFlags;
    DWORD   dwReserved;
} SCHANNEL_ALG, *PSCHANNEL_ALG;

#define     SCHANNEL_MAC_KEY    0x00000000
#define     SCHANNEL_ENC_KEY    0x00000001

#define     INTERNATIONAL_USAGE 0x00000001

typedef struct _PROV_ENUMALGS {
    ALG_ID    aiAlgid;
    DWORD     dwBitLen;
    DWORD     dwNameLen;
    CHAR      szName[20];
} PROV_ENUMALGS;

typedef struct _PROV_ENUMALGS_EX {
    ALG_ID    aiAlgid;
    DWORD     dwDefaultLen;
    DWORD     dwMinLen;
    DWORD     dwMaxLen;
    DWORD     dwProtocols;
    DWORD     dwNameLen;
    CHAR      szName[20];
    DWORD     dwLongNameLen;
    CHAR      szLongName[40];
} PROV_ENUMALGS_EX;

typedef struct _PUBLICKEYSTRUC {
        BYTE    bType;
        BYTE    bVersion;
        WORD    reserved;
        ALG_ID  aiKeyAlg;
} BLOBHEADER, PUBLICKEYSTRUC;

typedef struct _RSAPUBKEY {
        DWORD   magic;
        DWORD   bitlen;
        DWORD   pubexp;
} RSAPUBKEY;

typedef struct _PUBKEY {
        DWORD   magic;
        DWORD   bitlen;
} DHPUBKEY, DSSPUBKEY, KEAPUBKEY, TEKPUBKEY;

typedef struct _DSSSEED {
        DWORD   counter;
        BYTE    seed[20];
} DSSSEED;

typedef struct _PUBKEYVER3 {
        DWORD   magic;
        DWORD   bitlenP;
        DWORD   bitlenQ;
        DWORD   bitlenJ;
        DSSSEED DSSSeed;
} DHPUBKEY_VER3, DSSPUBKEY_VER3;

typedef struct _PRIVKEYVER3 {
        DWORD   magic;
        DWORD   bitlenP;
        DWORD   bitlenQ;
        DWORD   bitlenJ;
        DWORD   bitlenX;
        DSSSEED DSSSeed;
} DHPRIVKEY_VER3, DSSPRIVKEY_VER3;

typedef struct _KEY_TYPE_SUBTYPE {
        DWORD   dwKeySpec;
        GUID    Type;
        GUID    Subtype;
} KEY_TYPE_SUBTYPE, *PKEY_TYPE_SUBTYPE;

typedef struct _CERT_FORTEZZA_DATA_PROP {
    unsigned char   SerialNumber[8];
    int             CertIndex;
    unsigned char   CertLabel[36];
} CERT_FORTEZZA_DATA_PROP;

typedef struct _CRYPTOAPI_BLOB {
    DWORD   cbData;
    BYTE    *pbData;
} CRYPT_INTEGER_BLOB, *PCRYPT_INTEGER_BLOB,
CRYPT_UINT_BLOB, *PCRYPT_UINT_BLOB,
CRYPT_OBJID_BLOB, *PCRYPT_OBJID_BLOB,
CERT_NAME_BLOB, *PCERT_NAME_BLOB,
CERT_RDN_VALUE_BLOB, *PCERT_RDN_VALUE_BLOB,
CERT_BLOB, *PCERT_BLOB,
CRL_BLOB, *PCRL_BLOB,
DATA_BLOB, *PDATA_BLOB,
CRYPT_DATA_BLOB, *PCRYPT_DATA_BLOB,
CRYPT_HASH_BLOB, *PCRYPT_HASH_BLOB,
CRYPT_DIGEST_BLOB, *PCRYPT_DIGEST_BLOB,
CRYPT_DER_BLOB, *PCRYPT_DER_BLOB,
CRYPT_ATTR_BLOB, *PCRYPT_ATTR_BLOB;

typedef struct _CMS_DH_KEY_INFO {
    DWORD	        dwVersion;
    ALG_ID          Algid;
    LPSTR           pszContentEncObjId;
    CRYPT_DATA_BLOB PubInfo;
    void            *pReserved;
} CMS_DH_KEY_INFO, *PCMS_DH_KEY_INFO;


WINADVAPI
BOOL
WINAPI
CryptAcquireContextA(
    HCRYPTPROV *phProv,
    LPCSTR pszContainer,
    LPCSTR pszProvider,
    DWORD dwProvType,
    DWORD dwFlags
    );
WINADVAPI
BOOL
WINAPI
CryptAcquireContextW(
    HCRYPTPROV *phProv,
    LPCWSTR pszContainer,
    LPCWSTR pszProvider,
    DWORD dwProvType,
    DWORD dwFlags
    );
#ifdef UNICODE
#define CryptAcquireContext  CryptAcquireContextW
#else
#define CryptAcquireContext  CryptAcquireContextA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptReleaseContext(
    HCRYPTPROV hProv,
    ULONG_PTR dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptGenKey(
    HCRYPTPROV hProv,
    ALG_ID Algid,
    DWORD dwFlags,
    HCRYPTKEY *phKey
    );

WINADVAPI
BOOL
WINAPI
CryptDeriveKey(
    HCRYPTPROV hProv,
    ALG_ID Algid,
    HCRYPTHASH hBaseData,
    DWORD dwFlags,
    HCRYPTKEY *phKey
    );

WINADVAPI
BOOL
WINAPI
CryptDestroyKey(
    HCRYPTKEY hKey
    );

WINADVAPI
BOOL
WINAPI
CryptSetKeyParam(
    HCRYPTKEY hKey,
    DWORD dwParam,
    BYTE *pbData,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptGetKeyParam(
    HCRYPTKEY hKey,
    DWORD dwParam,
    BYTE *pbData,
    DWORD *pdwDataLen,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptSetHashParam(
    HCRYPTHASH hHash,
    DWORD dwParam,
    BYTE*pbData,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptGetHashParam(
    HCRYPTHASH hHash,
    DWORD dwParam,
    BYTE*pbData,
    DWORD *pdwDataLen,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptSetProvParam(
    HCRYPTPROV hProv,
    DWORD dwParam,
    BYTE*pbData,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptGetProvParam(
    HCRYPTPROV hProv,
    DWORD dwParam,
    BYTE*pbData,
    DWORD *pdwDataLen,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptGenRandom(
    HCRYPTPROV hProv,
    DWORD dwLen,
    BYTE *pbBuffer
    );

WINADVAPI
BOOL
WINAPI
CryptGetUserKey(
    HCRYPTPROV hProv,
    DWORD dwKeySpec,
    HCRYPTKEY *phUserKey
    );

WINADVAPI
BOOL
WINAPI
CryptExportKey(
    HCRYPTKEY hKey,
    HCRYPTKEY hExpKey,
    DWORD dwBlobType,
    DWORD dwFlags,
    BYTE *pbData,
    DWORD *pdwDataLen
    );

WINADVAPI
BOOL
WINAPI
CryptImportKey(
    HCRYPTPROV hProv,
    CONST BYTE *pbData,
    DWORD dwDataLen,
    HCRYPTKEY hPubKey,
    DWORD dwFlags,
    HCRYPTKEY *phKey
    );

WINADVAPI
BOOL
WINAPI
CryptEncrypt(
    HCRYPTKEY hKey,
    HCRYPTHASH hHash,
    BOOL Final,
    DWORD dwFlags,
    BYTE *pbData,
    DWORD *pdwDataLen,
    DWORD dwBufLen
    );

WINADVAPI
BOOL
WINAPI
CryptDecrypt(
    HCRYPTKEY hKey,
    HCRYPTHASH hHash,
    BOOL Final,
    DWORD dwFlags,
    BYTE *pbData,
    DWORD *pdwDataLen
    );

WINADVAPI
BOOL
WINAPI
CryptCreateHash(
    HCRYPTPROV hProv,
    ALG_ID Algid,
    HCRYPTKEY hKey,
    DWORD dwFlags,
    HCRYPTHASH *phHash
    );

WINADVAPI
BOOL
WINAPI
CryptHashData(
    HCRYPTHASH hHash,
    CONST BYTE *pbData,
    DWORD dwDataLen,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptHashSessionKey(
    HCRYPTHASH hHash,
    HCRYPTKEY hKey,
    DWORD dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptDestroyHash(
    HCRYPTHASH hHash
    );

WINADVAPI
BOOL
WINAPI
CryptSignHashA(
    HCRYPTHASH hHash,
    DWORD dwKeySpec,
    LPCSTR sDescription,
    DWORD dwFlags,
    BYTE *pbSignature,
    DWORD *pdwSigLen
    );
WINADVAPI
BOOL
WINAPI
CryptSignHashW(
    HCRYPTHASH hHash,
    DWORD dwKeySpec,
    LPCWSTR sDescription,
    DWORD dwFlags,
    BYTE *pbSignature,
    DWORD *pdwSigLen
    );
#ifdef UNICODE
#define CryptSignHash  CryptSignHashW
#else
#define CryptSignHash  CryptSignHashA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptVerifySignatureA(
    HCRYPTHASH hHash,
    CONST BYTE *pbSignature,
    DWORD dwSigLen,
    HCRYPTKEY hPubKey,
    LPCSTR sDescription,
    DWORD dwFlags
    );
WINADVAPI
BOOL
WINAPI
CryptVerifySignatureW(
    HCRYPTHASH hHash,
    CONST BYTE *pbSignature,
    DWORD dwSigLen,
    HCRYPTKEY hPubKey,
    LPCWSTR sDescription,
    DWORD dwFlags
    );
#ifdef UNICODE
#define CryptVerifySignature  CryptVerifySignatureW
#else
#define CryptVerifySignature  CryptVerifySignatureA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptSetProviderA(
    LPCSTR pszProvName,
    DWORD    dwProvType
    );
WINADVAPI
BOOL
WINAPI
CryptSetProviderW(
    LPCWSTR pszProvName,
    DWORD    dwProvType
    );
#ifdef UNICODE
#define CryptSetProvider  CryptSetProviderW
#else
#define CryptSetProvider  CryptSetProviderA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptSetProviderExA(
    LPCSTR pszProvName,
    DWORD    dwProvType,
    DWORD * pdwReserved,
    DWORD   dwFlags
    );
WINADVAPI
BOOL
WINAPI
CryptSetProviderExW(
    LPCWSTR pszProvName,
    DWORD    dwProvType,
    DWORD * pdwReserved,
    DWORD   dwFlags
    );
#ifdef UNICODE
#define CryptSetProviderEx  CryptSetProviderExW
#else
#define CryptSetProviderEx  CryptSetProviderExA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptGetDefaultProviderA(
    DWORD dwProvType,
    DWORD *pdwReserved,
    DWORD dwFlags,
    LPSTR pszProvName,
    DWORD *pcbProvName
    );
WINADVAPI
BOOL
WINAPI
CryptGetDefaultProviderW(
    DWORD dwProvType,
    DWORD *pdwReserved,
    DWORD dwFlags,
    LPWSTR pszProvName,
    DWORD *pcbProvName
    );
#ifdef UNICODE
#define CryptGetDefaultProvider  CryptGetDefaultProviderW
#else
#define CryptGetDefaultProvider  CryptGetDefaultProviderA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptEnumProviderTypesA(
    DWORD   dwIndex,
    DWORD * pdwReserved,
    DWORD   dwFlags,
    DWORD * pdwProvType,
    LPSTR pszTypeName,
    DWORD * pcbTypeName
    );
WINADVAPI
BOOL
WINAPI
CryptEnumProviderTypesW(
    DWORD   dwIndex,
    DWORD * pdwReserved,
    DWORD   dwFlags,
    DWORD * pdwProvType,
    LPWSTR pszTypeName,
    DWORD * pcbTypeName
    );
#ifdef UNICODE
#define CryptEnumProviderTypes  CryptEnumProviderTypesW
#else
#define CryptEnumProviderTypes  CryptEnumProviderTypesA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptEnumProvidersA(
    DWORD   dwIndex,
    DWORD * pdwReserved,
    DWORD   dwFlags,
    DWORD * pdwProvType,
    LPSTR pszProvName,
    DWORD * pcbProvName
    );
WINADVAPI
BOOL
WINAPI
CryptEnumProvidersW(
    DWORD   dwIndex,
    DWORD * pdwReserved,
    DWORD   dwFlags,
    DWORD * pdwProvType,
    LPWSTR pszProvName,
    DWORD * pcbProvName
    );
#ifdef UNICODE
#define CryptEnumProviders  CryptEnumProvidersW
#else
#define CryptEnumProviders  CryptEnumProvidersA
#endif // !UNICODE

WINADVAPI
BOOL
WINAPI
CryptContextAddRef(
    HCRYPTPROV hProv,
    DWORD * pdwReserved,
    DWORD   dwFlags
    );

WINADVAPI
BOOL
WINAPI
CryptDuplicateKey(
    HCRYPTKEY   hKey,
    DWORD     * pdwReserved,
    DWORD       dwFlags,
    HCRYPTKEY * phKey
    );

WINADVAPI
BOOL
WINAPI
CryptDuplicateHash(
    HCRYPTHASH   hHash,
    DWORD      * pdwReserved,
    DWORD        dwFlags,
    HCRYPTHASH * phHash
    );

typedef struct _CRYPT_BIT_BLOB {
    DWORD   cbData;
    BYTE    *pbData;
    DWORD   cUnusedBits;
} CRYPT_BIT_BLOB, *PCRYPT_BIT_BLOB;

typedef struct _CRYPT_ALGORITHM_IDENTIFIER {
    LPSTR               pszObjId;
    CRYPT_OBJID_BLOB    Parameters;
} CRYPT_ALGORITHM_IDENTIFIER, *PCRYPT_ALGORITHM_IDENTIFIER;

#define szOID_RSA               "1.2.840.113549"
#define szOID_PKCS              "1.2.840.113549.1"
#define szOID_RSA_HASH          "1.2.840.113549.2"
#define szOID_RSA_ENCRYPT       "1.2.840.113549.3"
#define szOID_PKCS_1            "1.2.840.113549.1.1"
#define szOID_PKCS_2            "1.2.840.113549.1.2"
#define szOID_PKCS_3            "1.2.840.113549.1.3"
#define szOID_PKCS_4            "1.2.840.113549.1.4"
#define szOID_PKCS_5            "1.2.840.113549.1.5"
#define szOID_PKCS_6            "1.2.840.113549.1.6"
#define szOID_PKCS_7            "1.2.840.113549.1.7"
#define szOID_PKCS_8            "1.2.840.113549.1.8"
#define szOID_PKCS_9            "1.2.840.113549.1.9"
#define szOID_PKCS_10           "1.2.840.113549.1.10"
#define szOID_PKCS_12           "1.2.840.113549.1.12"
#define szOID_RSA_RSA           "1.2.840.113549.1.1.1"
#define szOID_RSA_MD2RSA        "1.2.840.113549.1.1.2"
#define szOID_RSA_MD4RSA        "1.2.840.113549.1.1.3"
#define szOID_RSA_MD5RSA        "1.2.840.113549.1.1.4"
#define szOID_RSA_SHA1RSA       "1.2.840.113549.1.1.5"
#define szOID_RSA_SETOAEP_RSA   "1.2.840.113549.1.1.6"
#define szOID_RSA_DH            "1.2.840.113549.1.3.1"
#define szOID_RSA_data          "1.2.840.113549.1.7.1"
#define szOID_RSA_signedData    "1.2.840.113549.1.7.2"
#define szOID_RSA_envelopedData "1.2.840.113549.1.7.3"
#define szOID_RSA_signEnvData   "1.2.840.113549.1.7.4"
#define szOID_RSA_digestedData  "1.2.840.113549.1.7.5"
#define szOID_RSA_hashedData    "1.2.840.113549.1.7.5"
#define szOID_RSA_encryptedData "1.2.840.113549.1.7.6"
#define szOID_RSA_emailAddr     "1.2.840.113549.1.9.1"
#define szOID_RSA_unstructName  "1.2.840.113549.1.9.2"
#define szOID_RSA_contentType   "1.2.840.113549.1.9.3"
#define szOID_RSA_messageDigest "1.2.840.113549.1.9.4"
#define szOID_RSA_signingTime   "1.2.840.113549.1.9.5"
#define szOID_RSA_counterSign   "1.2.840.113549.1.9.6"
#define szOID_RSA_challengePwd  "1.2.840.113549.1.9.7"
#define szOID_RSA_unstructAddr  "1.2.840.113549.1.9.8"
#define szOID_RSA_extCertAttrs  "1.2.840.113549.1.9.9"
#define szOID_RSA_certExtensions "1.2.840.113549.1.9.14"
#define szOID_RSA_SMIMECapabilities "1.2.840.113549.1.9.15"
#define szOID_RSA_preferSignedData "1.2.840.113549.1.9.15.1"
#define szOID_RSA_SMIMEalg              "1.2.840.113549.1.9.16.3"
#define szOID_RSA_SMIMEalgESDH          "1.2.840.113549.1.9.16.3.5"
#define szOID_RSA_SMIMEalgCMS3DESwrap   "1.2.840.113549.1.9.16.3.6"
#define szOID_RSA_SMIMEalgCMSRC2wrap    "1.2.840.113549.1.9.16.3.7"
#define szOID_RSA_MD2           "1.2.840.113549.2.2"
#define szOID_RSA_MD4           "1.2.840.113549.2.4"
#define szOID_RSA_MD5           "1.2.840.113549.2.5"
#define szOID_RSA_RC2CBC        "1.2.840.113549.3.2"
#define szOID_RSA_RC4           "1.2.840.113549.3.4"
#define szOID_RSA_DES_EDE3_CBC  "1.2.840.113549.3.7"
#define szOID_RSA_RC5_CBCPad    "1.2.840.113549.3.9"
#define szOID_ANSI_X942         "1.2.840.10046"
#define szOID_ANSI_X942_DH      "1.2.840.10046.2.1"
#define szOID_X957              "1.2.840.10040"
#define szOID_X957_DSA          "1.2.840.10040.4.1"
#define szOID_X957_SHA1DSA      "1.2.840.10040.4.3"
#define szOID_DS                "2.5"
#define szOID_DSALG             "2.5.8"
#define szOID_DSALG_CRPT        "2.5.8.1"
#define szOID_DSALG_HASH        "2.5.8.2"
#define szOID_DSALG_SIGN        "2.5.8.3"
#define szOID_DSALG_RSA         "2.5.8.1.1"
#define szOID_OIW               "1.3.14"
#define szOID_OIWSEC            "1.3.14.3.2"
#define szOID_OIWSEC_md4RSA     "1.3.14.3.2.2"
#define szOID_OIWSEC_md5RSA     "1.3.14.3.2.3"
#define szOID_OIWSEC_md4RSA2    "1.3.14.3.2.4"
#define szOID_OIWSEC_desECB     "1.3.14.3.2.6"
#define szOID_OIWSEC_desCBC     "1.3.14.3.2.7"
#define szOID_OIWSEC_desOFB     "1.3.14.3.2.8"
#define szOID_OIWSEC_desCFB     "1.3.14.3.2.9"
#define szOID_OIWSEC_desMAC     "1.3.14.3.2.10"
#define szOID_OIWSEC_rsaSign    "1.3.14.3.2.11"
#define szOID_OIWSEC_dsa        "1.3.14.3.2.12"
#define szOID_OIWSEC_shaDSA     "1.3.14.3.2.13"
#define szOID_OIWSEC_mdc2RSA    "1.3.14.3.2.14"
#define szOID_OIWSEC_shaRSA     "1.3.14.3.2.15"
#define szOID_OIWSEC_dhCommMod  "1.3.14.3.2.16"
#define szOID_OIWSEC_desEDE     "1.3.14.3.2.17"
#define szOID_OIWSEC_sha        "1.3.14.3.2.18"
#define szOID_OIWSEC_mdc2       "1.3.14.3.2.19"
#define szOID_OIWSEC_dsaComm    "1.3.14.3.2.20"
#define szOID_OIWSEC_dsaCommSHA "1.3.14.3.2.21"
#define szOID_OIWSEC_rsaXchg    "1.3.14.3.2.22"
#define szOID_OIWSEC_keyHashSeal "1.3.14.3.2.23"
#define szOID_OIWSEC_md2RSASign "1.3.14.3.2.24"
#define szOID_OIWSEC_md5RSASign "1.3.14.3.2.25"
#define szOID_OIWSEC_sha1       "1.3.14.3.2.26"
#define szOID_OIWSEC_dsaSHA1    "1.3.14.3.2.27"
#define szOID_OIWSEC_dsaCommSHA1 "1.3.14.3.2.28"
#define szOID_OIWSEC_sha1RSASign "1.3.14.3.2.29"
#define szOID_OIWDIR            "1.3.14.7.2"
#define szOID_OIWDIR_CRPT       "1.3.14.7.2.1"
#define szOID_OIWDIR_HASH       "1.3.14.7.2.2"
#define szOID_OIWDIR_SIGN       "1.3.14.7.2.3"
#define szOID_OIWDIR_md2        "1.3.14.7.2.2.1"
#define szOID_OIWDIR_md2RSA     "1.3.14.7.2.3.1"
#define szOID_INFOSEC                       "2.16.840.1.101.2.1"
#define szOID_INFOSEC_sdnsSignature         "2.16.840.1.101.2.1.1.1"
#define szOID_INFOSEC_mosaicSignature       "2.16.840.1.101.2.1.1.2"
#define szOID_INFOSEC_sdnsConfidentiality   "2.16.840.1.101.2.1.1.3"
#define szOID_INFOSEC_mosaicConfidentiality "2.16.840.1.101.2.1.1.4"
#define szOID_INFOSEC_sdnsIntegrity         "2.16.840.1.101.2.1.1.5"
#define szOID_INFOSEC_mosaicIntegrity       "2.16.840.1.101.2.1.1.6"
#define szOID_INFOSEC_sdnsTokenProtection   "2.16.840.1.101.2.1.1.7"
#define szOID_INFOSEC_mosaicTokenProtection "2.16.840.1.101.2.1.1.8"
#define szOID_INFOSEC_sdnsKeyManagement     "2.16.840.1.101.2.1.1.9"
#define szOID_INFOSEC_mosaicKeyManagement   "2.16.840.1.101.2.1.1.10"
#define szOID_INFOSEC_sdnsKMandSig          "2.16.840.1.101.2.1.1.11"
#define szOID_INFOSEC_mosaicKMandSig        "2.16.840.1.101.2.1.1.12"
#define szOID_INFOSEC_SuiteASignature       "2.16.840.1.101.2.1.1.13"
#define szOID_INFOSEC_SuiteAConfidentiality "2.16.840.1.101.2.1.1.14"
#define szOID_INFOSEC_SuiteAIntegrity       "2.16.840.1.101.2.1.1.15"
#define szOID_INFOSEC_SuiteATokenProtection "2.16.840.1.101.2.1.1.16"
#define szOID_INFOSEC_SuiteAKeyManagement   "2.16.840.1.101.2.1.1.17"
#define szOID_INFOSEC_SuiteAKMandSig        "2.16.840.1.101.2.1.1.18"
#define szOID_INFOSEC_mosaicUpdatedSig      "2.16.840.1.101.2.1.1.19"
#define szOID_INFOSEC_mosaicKMandUpdSig     "2.16.840.1.101.2.1.1.20"
#define szOID_INFOSEC_mosaicUpdatedInteg    "2.16.840.1.101.2.1.1.21"

typedef struct _CRYPT_OBJID_TABLE {
    DWORD   dwAlgId;
    LPCSTR  pszObjId;
} CRYPT_OBJID_TABLE, *PCRYPT_OBJID_TABLE;

typedef struct _CRYPT_HASH_INFO {
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    CRYPT_HASH_BLOB             Hash;
} CRYPT_HASH_INFO, *PCRYPT_HASH_INFO;

typedef struct _CERT_EXTENSION {
    LPSTR               pszObjId;
    BOOL                fCritical;
    CRYPT_OBJID_BLOB    Value;
} CERT_EXTENSION, *PCERT_EXTENSION;

typedef struct _CRYPT_ATTRIBUTE_TYPE_VALUE {
    LPSTR               pszObjId;
    CRYPT_OBJID_BLOB    Value;
} CRYPT_ATTRIBUTE_TYPE_VALUE, *PCRYPT_ATTRIBUTE_TYPE_VALUE;

typedef struct _CRYPT_ATTRIBUTE {
    LPSTR               pszObjId;
    DWORD               cValue;
    PCRYPT_ATTR_BLOB    rgValue;
} CRYPT_ATTRIBUTE, *PCRYPT_ATTRIBUTE;

typedef struct _CRYPT_ATTRIBUTES {
    DWORD                cAttr;
    PCRYPT_ATTRIBUTE     rgAttr;
} CRYPT_ATTRIBUTES, *PCRYPT_ATTRIBUTES;

typedef struct _CERT_RDN_ATTR {
    LPSTR                   pszObjId;
    DWORD                   dwValueType;
    CERT_RDN_VALUE_BLOB     Value;
} CERT_RDN_ATTR, *PCERT_RDN_ATTR;

#define szOID_COMMON_NAME                   "2.5.4.3"
#define szOID_SUR_NAME                      "2.5.4.4"
#define szOID_DEVICE_SERIAL_NUMBER          "2.5.4.5"
#define szOID_COUNTRY_NAME                  "2.5.4.6"
#define szOID_LOCALITY_NAME                 "2.5.4.7"
#define szOID_STATE_OR_PROVINCE_NAME        "2.5.4.8"
#define szOID_STREET_ADDRESS                "2.5.4.9"
#define szOID_ORGANIZATION_NAME             "2.5.4.10"
#define szOID_ORGANIZATIONAL_UNIT_NAME      "2.5.4.11"
#define szOID_TITLE                         "2.5.4.12"
#define szOID_DESCRIPTION                   "2.5.4.13"
#define szOID_SEARCH_GUIDE                  "2.5.4.14"
#define szOID_BUSINESS_CATEGORY             "2.5.4.15"
#define szOID_POSTAL_ADDRESS                "2.5.4.16"
#define szOID_POSTAL_CODE                   "2.5.4.17"
#define szOID_POST_OFFICE_BOX               "2.5.4.18"
#define szOID_PHYSICAL_DELIVERY_OFFICE_NAME "2.5.4.19"
#define szOID_TELEPHONE_NUMBER              "2.5.4.20"
#define szOID_TELEX_NUMBER                  "2.5.4.21"
#define szOID_TELETEXT_TERMINAL_IDENTIFIER  "2.5.4.22"
#define szOID_FACSIMILE_TELEPHONE_NUMBER    "2.5.4.23"
#define szOID_X21_ADDRESS                   "2.5.4.24"
#define szOID_INTERNATIONAL_ISDN_NUMBER     "2.5.4.25"
#define szOID_REGISTERED_ADDRESS            "2.5.4.26"
#define szOID_DESTINATION_INDICATOR         "2.5.4.27"
#define szOID_PREFERRED_DELIVERY_METHOD     "2.5.4.28"
#define szOID_PRESENTATION_ADDRESS          "2.5.4.29"
#define szOID_SUPPORTED_APPLICATION_CONTEXT "2.5.4.30"
#define szOID_MEMBER                        "2.5.4.31"
#define szOID_OWNER                         "2.5.4.32"
#define szOID_ROLE_OCCUPANT                 "2.5.4.33"
#define szOID_SEE_ALSO                      "2.5.4.34"
#define szOID_USER_PASSWORD                 "2.5.4.35"
#define szOID_USER_CERTIFICATE              "2.5.4.36"
#define szOID_CA_CERTIFICATE                "2.5.4.37"
#define szOID_AUTHORITY_REVOCATION_LIST     "2.5.4.38"
#define szOID_CERTIFICATE_REVOCATION_LIST   "2.5.4.39"
#define szOID_CROSS_CERTIFICATE_PAIR        "2.5.4.40"
#define szOID_GIVEN_NAME                    "2.5.4.42"
#define szOID_INITIALS                      "2.5.4.43"
#define szOID_DN_QUALIFIER                  "2.5.4.46"
#define szOID_DOMAIN_COMPONENT  "0.9.2342.19200300.100.1.25"
#define szOID_PKCS_12_FRIENDLY_NAME_ATTR     "1.2.840.113549.1.9.20"
#define szOID_PKCS_12_LOCAL_KEY_ID           "1.2.840.113549.1.9.21"
#define szOID_PKCS_12_KEY_PROVIDER_NAME_ATTR "1.3.6.1.4.1.311.17.1"
#define szOID_LOCAL_MACHINE_KEYSET			 "1.3.6.1.4.1.311.17.2"
#define szOID_KEYID_RDN                     "1.3.6.1.4.1.311.10.7.1"

#define CERT_RDN_ANY_TYPE                0
#define CERT_RDN_ENCODED_BLOB            1
#define CERT_RDN_OCTET_STRING            2
#define CERT_RDN_NUMERIC_STRING          3
#define CERT_RDN_PRINTABLE_STRING        4
#define CERT_RDN_TELETEX_STRING          5
#define CERT_RDN_T61_STRING              5
#define CERT_RDN_VIDEOTEX_STRING         6
#define CERT_RDN_IA5_STRING              7
#define CERT_RDN_GRAPHIC_STRING          8
#define CERT_RDN_VISIBLE_STRING          9
#define CERT_RDN_ISO646_STRING           9
#define CERT_RDN_GENERAL_STRING          10
#define CERT_RDN_UNIVERSAL_STRING        11
#define CERT_RDN_INT4_STRING             11
#define CERT_RDN_BMP_STRING              12
#define CERT_RDN_UNICODE_STRING          12
#define CERT_RDN_UTF8_STRING             13
#define CERT_RDN_TYPE_MASK                  0x000000FF
#define CERT_RDN_FLAGS_MASK                 0xFF000000
#define CERT_RDN_ENABLE_T61_UNICODE_FLAG    0x80000000
#define CERT_RDN_ENABLE_UTF8_UNICODE_FLAG   0x20000000
#define CERT_RDN_DISABLE_CHECK_TYPE_FLAG    0x40000000
#define CERT_RDN_DISABLE_IE4_UTF8_FLAG      0x01000000
#define IS_CERT_RDN_CHAR_STRING(X)      \
                (((X) & CERT_RDN_TYPE_MASK) >= CERT_RDN_NUMERIC_STRING)

typedef struct _CERT_RDN {
    DWORD           cRDNAttr;
    PCERT_RDN_ATTR  rgRDNAttr;
} CERT_RDN, *PCERT_RDN;

typedef struct _CERT_NAME_INFO {
    DWORD       cRDN;
    PCERT_RDN   rgRDN;
} CERT_NAME_INFO, *PCERT_NAME_INFO;

typedef struct _CERT_NAME_VALUE {
    DWORD               dwValueType;
    CERT_RDN_VALUE_BLOB Value;
} CERT_NAME_VALUE, *PCERT_NAME_VALUE;

typedef struct _CERT_PUBLIC_KEY_INFO {
    CRYPT_ALGORITHM_IDENTIFIER    Algorithm;
    CRYPT_BIT_BLOB                PublicKey;
} CERT_PUBLIC_KEY_INFO, *PCERT_PUBLIC_KEY_INFO;

#define CERT_RSA_PUBLIC_KEY_OBJID            szOID_RSA_RSA
#define CERT_DEFAULT_OID_PUBLIC_KEY_SIGN     szOID_RSA_RSA
#define CERT_DEFAULT_OID_PUBLIC_KEY_XCHG     szOID_RSA_RSA

typedef struct _CRYPT_PRIVATE_KEY_INFO{
    DWORD                       Version;
    CRYPT_ALGORITHM_IDENTIFIER  Algorithm;
    CRYPT_DER_BLOB              PrivateKey;
    PCRYPT_ATTRIBUTES           pAttributes;
}  CRYPT_PRIVATE_KEY_INFO, *PCRYPT_PRIVATE_KEY_INFO;

typedef struct _CRYPT_ENCRYPTED_PRIVATE_KEY_INFO{
    CRYPT_ALGORITHM_IDENTIFIER  EncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedPrivateKey;
} CRYPT_ENCRYPTED_PRIVATE_KEY_INFO, *PCRYPT_ENCRYPTED_PRIVATE_KEY_INFO;

typedef BOOL (CALLBACK *PCRYPT_DECRYPT_PRIVATE_KEY_FUNC)(
                                                        CRYPT_ALGORITHM_IDENTIFIER  Algorithm,
                                                        CRYPT_DATA_BLOB             EncryptedPrivateKey,
                                                        BYTE                        *pbClearTextKey,
                                                        DWORD                       *pcbClearTextKey,
                                                        LPVOID                      pVoidDecryptFunc);

typedef BOOL (CALLBACK *PCRYPT_ENCRYPT_PRIVATE_KEY_FUNC)(
                                                        CRYPT_ALGORITHM_IDENTIFIER* pAlgorithm,
                                                        CRYPT_DATA_BLOB*            pClearTextPrivateKey,
                                                        BYTE                        *pbEncryptedKey,
                                                        DWORD                       *pcbEncryptedKey,
                                                        LPVOID                      pVoidEncryptFunc);

typedef BOOL (CALLBACK *PCRYPT_RESOLVE_HCRYPTPROV_FUNC)(
                                                       CRYPT_PRIVATE_KEY_INFO      *pPrivateKeyInfo,
                                                       HCRYPTPROV                  *phCryptProv,
                                                       LPVOID                      pVoidResolveFunc);

typedef struct _CRYPT_PKCS8_IMPORT_PARAMS{
    CRYPT_DIGEST_BLOB               PrivateKey;
    PCRYPT_RESOLVE_HCRYPTPROV_FUNC  pResolvehCryptProvFunc;
    LPVOID                          pVoidResolveFunc;
    PCRYPT_DECRYPT_PRIVATE_KEY_FUNC pDecryptPrivateKeyFunc;
    LPVOID                          pVoidDecryptFunc;
} CRYPT_PKCS8_IMPORT_PARAMS, *PCRYPT_PKCS8_IMPORT_PARAMS, CRYPT_PRIVATE_KEY_BLOB_AND_PARAMS, *PCRYPT_PRIVATE_KEY_BLOB_AND_PARAMS;

typedef struct _CRYPT_PKCS8_EXPORT_PARAMS{
    HCRYPTPROV                      hCryptProv;
    DWORD                           dwKeySpec;
    LPSTR                           pszPrivateKeyObjId;

    PCRYPT_ENCRYPT_PRIVATE_KEY_FUNC pEncryptPrivateKeyFunc;
    LPVOID                          pVoidEncryptFunc;
} CRYPT_PKCS8_EXPORT_PARAMS, *PCRYPT_PKCS8_EXPORT_PARAMS;

typedef struct _CERT_INFO {
    DWORD                       dwVersion;
    CRYPT_INTEGER_BLOB          SerialNumber;
    CRYPT_ALGORITHM_IDENTIFIER  SignatureAlgorithm;
    CERT_NAME_BLOB              Issuer;
    FILETIME                    NotBefore;
    FILETIME                    NotAfter;
    CERT_NAME_BLOB              Subject;
    CERT_PUBLIC_KEY_INFO        SubjectPublicKeyInfo;
    CRYPT_BIT_BLOB              IssuerUniqueId;
    CRYPT_BIT_BLOB              SubjectUniqueId;
    DWORD                       cExtension;
    PCERT_EXTENSION             rgExtension;
} CERT_INFO, *PCERT_INFO;

#define CERT_V1     0
#define CERT_V2     1
#define CERT_V3     2

#define CERT_INFO_VERSION_FLAG                      1
#define CERT_INFO_SERIAL_NUMBER_FLAG                2
#define CERT_INFO_SIGNATURE_ALGORITHM_FLAG          3
#define CERT_INFO_ISSUER_FLAG                       4
#define CERT_INFO_NOT_BEFORE_FLAG                   5
#define CERT_INFO_NOT_AFTER_FLAG                    6
#define CERT_INFO_SUBJECT_FLAG                      7
#define CERT_INFO_SUBJECT_PUBLIC_KEY_INFO_FLAG      8
#define CERT_INFO_ISSUER_UNIQUE_ID_FLAG             9
#define CERT_INFO_SUBJECT_UNIQUE_ID_FLAG            10
#define CERT_INFO_EXTENSION_FLAG                    11

typedef struct _CRL_ENTRY {
    CRYPT_INTEGER_BLOB  SerialNumber;
    FILETIME            RevocationDate;
    DWORD               cExtension;
    PCERT_EXTENSION     rgExtension;
} CRL_ENTRY, *PCRL_ENTRY;

typedef struct _CRL_INFO {
    DWORD                       dwVersion;
    CRYPT_ALGORITHM_IDENTIFIER  SignatureAlgorithm;
    CERT_NAME_BLOB              Issuer;
    FILETIME                    ThisUpdate;
    FILETIME                    NextUpdate;
    DWORD                       cCRLEntry;
    PCRL_ENTRY                  rgCRLEntry;
    DWORD                       cExtension;
    PCERT_EXTENSION             rgExtension;
} CRL_INFO, *PCRL_INFO;

#define CRL_V1     0
#define CRL_V2     1

typedef struct _CERT_REQUEST_INFO {
    DWORD                   dwVersion;
    CERT_NAME_BLOB          Subject;
    CERT_PUBLIC_KEY_INFO    SubjectPublicKeyInfo;
    DWORD                   cAttribute;
    PCRYPT_ATTRIBUTE        rgAttribute;
} CERT_REQUEST_INFO, *PCERT_REQUEST_INFO;

#define CERT_REQUEST_V1     0

typedef struct _CERT_KEYGEN_REQUEST_INFO {
    DWORD                   dwVersion;
    CERT_PUBLIC_KEY_INFO    SubjectPublicKeyInfo;
    LPWSTR                  pwszChallengeString;
} CERT_KEYGEN_REQUEST_INFO, *PCERT_KEYGEN_REQUEST_INFO;

#define CERT_KEYGEN_REQUEST_V1     0

typedef struct _CERT_SIGNED_CONTENT_INFO {
    CRYPT_DER_BLOB              ToBeSigned;
    CRYPT_ALGORITHM_IDENTIFIER  SignatureAlgorithm;
    CRYPT_BIT_BLOB              Signature;
} CERT_SIGNED_CONTENT_INFO, *PCERT_SIGNED_CONTENT_INFO;

typedef struct _CTL_USAGE {
    DWORD               cUsageIdentifier;
    LPSTR               *rgpszUsageIdentifier;
} CTL_USAGE, *PCTL_USAGE,
CERT_ENHKEY_USAGE, *PCERT_ENHKEY_USAGE;

typedef struct _CTL_ENTRY {
    CRYPT_DATA_BLOB     SubjectIdentifier;
    DWORD               cAttribute;
    PCRYPT_ATTRIBUTE    rgAttribute;
} CTL_ENTRY, *PCTL_ENTRY;

typedef struct _CTL_INFO {
    DWORD                       dwVersion;
    CTL_USAGE                   SubjectUsage;
    CRYPT_DATA_BLOB             ListIdentifier;
    CRYPT_INTEGER_BLOB          SequenceNumber;
    FILETIME                    ThisUpdate;
    FILETIME                    NextUpdate;
    CRYPT_ALGORITHM_IDENTIFIER  SubjectAlgorithm;
    DWORD                       cCTLEntry;
    PCTL_ENTRY                  rgCTLEntry;
    DWORD                       cExtension;
    PCERT_EXTENSION             rgExtension;
} CTL_INFO, *PCTL_INFO;

#define CTL_V1     0

typedef struct _CRYPT_TIME_STAMP_REQUEST_INFO {
    LPSTR                   pszTimeStampAlgorithm;
    LPSTR                   pszContentType;
    CRYPT_OBJID_BLOB        Content;
    DWORD                   cAttribute;
    PCRYPT_ATTRIBUTE        rgAttribute;
} CRYPT_TIME_STAMP_REQUEST_INFO, *PCRYPT_TIME_STAMP_REQUEST_INFO;

typedef struct _CRYPT_ENROLLMENT_NAME_VALUE_PAIR {
    LPWSTR      pwszName;
    LPWSTR      pwszValue;
} CRYPT_ENROLLMENT_NAME_VALUE_PAIR, * PCRYPT_ENROLLMENT_NAME_VALUE_PAIR;

typedef struct _CRYPT_CSP_PROVIDER {
    DWORD           dwKeySpec;
    LPWSTR          pwszProviderName;
    CRYPT_BIT_BLOB  Signature;
} CRYPT_CSP_PROVIDER, * PCRYPT_CSP_PROVIDER;

#define CERT_ENCODING_TYPE_MASK     0x0000FFFF
#define CMSG_ENCODING_TYPE_MASK     0xFFFF0000
#define GET_CERT_ENCODING_TYPE(X)   (X & CERT_ENCODING_TYPE_MASK)
#define GET_CMSG_ENCODING_TYPE(X)   (X & CMSG_ENCODING_TYPE_MASK)

#define CRYPT_ASN_ENCODING          0x00000001
#define CRYPT_NDR_ENCODING          0x00000002
#define X509_ASN_ENCODING           0x00000001
#define X509_NDR_ENCODING           0x00000002
#define PKCS_7_ASN_ENCODING         0x00010000
#define PKCS_7_NDR_ENCODING         0x00020000

WINCRYPT32API
BOOL
WINAPI
CryptFormatObject(
    DWORD dwCertEncodingType,
    DWORD dwFormatType,
    DWORD dwFormatStrType,
    void  *pFormatStruct,
    LPCSTR lpszStructType,
    const BYTE *pbEncoded,
    DWORD cbEncoded,
    void *pbFormat,
    DWORD *pcbFormat
    );

#define         CRYPT_FORMAT_STR_MULTI_LINE         0x0001
#define         CRYPT_FORMAT_STR_NO_HEX             0x0010
#define         CRYPT_FORMAT_SIMPLE                 0x0001
#define         CRYPT_FORMAT_X509                   0x0002
#define         CRYPT_FORMAT_OID                    0x0004
#define         CRYPT_FORMAT_RDN_SEMICOLON          0x0100
#define         CRYPT_FORMAT_RDN_CRLF               0x0200
#define         CRYPT_FORMAT_RDN_UNQUOTE            0x0400
#define         CRYPT_FORMAT_RDN_REVERSE            0x0800
#define         CRYPT_FORMAT_COMMA                  0x1000
#define         CRYPT_FORMAT_SEMICOLON              CRYPT_FORMAT_RDN_SEMICOLON
#define         CRYPT_FORMAT_CRLF                   CRYPT_FORMAT_RDN_CRLF

typedef LPVOID (WINAPI *PFN_CRYPT_ALLOC)(
    size_t cbSize
    );

typedef VOID (WINAPI *PFN_CRYPT_FREE)(
    LPVOID pv
    );


typedef struct _CRYPT_ENCODE_PARA {
    DWORD                   cbSize;
    PFN_CRYPT_ALLOC         pfnAlloc;
    PFN_CRYPT_FREE          pfnFree;
} CRYPT_ENCODE_PARA, *PCRYPT_ENCODE_PARA;


WINCRYPT32API
BOOL
WINAPI
CryptEncodeObjectEx(
    DWORD dwCertEncodingType,
    LPCSTR lpszStructType,
    const void *pvStructInfo,
    DWORD dwFlags,
    OPTIONAL PCRYPT_ENCODE_PARA pEncodePara,
    void *pvEncoded,
    DWORD *pcbEncoded
    );

WINCRYPT32API
BOOL
WINAPI
CryptEncodeObject(
    DWORD        dwCertEncodingType,
    LPCSTR       lpszStructType,
    const void   *pvStructInfo,
    BYTE        *pbEncoded,
    DWORD    *pcbEncoded
    );

#define CRYPT_ENCODE_NO_SIGNATURE_BYTE_REVERSAL_FLAG    0x8
#define CRYPT_ENCODE_ALLOC_FLAG             0x8000
#define CRYPT_UNICODE_NAME_ENCODE_ENABLE_T61_UNICODE_FLAG   \
            CERT_RDN_ENABLE_T61_UNICODE_FLAG
#define CRYPT_UNICODE_NAME_ENCODE_ENABLE_UTF8_UNICODE_FLAG   \
            CERT_RDN_ENABLE_UTF8_UNICODE_FLAG
#define CRYPT_UNICODE_NAME_ENCODE_DISABLE_CHECK_TYPE_FLAG   \
            CERT_RDN_DISABLE_CHECK_TYPE_FLAG
#define CRYPT_SORTED_CTL_ENCODE_HASHED_SUBJECT_IDENTIFIER_FLAG     0x10000

typedef struct _CRYPT_DECODE_PARA {
    DWORD                   cbSize;
    PFN_CRYPT_ALLOC         pfnAlloc;
    PFN_CRYPT_FREE          pfnFree;
} CRYPT_DECODE_PARA, *PCRYPT_DECODE_PARA;

WINCRYPT32API
BOOL
WINAPI
CryptDecodeObjectEx(
    DWORD dwCertEncodingType,
    LPCSTR lpszStructType,
    const BYTE *pbEncoded,
    DWORD cbEncoded,
    DWORD dwFlags,
    OPTIONAL PCRYPT_DECODE_PARA pDecodePara,
    OPTIONAL void *pvStructInfo,
    DWORD *pcbStructInfo
    );


WINCRYPT32API
BOOL
WINAPI
CryptDecodeObject(
    DWORD        dwCertEncodingType,
    LPCSTR       lpszStructType,
    const BYTE   *pbEncoded,
    DWORD        cbEncoded,
    DWORD        dwFlags,
    void        *pvStructInfo,
    DWORD    *pcbStructInfo
    );

#define CRYPT_DECODE_NOCOPY_FLAG            0x1
#define CRYPT_DECODE_TO_BE_SIGNED_FLAG      0x2
#define CRYPT_DECODE_SHARE_OID_STRING_FLAG  0x4
#define CRYPT_DECODE_NO_SIGNATURE_BYTE_REVERSAL_FLAG    0x8
#define CRYPT_DECODE_ALLOC_FLAG             0x8000
#define CRYPT_UNICODE_NAME_DECODE_DISABLE_IE4_UTF8_FLAG     \
            CERT_RDN_DISABLE_IE4_UTF8_FLAG

#define CRYPT_ENCODE_DECODE_NONE            0
#define X509_CERT                           ((LPCSTR) 1)
#define X509_CERT_TO_BE_SIGNED              ((LPCSTR) 2)
#define X509_CERT_CRL_TO_BE_SIGNED          ((LPCSTR) 3)
#define X509_CERT_REQUEST_TO_BE_SIGNED      ((LPCSTR) 4)
#define X509_EXTENSIONS                     ((LPCSTR) 5)
#define X509_NAME_VALUE                     ((LPCSTR) 6)
#define X509_NAME                           ((LPCSTR) 7)
#define X509_PUBLIC_KEY_INFO                ((LPCSTR) 8)
#define X509_AUTHORITY_KEY_ID               ((LPCSTR) 9)
#define X509_KEY_ATTRIBUTES                 ((LPCSTR) 10)
#define X509_KEY_USAGE_RESTRICTION          ((LPCSTR) 11)
#define X509_ALTERNATE_NAME                 ((LPCSTR) 12)
#define X509_BASIC_CONSTRAINTS              ((LPCSTR) 13)
#define X509_KEY_USAGE                      ((LPCSTR) 14)
#define X509_BASIC_CONSTRAINTS2             ((LPCSTR) 15)
#define X509_CERT_POLICIES                  ((LPCSTR) 16)

#define PKCS_UTC_TIME                       ((LPCSTR) 17)
#define PKCS_TIME_REQUEST                   ((LPCSTR) 18)
#define RSA_CSP_PUBLICKEYBLOB               ((LPCSTR) 19)
#define X509_UNICODE_NAME                   ((LPCSTR) 20)
#define X509_KEYGEN_REQUEST_TO_BE_SIGNED    ((LPCSTR) 21)
#define PKCS_ATTRIBUTE                      ((LPCSTR) 22)
#define PKCS_CONTENT_INFO_SEQUENCE_OF_ANY   ((LPCSTR) 23)

#define X509_UNICODE_NAME_VALUE             ((LPCSTR) 24)
#define X509_ANY_STRING                     X509_NAME_VALUE
#define X509_UNICODE_ANY_STRING             X509_UNICODE_NAME_VALUE
#define X509_OCTET_STRING                   ((LPCSTR) 25)
#define X509_BITS                           ((LPCSTR) 26)
#define X509_INTEGER                        ((LPCSTR) 27)
#define X509_MULTI_BYTE_INTEGER             ((LPCSTR) 28)
#define X509_ENUMERATED                     ((LPCSTR) 29)
#define X509_CHOICE_OF_TIME                 ((LPCSTR) 30)
#define X509_AUTHORITY_KEY_ID2              ((LPCSTR) 31)
#define X509_AUTHORITY_INFO_ACCESS          ((LPCSTR) 32)
#define X509_CRL_REASON_CODE                X509_ENUMERATED
#define PKCS_CONTENT_INFO                   ((LPCSTR) 33)
#define X509_SEQUENCE_OF_ANY                ((LPCSTR) 34)
#define X509_CRL_DIST_POINTS                ((LPCSTR) 35)
#define X509_ENHANCED_KEY_USAGE             ((LPCSTR) 36)
#define PKCS_CTL                            ((LPCSTR) 37)

#define X509_MULTI_BYTE_UINT                ((LPCSTR) 38)
#define X509_DSS_PUBLICKEY                  X509_MULTI_BYTE_UINT
#define X509_DSS_PARAMETERS                 ((LPCSTR) 39)
#define X509_DSS_SIGNATURE                  ((LPCSTR) 40)
#define PKCS_RC2_CBC_PARAMETERS             ((LPCSTR) 41)
#define PKCS_SMIME_CAPABILITIES             ((LPCSTR) 42)
#define PKCS_RSA_PRIVATE_KEY                ((LPCSTR) 43)
#define PKCS_PRIVATE_KEY_INFO               ((LPCSTR) 44)
#define PKCS_ENCRYPTED_PRIVATE_KEY_INFO     ((LPCSTR) 45)

#define X509_PKIX_POLICY_QUALIFIER_USERNOTICE ((LPCSTR) 46)
#define X509_DH_PUBLICKEY                   X509_MULTI_BYTE_UINT
#define X509_DH_PARAMETERS                  ((LPCSTR) 47)
#define PKCS_ATTRIBUTES                     ((LPCSTR) 48)
#define PKCS_SORTED_CTL                     ((LPCSTR) 49)

#define X942_DH_PARAMETERS                  ((LPCSTR) 50)
#define X509_BITS_WITHOUT_TRAILING_ZEROES   ((LPCSTR) 51)

//+-------------------------------------------------------------------------
//  X942 Diffie-Hellman Other Info
//--------------------------------------------------------------------------
#define X942_OTHER_INFO                     ((LPCSTR) 52)

#define CMS_SIGNER_INFO                     ((LPCSTR) 501)

#define szOID_AUTHORITY_KEY_IDENTIFIER  "2.5.29.1"
#define szOID_KEY_ATTRIBUTES            "2.5.29.2"
#define szOID_CERT_POLICIES_95          "2.5.29.3"
#define szOID_KEY_USAGE_RESTRICTION     "2.5.29.4"
#define szOID_SUBJECT_ALT_NAME          "2.5.29.7"
#define szOID_ISSUER_ALT_NAME           "2.5.29.8"
#define szOID_BASIC_CONSTRAINTS         "2.5.29.10"
#define szOID_KEY_USAGE                 "2.5.29.15"
#define szOID_PRIVATEKEY_USAGE_PERIOD   "2.5.29.16"
#define szOID_BASIC_CONSTRAINTS2        "2.5.29.19"
#define szOID_CERT_POLICIES             "2.5.29.32"
#define szOID_AUTHORITY_KEY_IDENTIFIER2 "2.5.29.35"
#define szOID_SUBJECT_KEY_IDENTIFIER    "2.5.29.14"
#define szOID_SUBJECT_ALT_NAME2         "2.5.29.17"
#define szOID_ISSUER_ALT_NAME2          "2.5.29.18"
#define szOID_CRL_REASON_CODE           "2.5.29.21"
#define szOID_CRL_DIST_POINTS           "2.5.29.31"
#define szOID_ENHANCED_KEY_USAGE        "2.5.29.37"
#define szOID_RENEWAL_CERTIFICATE	    "1.3.6.1.4.1.311.13.1"
#define szOID_ENROLLMENT_NAME_VALUE_PAIR    "1.3.6.1.4.1.311.13.2.1"
#define szOID_ENROLLMENT_CSP_PROVIDER	    "1.3.6.1.4.1.311.13.2.2"
#define szOID_OS_VERSION        	    "1.3.6.1.4.1.311.13.2.3"
#define szOID_ENROLLMENT_AGENT		    "1.3.6.1.4.1.311.20.2.1"
#define szOID_PKIX                      "1.3.6.1.5.5.7"
#define szOID_PKIX_PE                   "1.3.6.1.5.5.7.1"
#define szOID_AUTHORITY_INFO_ACCESS     "1.3.6.1.5.5.7.1.1"
#define szOID_CERT_EXTENSIONS           "1.3.6.1.4.1.311.2.1.14"
#define szOID_NEXT_UPDATE_LOCATION      "1.3.6.1.4.1.311.10.2"
#define szOID_CTL                       "1.3.6.1.4.1.311.10.1"
#define szOID_SORTED_CTL                "1.3.6.1.4.1.311.10.1.1"
#ifndef szOID_SERIALIZED
#define szOID_SERIALIZED		"1.3.6.1.4.1.311.10.3.3.1"
#endif

#ifndef szOID_NT_PRINCIPAL_NAME
#define szOID_NT_PRINCIPAL_NAME 	"1.3.6.1.4.1.311.20.2.3"
#endif
#ifndef szOID_PRODUCT_UPDATE
#define szOID_PRODUCT_UPDATE		"1.3.6.1.4.1.311.31.1"
#endif
#define szOID_AUTO_ENROLL_CTL_USAGE	"1.3.6.1.4.1.311.20.1"
#define szOID_ENROLL_CERTTYPE_EXTENSION "1.3.6.1.4.1.311.20.2"
#define szOID_CERT_MANIFOLD             "1.3.6.1.4.1.311.20.3"
#ifndef szOID_CERTSRV_CA_VERSION
#define szOID_CERTSRV_CA_VERSION	"1.3.6.1.4.1.311.21.1"
#endif

#define szOID_NTDS_REPLICATION	    "1.3.6.1.4.1.311.25.1"
#define szOID_POLICY_MAPPINGS           "2.5.29.5"
#define szOID_SUBJECT_DIR_ATTRS         "2.5.29.9"
#define szOID_PKIX_KP                   "1.3.6.1.5.5.7.3"
#define szOID_PKIX_KP_SERVER_AUTH       "1.3.6.1.5.5.7.3.1"
#define szOID_PKIX_KP_CLIENT_AUTH       "1.3.6.1.5.5.7.3.2"
#define szOID_PKIX_KP_CODE_SIGNING      "1.3.6.1.5.5.7.3.3"
#define szOID_PKIX_KP_EMAIL_PROTECTION  "1.3.6.1.5.5.7.3.4"
#define szOID_PKIX_KP_IPSEC_END_SYSTEM  "1.3.6.1.5.5.7.3.5"
#define szOID_PKIX_KP_IPSEC_TUNNEL      "1.3.6.1.5.5.7.3.6"
#define szOID_PKIX_KP_IPSEC_USER        "1.3.6.1.5.5.7.3.7"
#define szOID_PKIX_KP_TIMESTAMP_SIGNING "1.3.6.1.5.5.7.3.8"
#define szOID_KP_CTL_USAGE_SIGNING      "1.3.6.1.4.1.311.10.3.1"
#define szOID_KP_TIME_STAMP_SIGNING     "1.3.6.1.4.1.311.10.3.2"
#ifndef szOID_SERVER_GATED_CRYPTO
#define szOID_SERVER_GATED_CRYPTO       "1.3.6.1.4.1.311.10.3.3"
#endif
#ifndef szOID_SGC_NETSCAPE
#define szOID_SGC_NETSCAPE              "2.16.840.1.113730.4.1"
#endif
#define szOID_KP_EFS			"1.3.6.1.4.1.311.10.3.4"
#define szOID_WHQL_CRYPTO		"1.3.6.1.4.1.311.10.3.5"
#define szOID_NT5_CRYPTO		"1.3.6.1.4.1.311.10.3.6"
#define szOID_OEM_WHQL_CRYPTO		"1.3.6.1.4.1.311.10.3.7"
#define szOID_EMBEDDED_NT_CRYPTO	"1.3.6.1.4.1.311.10.3.8"
#ifndef szOID_DRM
#define szOID_DRM			"1.3.6.1.4.1.311.10.5.1"
#endif
#ifndef szOID_LICENSES
#define szOID_LICENSES			"1.3.6.1.4.1.311.10.6.1"
#endif
#ifndef szOID_LICENSE_SERVER
#define szOID_LICENSE_SERVER		"1.3.6.1.4.1.311.10.6.2"
#endif
#ifndef szOID_KP_SMARTCARD_LOGON
#define szOID_KP_SMARTCARD_LOGON	"1.3.6.1.4.1.311.20.2.2"
#endif
#define szOID_YESNO_TRUST_ATTR          "1.3.6.1.4.1.311.10.4.1"
#define szOID_PKIX_POLICY_QUALIFIER_CPS               "1.3.6.1.5.5.7.2.1"
#define szOID_PKIX_POLICY_QUALIFIER_USERNOTICE        "1.3.6.1.5.5.7.2.2"

// OID for old qualifer
#define szOID_CERT_POLICIES_95_QUALIFIER1             "2.16.840.1.113733.1.7.1.1"

typedef struct _CERT_EXTENSIONS {
    DWORD           cExtension;
    PCERT_EXTENSION rgExtension;
} CERT_EXTENSIONS, *PCERT_EXTENSIONS;

#define CERT_UNICODE_RDN_ERR_INDEX_MASK     0x3FF
#define CERT_UNICODE_RDN_ERR_INDEX_SHIFT    22
#define CERT_UNICODE_ATTR_ERR_INDEX_MASK    0x003F
#define CERT_UNICODE_ATTR_ERR_INDEX_SHIFT   16
#define CERT_UNICODE_VALUE_ERR_INDEX_MASK   0x0000FFFF
#define CERT_UNICODE_VALUE_ERR_INDEX_SHIFT  0

#define GET_CERT_UNICODE_RDN_ERR_INDEX(X)   \
    ((X >> CERT_UNICODE_RDN_ERR_INDEX_SHIFT) & CERT_UNICODE_RDN_ERR_INDEX_MASK)
#define GET_CERT_UNICODE_ATTR_ERR_INDEX(X)  \
    ((X >> CERT_UNICODE_ATTR_ERR_INDEX_SHIFT) & CERT_UNICODE_ATTR_ERR_INDEX_MASK)
#define GET_CERT_UNICODE_VALUE_ERR_INDEX(X) \
    (X & CERT_UNICODE_VALUE_ERR_INDEX_MASK)

typedef struct _CERT_AUTHORITY_KEY_ID_INFO {
    CRYPT_DATA_BLOB     KeyId;
    CERT_NAME_BLOB      CertIssuer;
    CRYPT_INTEGER_BLOB  CertSerialNumber;
} CERT_AUTHORITY_KEY_ID_INFO, *PCERT_AUTHORITY_KEY_ID_INFO;

typedef struct _CERT_PRIVATE_KEY_VALIDITY {
    FILETIME            NotBefore;
    FILETIME            NotAfter;
} CERT_PRIVATE_KEY_VALIDITY, *PCERT_PRIVATE_KEY_VALIDITY;

typedef struct _CERT_KEY_ATTRIBUTES_INFO {
    CRYPT_DATA_BLOB             KeyId;
    CRYPT_BIT_BLOB              IntendedKeyUsage;
    PCERT_PRIVATE_KEY_VALIDITY  pPrivateKeyUsagePeriod;     // OPTIONAL
} CERT_KEY_ATTRIBUTES_INFO, *PCERT_KEY_ATTRIBUTES_INFO;

#define CERT_DIGITAL_SIGNATURE_KEY_USAGE     0x80
#define CERT_NON_REPUDIATION_KEY_USAGE       0x40
#define CERT_KEY_ENCIPHERMENT_KEY_USAGE      0x20
#define CERT_DATA_ENCIPHERMENT_KEY_USAGE     0x10
#define CERT_KEY_AGREEMENT_KEY_USAGE         0x08
#define CERT_KEY_CERT_SIGN_KEY_USAGE         0x04
#define CERT_OFFLINE_CRL_SIGN_KEY_USAGE      0x02
#define CERT_CRL_SIGN_KEY_USAGE              0x02
#define CERT_ENCIPHER_ONLY_KEY_USAGE         0x01
#define CERT_DECIPHER_ONLY_KEY_USAGE         0x80

typedef struct _CERT_POLICY_ID {
    DWORD                   cCertPolicyElementId;
    LPSTR                   *rgpszCertPolicyElementId;  // pszObjId
} CERT_POLICY_ID, *PCERT_POLICY_ID;

typedef struct _CERT_KEY_USAGE_RESTRICTION_INFO {
    DWORD                   cCertPolicyId;
    PCERT_POLICY_ID         rgCertPolicyId;
    CRYPT_BIT_BLOB          RestrictedKeyUsage;
} CERT_KEY_USAGE_RESTRICTION_INFO, *PCERT_KEY_USAGE_RESTRICTION_INFO;

typedef struct _CERT_OTHER_NAME {
    LPSTR               pszObjId;
    CRYPT_OBJID_BLOB    Value;
} CERT_OTHER_NAME, *PCERT_OTHER_NAME;

typedef struct _CERT_ALT_NAME_ENTRY {
    DWORD   dwAltNameChoice;
    union {
        PCERT_OTHER_NAME            pOtherName;
        LPWSTR                      pwszRfc822Name;
        LPWSTR                      pwszDNSName;
        CERT_NAME_BLOB              DirectoryName;
        LPWSTR                      pwszURL;
        CRYPT_DATA_BLOB             IPAddress;
        LPSTR                       pszRegisteredID;
    };
} CERT_ALT_NAME_ENTRY, *PCERT_ALT_NAME_ENTRY;

#define CERT_ALT_NAME_OTHER_NAME         1
#define CERT_ALT_NAME_RFC822_NAME        2
#define CERT_ALT_NAME_DNS_NAME           3
#define CERT_ALT_NAME_X400_ADDRESS       4
#define CERT_ALT_NAME_DIRECTORY_NAME     5
#define CERT_ALT_NAME_EDI_PARTY_NAME     6
#define CERT_ALT_NAME_URL                7
#define CERT_ALT_NAME_IP_ADDRESS         8
#define CERT_ALT_NAME_REGISTERED_ID      9

typedef struct _CERT_ALT_NAME_INFO {
    DWORD                   cAltEntry;
    PCERT_ALT_NAME_ENTRY    rgAltEntry;
} CERT_ALT_NAME_INFO, *PCERT_ALT_NAME_INFO;

#define CERT_ALT_NAME_ENTRY_ERR_INDEX_MASK  0xFF
#define CERT_ALT_NAME_ENTRY_ERR_INDEX_SHIFT 16
#define CERT_ALT_NAME_VALUE_ERR_INDEX_MASK  0x0000FFFF
#define CERT_ALT_NAME_VALUE_ERR_INDEX_SHIFT 0

#define GET_CERT_ALT_NAME_ENTRY_ERR_INDEX(X)   \
    ((X >> CERT_ALT_NAME_ENTRY_ERR_INDEX_SHIFT) & \
    CERT_ALT_NAME_ENTRY_ERR_INDEX_MASK)
#define GET_CERT_ALT_NAME_VALUE_ERR_INDEX(X) \
    (X & CERT_ALT_NAME_VALUE_ERR_INDEX_MASK)

typedef struct _CERT_BASIC_CONSTRAINTS_INFO {
    CRYPT_BIT_BLOB          SubjectType;
    BOOL                    fPathLenConstraint;
    DWORD                   dwPathLenConstraint;
    DWORD                   cSubtreesConstraint;
    CERT_NAME_BLOB          *rgSubtreesConstraint;
} CERT_BASIC_CONSTRAINTS_INFO, *PCERT_BASIC_CONSTRAINTS_INFO;

#define CERT_CA_SUBJECT_FLAG         0x80
#define CERT_END_ENTITY_SUBJECT_FLAG 0x40

typedef struct _CERT_BASIC_CONSTRAINTS2_INFO {
    BOOL                    fCA;
    BOOL                    fPathLenConstraint;
    DWORD                   dwPathLenConstraint;
} CERT_BASIC_CONSTRAINTS2_INFO, *PCERT_BASIC_CONSTRAINTS2_INFO;

typedef struct _CERT_POLICY_QUALIFIER_INFO {
    LPSTR                       pszPolicyQualifierId;
    CRYPT_OBJID_BLOB            Qualifier;
} CERT_POLICY_QUALIFIER_INFO, *PCERT_POLICY_QUALIFIER_INFO;

typedef struct _CERT_POLICY_INFO {
    LPSTR                       pszPolicyIdentifier;
    DWORD                       cPolicyQualifier;
    CERT_POLICY_QUALIFIER_INFO  *rgPolicyQualifier;
} CERT_POLICY_INFO, *PCERT_POLICY_INFO;

typedef struct _CERT_POLICIES_INFO {
    DWORD                       cPolicyInfo;
    CERT_POLICY_INFO            *rgPolicyInfo;
} CERT_POLICIES_INFO, *PCERT_POLICIES_INFO;

typedef struct _CERT_POLICY_QUALIFIER_NOTICE_REFERENCE {
    LPSTR   pszOrganization;
    DWORD   cNoticeNumbers;
    int     *rgNoticeNumbers;
} CERT_POLICY_QUALIFIER_NOTICE_REFERENCE, *PCERT_POLICY_QUALIFIER_NOTICE_REFERENCE;

typedef struct _CERT_POLICY_QUALIFIER_USER_NOTICE {
    CERT_POLICY_QUALIFIER_NOTICE_REFERENCE  *pNoticeReference;  // optional
    LPWSTR                                  pszDisplayText;     // optional
} CERT_POLICY_QUALIFIER_USER_NOTICE, *PCERT_POLICY_QUALIFIER_USER_NOTICE;

typedef struct _CPS_URLS {
    LPWSTR                      pszURL;
    CRYPT_ALGORITHM_IDENTIFIER  *pAlgorithm; // optional
    CRYPT_DATA_BLOB             *pDigest;    // optional
} CPS_URLS, *PCPS_URLS;

typedef struct _CERT_POLICY95_QUALIFIER1 {
    LPWSTR      pszPracticesReference;      // optional
    LPSTR       pszNoticeIdentifier;        // optional
    LPSTR       pszNSINoticeIdentifier;     // optional
    DWORD       cCPSURLs;
    CPS_URLS    *rgCPSURLs;                 // optional
} CERT_POLICY95_QUALIFIER1, *PCERT_POLICY95_QUALIFIER1;

typedef struct _CRYPT_CONTENT_INFO_SEQUENCE_OF_ANY {
    LPSTR               pszObjId;
    DWORD               cValue;
    PCRYPT_DER_BLOB     rgValue;
} CRYPT_CONTENT_INFO_SEQUENCE_OF_ANY, *PCRYPT_CONTENT_INFO_SEQUENCE_OF_ANY;

typedef struct _CRYPT_CONTENT_INFO {
    LPSTR               pszObjId;
    CRYPT_DER_BLOB      Content;
} CRYPT_CONTENT_INFO, *PCRYPT_CONTENT_INFO;

typedef struct _CRYPT_SEQUENCE_OF_ANY {
    DWORD               cValue;
    PCRYPT_DER_BLOB     rgValue;
} CRYPT_SEQUENCE_OF_ANY, *PCRYPT_SEQUENCE_OF_ANY;

typedef struct _CERT_AUTHORITY_KEY_ID2_INFO {
    CRYPT_DATA_BLOB     KeyId;
    CERT_ALT_NAME_INFO  AuthorityCertIssuer;
    CRYPT_INTEGER_BLOB  AuthorityCertSerialNumber;
} CERT_AUTHORITY_KEY_ID2_INFO, *PCERT_AUTHORITY_KEY_ID2_INFO;

typedef struct _CERT_ACCESS_DESCRIPTION {
    LPSTR               pszAccessMethod;
    CERT_ALT_NAME_ENTRY AccessLocation;
} CERT_ACCESS_DESCRIPTION, *PCERT_ACCESS_DESCRIPTION;


typedef struct _CERT_AUTHORITY_INFO_ACCESS {
    DWORD                       cAccDescr;
    PCERT_ACCESS_DESCRIPTION    rgAccDescr;
} CERT_AUTHORITY_INFO_ACCESS, *PCERT_AUTHORITY_INFO_ACCESS;

#define szOID_PKIX_ACC_DESCR            "1.3.6.1.5.5.7.48"
#define szOID_PKIX_OCSP                 "1.3.6.1.5.5.7.48.1"
#define szOID_PKIX_CA_ISSUERS           "1.3.6.1.5.5.7.48.2"

#define CRL_REASON_UNSPECIFIED              0
#define CRL_REASON_KEY_COMPROMISE           1
#define CRL_REASON_CA_COMPROMISE            2
#define CRL_REASON_AFFILIATION_CHANGED      3
#define CRL_REASON_SUPERSEDED               4
#define CRL_REASON_CESSATION_OF_OPERATION   5
#define CRL_REASON_CERTIFICATE_HOLD         6
#define CRL_REASON_REMOVE_FROM_CRL          8

typedef struct _CRL_DIST_POINT_NAME {
    DWORD   dwDistPointNameChoice;
    union {
        CERT_ALT_NAME_INFO      FullName;
    };
} CRL_DIST_POINT_NAME, *PCRL_DIST_POINT_NAME;

#define CRL_DIST_POINT_NO_NAME          0
#define CRL_DIST_POINT_FULL_NAME        1
#define CRL_DIST_POINT_ISSUER_RDN_NAME  2

typedef struct _CRL_DIST_POINT {
    CRL_DIST_POINT_NAME     DistPointName;
    CRYPT_BIT_BLOB          ReasonFlags;
    CERT_ALT_NAME_INFO      CRLIssuer;
} CRL_DIST_POINT, *PCRL_DIST_POINT;

#define CRL_REASON_UNUSED_FLAG                  0x80
#define CRL_REASON_KEY_COMPROMISE_FLAG          0x40
#define CRL_REASON_CA_COMPROMISE_FLAG           0x20
#define CRL_REASON_AFFILIATION_CHANGED_FLAG     0x10
#define CRL_REASON_SUPERSEDED_FLAG              0x08
#define CRL_REASON_CESSATION_OF_OPERATION_FLAG  0x04
#define CRL_REASON_CERTIFICATE_HOLD_FLAG        0x02

typedef struct _CRL_DIST_POINTS_INFO {
    DWORD                   cDistPoint;
    PCRL_DIST_POINT         rgDistPoint;
} CRL_DIST_POINTS_INFO, *PCRL_DIST_POINTS_INFO;

#define CRL_DIST_POINT_ERR_INDEX_MASK          0x7F
#define CRL_DIST_POINT_ERR_INDEX_SHIFT         24
#define GET_CRL_DIST_POINT_ERR_INDEX(X)   \
    ((X >> CRL_DIST_POINT_ERR_INDEX_SHIFT) & CRL_DIST_POINT_ERR_INDEX_MASK)

#define CRL_DIST_POINT_ERR_CRL_ISSUER_BIT      0x80000000L
#define IS_CRL_DIST_POINT_ERR_CRL_ISSUER(X)   \
    (0 != (X & CRL_DIST_POINT_ERR_CRL_ISSUER_BIT))

#define SORTED_CTL_EXT_FLAGS_OFFSET         (0*4)
#define SORTED_CTL_EXT_COUNT_OFFSET         (1*4)
#define SORTED_CTL_EXT_MAX_COLLISION_OFFSET (2*4)
#define SORTED_CTL_EXT_HASH_BUCKET_OFFSET   (3*4)

#define SORTED_CTL_EXT_HASHED_SUBJECT_IDENTIFIER_FLAG       0x1

typedef struct _CERT_DSS_PARAMETERS {
    CRYPT_UINT_BLOB     p;
    CRYPT_UINT_BLOB     q;
    CRYPT_UINT_BLOB     g;
} CERT_DSS_PARAMETERS, *PCERT_DSS_PARAMETERS;

#define CERT_DSS_R_LEN          20
#define CERT_DSS_S_LEN          20
#define CERT_DSS_SIGNATURE_LEN  (CERT_DSS_R_LEN + CERT_DSS_S_LEN)
#define CERT_MAX_ASN_ENCODED_DSS_SIGNATURE_LEN  (2 + 2*(2 + 20 +1))

typedef struct _CERT_DH_PARAMETERS {
    CRYPT_UINT_BLOB     p;
    CRYPT_UINT_BLOB     g;
} CERT_DH_PARAMETERS, *PCERT_DH_PARAMETERS;

typedef struct _CERT_X942_DH_VALIDATION_PARAMS {
    CRYPT_BIT_BLOB      seed;
    DWORD               pgenCounter;
} CERT_X942_DH_VALIDATION_PARAMS, *PCERT_X942_DH_VALIDATION_PARAMS;

typedef struct _CERT_X942_DH_PARAMETERS {
    CRYPT_UINT_BLOB     p;
    CRYPT_UINT_BLOB     g;
    CRYPT_UINT_BLOB     q;
    CRYPT_UINT_BLOB     j;
    PCERT_X942_DH_VALIDATION_PARAMS pValidationParams;
} CERT_X942_DH_PARAMETERS, *PCERT_X942_DH_PARAMETERS;

#define CRYPT_X942_COUNTER_BYTE_LENGTH      4
#define CRYPT_X942_KEY_LENGTH_BYTE_LENGTH   4
#define CRYPT_X942_PUB_INFO_BYTE_LENGTH     (512/8)
typedef struct _CRYPT_X942_OTHER_INFO {
    LPSTR               pszContentEncryptionObjId;
    BYTE                rgbCounter[CRYPT_X942_COUNTER_BYTE_LENGTH];
    BYTE                rgbKeyLength[CRYPT_X942_KEY_LENGTH_BYTE_LENGTH];
    CRYPT_DATA_BLOB     PubInfo;
} CRYPT_X942_OTHER_INFO, *PCRYPT_X942_OTHER_INFO;

typedef struct _CRYPT_RC2_CBC_PARAMETERS {
    DWORD               dwVersion;
    BOOL                fIV;
    BYTE                rgbIV[8];
} CRYPT_RC2_CBC_PARAMETERS, *PCRYPT_RC2_CBC_PARAMETERS;

#define CRYPT_RC2_40BIT_VERSION     160
#define CRYPT_RC2_56BIT_VERSION     52
#define CRYPT_RC2_64BIT_VERSION     120
#define CRYPT_RC2_128BIT_VERSION    58

typedef struct _CRYPT_SMIME_CAPABILITY {
    LPSTR               pszObjId;
    CRYPT_OBJID_BLOB    Parameters;
} CRYPT_SMIME_CAPABILITY, *PCRYPT_SMIME_CAPABILITY;

typedef struct _CRYPT_SMIME_CAPABILITIES {
    DWORD                   cCapability;
    PCRYPT_SMIME_CAPABILITY rgCapability;
} CRYPT_SMIME_CAPABILITIES, *PCRYPT_SMIME_CAPABILITIES;

#define szOID_NETSCAPE                  "2.16.840.1.113730"
#define szOID_NETSCAPE_CERT_EXTENSION   "2.16.840.1.113730.1"
#define szOID_NETSCAPE_CERT_TYPE        "2.16.840.1.113730.1.1"
#define szOID_NETSCAPE_BASE_URL         "2.16.840.1.113730.1.2"
#define szOID_NETSCAPE_REVOCATION_URL   "2.16.840.1.113730.1.3"
#define szOID_NETSCAPE_CA_REVOCATION_URL "2.16.840.1.113730.1.4"
#define szOID_NETSCAPE_CERT_RENEWAL_URL "2.16.840.1.113730.1.7"
#define szOID_NETSCAPE_CA_POLICY_URL    "2.16.840.1.113730.1.8"
#define szOID_NETSCAPE_SSL_SERVER_NAME  "2.16.840.1.113730.1.12"
#define szOID_NETSCAPE_COMMENT          "2.16.840.1.113730.1.13"
#define szOID_NETSCAPE_DATA_TYPE        "2.16.840.1.113730.2"
#define szOID_NETSCAPE_CERT_SEQUENCE    "2.16.840.1.113730.2.5"

#define NETSCAPE_SSL_CLIENT_AUTH_CERT_TYPE  0x80
#define NETSCAPE_SSL_SERVER_AUTH_CERT_TYPE  0x40
#define NETSCAPE_SMIME_CERT_TYPE            0x20
#define NETSCAPE_SIGN_CERT_TYPE             0x10
#define NETSCAPE_SSL_CA_CERT_TYPE           0x04
#define NETSCAPE_SMIME_CA_CERT_TYPE         0x02
#define NETSCAPE_SIGN_CA_CERT_TYPE          0x01

typedef void *HCRYPTOIDFUNCSET;
typedef void *HCRYPTOIDFUNCADDR;
#define CRYPT_OID_ENCODE_OBJECT_FUNC        "CryptDllEncodeObject"
#define CRYPT_OID_DECODE_OBJECT_FUNC        "CryptDllDecodeObject"
#define CRYPT_OID_ENCODE_OBJECT_EX_FUNC     "CryptDllEncodeObjectEx"
#define CRYPT_OID_DECODE_OBJECT_EX_FUNC     "CryptDllDecodeObjectEx"
#define CRYPT_OID_CREATE_COM_OBJECT_FUNC    "CryptDllCreateCOMObject"
#define CRYPT_OID_VERIFY_REVOCATION_FUNC    "CertDllVerifyRevocation"
#define CRYPT_OID_VERIFY_CTL_USAGE_FUNC     "CertDllVerifyCTLUsage"
#define CRYPT_OID_FORMAT_OBJECT_FUNC        "CryptDllFormatObject"
#define CRYPT_OID_FIND_OID_INFO_FUNC        "CryptDllFindOIDInfo"
#define CRYPT_OID_FIND_LOCALIZED_NAME_FUNC  "CryptDllFindLocalizedName"
#define CRYPT_OID_REGPATH "Software\\Microsoft\\Cryptography\\OID"
#define CRYPT_OID_REG_ENCODING_TYPE_PREFIX  "EncodingType "
#define CRYPT_OID_REG_DLL_VALUE_NAME        L"Dll"
#define CRYPT_OID_REG_FUNC_NAME_VALUE_NAME  L"FuncName"
#define CRYPT_OID_REG_FUNC_NAME_VALUE_NAME_A "FuncName"
#define CRYPT_OID_REG_FLAGS_VALUE_NAME      L"CryptFlags"
#define CRYPT_DEFAULT_OID                   "DEFAULT"

typedef struct _CRYPT_OID_FUNC_ENTRY {
    LPCSTR  pszOID;
    void    *pvFuncAddr;
} CRYPT_OID_FUNC_ENTRY, *PCRYPT_OID_FUNC_ENTRY;

#define CRYPT_INSTALL_OID_FUNC_BEFORE_FLAG  1

WINCRYPT32API
BOOL
WINAPI
CryptInstallOIDFunctionAddress(
    HMODULE hModule,         // hModule passed to DllMain
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    DWORD cFuncEntry,
    const CRYPT_OID_FUNC_ENTRY rgFuncEntry[],
    DWORD dwFlags
    );

WINCRYPT32API
HCRYPTOIDFUNCSET
WINAPI
CryptInitOIDFunctionSet(
    LPCSTR pszFuncName,
    DWORD dwFlags
    );

WINCRYPT32API
BOOL
WINAPI
CryptGetOIDFunctionAddress(
    HCRYPTOIDFUNCSET hFuncSet,
    DWORD dwEncodingType,
    LPCSTR pszOID,
    DWORD dwFlags,
    void **ppvFuncAddr,
    HCRYPTOIDFUNCADDR *phFuncAddr
    );

#define CRYPT_GET_INSTALLED_OID_FUNC_FLAG       0x1

WINCRYPT32API
BOOL
WINAPI
CryptGetDefaultOIDDllList(
    HCRYPTOIDFUNCSET hFuncSet,
    DWORD dwEncodingType,
    LPWSTR pwszDllList,
    DWORD *pcchDllList
    );

WINCRYPT32API
BOOL
WINAPI
CryptGetDefaultOIDFunctionAddress(
    HCRYPTOIDFUNCSET hFuncSet,
    DWORD dwEncodingType,
    OPTIONAL LPCWSTR pwszDll,
    DWORD dwFlags,
    void **ppvFuncAddr,
    HCRYPTOIDFUNCADDR *phFuncAddr
    );

WINCRYPT32API
BOOL
WINAPI
CryptFreeOIDFunctionAddress(
    HCRYPTOIDFUNCADDR hFuncAddr,
    DWORD dwFlags
    );

WINCRYPT32API
BOOL
WINAPI
CryptRegisterOIDFunction(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    LPCSTR pszOID,
    OPTIONAL LPCWSTR pwszDll,
    OPTIONAL LPCSTR pszOverrideFuncName
    );

WINCRYPT32API
BOOL
WINAPI
CryptUnregisterOIDFunction(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    LPCSTR pszOID
    );

WINCRYPT32API
BOOL
WINAPI
CryptRegisterDefaultOIDFunction(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    DWORD dwIndex,
    LPCWSTR pwszDll
    );

#define CRYPT_REGISTER_FIRST_INDEX   0
#define CRYPT_REGISTER_LAST_INDEX    0xFFFFFFFF

WINCRYPT32API
BOOL
WINAPI
CryptUnregisterDefaultOIDFunction(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    LPCWSTR pwszDll
    );

WINCRYPT32API
BOOL
WINAPI
CryptSetOIDFunctionValue(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    LPCSTR pszOID,
    LPCWSTR pwszValueName,
    DWORD dwValueType,
    const BYTE *pbValueData,
    DWORD cbValueData
    );

WINCRYPT32API
BOOL
WINAPI
CryptGetOIDFunctionValue(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    LPCSTR pszOID,
    LPCWSTR pwszValueName,
    DWORD *pdwValueType,
    BYTE *pbValueData,
    DWORD *pcbValueData
    );

typedef BOOL (WINAPI *PFN_CRYPT_ENUM_OID_FUNC)(
    DWORD dwEncodingType,
    LPCSTR pszFuncName,
    LPCSTR pszOID,
    DWORD cValue,
    const DWORD rgdwValueType[],
    LPCWSTR const rgpwszValueName[],
    const BYTE * const rgpbValueData[],
    const DWORD rgcbValueData[],
    void *pvArg
    );

WINCRYPT32API
BOOL
WINAPI
CryptEnumOIDFunction(
    DWORD dwEncodingType,
    OPTIONAL LPCSTR pszFuncName,
    OPTIONAL LPCSTR pszOID,
    DWORD dwFlags,
    void *pvArg,
    PFN_CRYPT_ENUM_OID_FUNC pfnEnumOIDFunc
    );

#define CRYPT_MATCH_ANY_ENCODING_TYPE   0xFFFFFFFF

typedef struct _CRYPT_OID_INFO {
    DWORD           cbSize;
    LPCSTR          pszOID;
    LPCWSTR         pwszName;
    DWORD           dwGroupId;
    union {
        DWORD       dwValue;
        ALG_ID      Algid;
        DWORD       dwLength;
    };
    CRYPT_DATA_BLOB ExtraInfo;
} CRYPT_OID_INFO, *PCRYPT_OID_INFO;
typedef const CRYPT_OID_INFO CCRYPT_OID_INFO, *PCCRYPT_OID_INFO;

#define CRYPT_HASH_ALG_OID_GROUP_ID             1
#define CRYPT_ENCRYPT_ALG_OID_GROUP_ID          2
#define CRYPT_PUBKEY_ALG_OID_GROUP_ID           3
#define CRYPT_SIGN_ALG_OID_GROUP_ID             4
#define CRYPT_RDN_ATTR_OID_GROUP_ID             5
#define CRYPT_EXT_OR_ATTR_OID_GROUP_ID          6
#define CRYPT_ENHKEY_USAGE_OID_GROUP_ID         7
#define CRYPT_POLICY_OID_GROUP_ID               8
#define CRYPT_LAST_OID_GROUP_ID                 8
#define CRYPT_FIRST_ALG_OID_GROUP_ID            CRYPT_HASH_ALG_OID_GROUP_ID
#define CRYPT_LAST_ALG_OID_GROUP_ID             CRYPT_SIGN_ALG_OID_GROUP_ID
#define CRYPT_OID_INHIBIT_SIGNATURE_FORMAT_FLAG     0x1
#define CRYPT_OID_USE_PUBKEY_PARA_FOR_PKCS7_FLAG    0x2
#define CRYPT_OID_NO_NULL_ALGORITHM_PARA_FLAG       0x4

WINCRYPT32API
PCCRYPT_OID_INFO
WINAPI
CryptFindOIDInfo(
    DWORD dwKeyType,
    void *pvKey,
    DWORD dwGroupId
    );

#define CRYPT_OID_INFO_OID_KEY           1
#define CRYPT_OID_INFO_NAME_KEY          2
#define CRYPT_OID_INFO_ALGID_KEY         3
#define CRYPT_OID_INFO_SIGN_KEY          4

WINCRYPT32API
BOOL
WINAPI
CryptRegisterOIDInfo(
    PCCRYPT_OID_INFO pInfo,
    DWORD dwFlags
    );

#define CRYPT_INSTALL_OID_INFO_BEFORE_FLAG  1

WINCRYPT32API
BOOL
WINAPI
CryptUnregisterOIDInfo(
    PCCRYPT_OID_INFO pInfo
    );

typedef BOOL (WINAPI *PFN_CRYPT_ENUM_OID_INFO)(
    PCCRYPT_OID_INFO pInfo,
    void *pvArg
    );

WINCRYPT32API
BOOL
WINAPI
CryptEnumOIDInfo(
    DWORD dwGroupId,
    DWORD dwFlags,
    void *pvArg,
    PFN_CRYPT_ENUM_OID_INFO pfnEnumOIDInfo
    );

WINCRYPT32API
LPCWSTR
WINAPI
CryptFindLocalizedName(
    LPCWSTR pwszCryptName
    );

#define CRYPT_LOCALIZED_NAME_ENCODING_TYPE  0
#define CRYPT_LOCALIZED_NAME_OID            "LocalizedNames"

typedef void *HCRYPTMSG;

#define szOID_PKCS_7_DATA               "1.2.840.113549.1.7.1"
#define szOID_PKCS_7_SIGNED             "1.2.840.113549.1.7.2"
#define szOID_PKCS_7_ENVELOPED          "1.2.840.113549.1.7.3"
#define szOID_PKCS_7_SIGNEDANDENVELOPED "1.2.840.113549.1.7.4"
#define szOID_PKCS_7_DIGESTED           "1.2.840.113549.1.7.5"
#define szOID_PKCS_7_ENCRYPTED          "1.2.840.113549.1.7.6"
#define szOID_PKCS_9_CONTENT_TYPE       "1.2.840.113549.1.9.3"
#define szOID_PKCS_9_MESSAGE_DIGEST     "1.2.840.113549.1.9.4"

#define CMSG_DATA                    1
#define CMSG_SIGNED                  2
#define CMSG_ENVELOPED               3
#define CMSG_SIGNED_AND_ENVELOPED    4
#define CMSG_HASHED                  5
#define CMSG_ENCRYPTED               6

#define CMSG_ALL_FLAGS                   (~0UL)
#define CMSG_DATA_FLAG                   (1 << CMSG_DATA)
#define CMSG_SIGNED_FLAG                 (1 << CMSG_SIGNED)
#define CMSG_ENVELOPED_FLAG              (1 << CMSG_ENVELOPED)
#define CMSG_SIGNED_AND_ENVELOPED_FLAG   (1 << CMSG_SIGNED_AND_ENVELOPED)
#define CMSG_HASHED_FLAG                 (1 << CMSG_HASHED)
#define CMSG_ENCRYPTED_FLAG              (1 << CMSG_ENCRYPTED)

typedef struct _CERT_ISSUER_SERIAL_NUMBER {
    CERT_NAME_BLOB      Issuer;
    CRYPT_INTEGER_BLOB  SerialNumber;
} CERT_ISSUER_SERIAL_NUMBER, *PCERT_ISSUER_SERIAL_NUMBER;

typedef struct _CERT_ID {
    DWORD   dwIdChoice;
    union {
        CERT_ISSUER_SERIAL_NUMBER   IssuerSerialNumber;
        CRYPT_HASH_BLOB             KeyId;
        CRYPT_HASH_BLOB             HashId;
    };
} CERT_ID, *PCERT_ID;

#define CERT_ID_ISSUER_SERIAL_NUMBER    1
#define CERT_ID_KEY_IDENTIFIER          2
#define CERT_ID_SHA1_HASH               3

typedef struct _CMSG_SIGNER_ENCODE_INFO {
    DWORD                       cbSize;
    PCERT_INFO                  pCertInfo;
    HCRYPTPROV                  hCryptProv;
    DWORD                       dwKeySpec;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    void                        *pvHashAuxInfo;
    DWORD                       cAuthAttr;
    PCRYPT_ATTRIBUTE            rgAuthAttr;
    DWORD                       cUnauthAttr;
    PCRYPT_ATTRIBUTE            rgUnauthAttr;

#ifdef CMSG_SIGNER_ENCODE_INFO_HAS_CMS_FIELDS
    CERT_ID                     SignerId;
    CRYPT_ALGORITHM_IDENTIFIER  HashEncryptionAlgorithm;
    void                        *pvHashEncryptionAuxInfo;
#endif
} CMSG_SIGNER_ENCODE_INFO, *PCMSG_SIGNER_ENCODE_INFO;

typedef struct _CMSG_SIGNED_ENCODE_INFO {
    DWORD                       cbSize;
    DWORD                       cSigners;
    PCMSG_SIGNER_ENCODE_INFO    rgSigners;
    DWORD                       cCertEncoded;
    PCERT_BLOB                  rgCertEncoded;
    DWORD                       cCrlEncoded;
    PCRL_BLOB                   rgCrlEncoded;

#ifdef CMSG_SIGNED_ENCODE_INFO_HAS_CMS_FIELDS
    DWORD                       cAttrCertEncoded;
    PCERT_BLOB                  rgAttrCertEncoded;
#endif
} CMSG_SIGNED_ENCODE_INFO, *PCMSG_SIGNED_ENCODE_INFO;

typedef struct _CMSG_RECIPIENT_ENCODE_INFO CMSG_RECIPIENT_ENCODE_INFO,
    *PCMSG_RECIPIENT_ENCODE_INFO;

typedef struct _CMSG_ENVELOPED_ENCODE_INFO {
    DWORD                       cbSize;
    HCRYPTPROV                  hCryptProv;
    CRYPT_ALGORITHM_IDENTIFIER  ContentEncryptionAlgorithm;
    void                        *pvEncryptionAuxInfo;
    DWORD                       cRecipients;
    PCERT_INFO                  *rgpRecipients;
#ifdef CMSG_ENVELOPED_ENCODE_INFO_HAS_CMS_FIELDS
    PCMSG_RECIPIENT_ENCODE_INFO rgCmsRecipients;
    DWORD                       cCertEncoded;
    PCERT_BLOB                  rgCertEncoded;
    DWORD                       cCrlEncoded;
    PCRL_BLOB                   rgCrlEncoded;
    DWORD                       cAttrCertEncoded;
    PCERT_BLOB                  rgAttrCertEncoded;
    DWORD                       cUnprotectedAttr;
    PCRYPT_ATTRIBUTE            rgUnprotectedAttr;
#endif
} CMSG_ENVELOPED_ENCODE_INFO, *PCMSG_ENVELOPED_ENCODE_INFO;

typedef struct _CMSG_KEY_TRANS_RECIPIENT_ENCODE_INFO {
    DWORD                       cbSize;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    void                        *pvKeyEncryptionAuxInfo;
    HCRYPTPROV                  hCryptProv;
    CRYPT_BIT_BLOB              RecipientPublicKey;
    CERT_ID                     RecipientId;
} CMSG_KEY_TRANS_RECIPIENT_ENCODE_INFO, *PCMSG_KEY_TRANS_RECIPIENT_ENCODE_INFO;

typedef struct _CMSG_RECIPIENT_ENCRYPTED_KEY_ENCODE_INFO {
    DWORD                       cbSize;
    CRYPT_BIT_BLOB              RecipientPublicKey;
    CERT_ID                     RecipientId;
    FILETIME                    Date;
    PCRYPT_ATTRIBUTE_TYPE_VALUE pOtherAttr;
} CMSG_RECIPIENT_ENCRYPTED_KEY_ENCODE_INFO,
    *PCMSG_RECIPIENT_ENCRYPTED_KEY_ENCODE_INFO;

typedef struct _CMSG_KEY_AGREE_RECIPIENT_ENCODE_INFO {
    DWORD                       cbSize;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    void                        *pvKeyEncryptionAuxInfo;
    CRYPT_ALGORITHM_IDENTIFIER  KeyWrapAlgorithm;
    void                        *pvKeyWrapAuxInfo;
    HCRYPTPROV                  hCryptProv;
    DWORD                       dwKeySpec;
    DWORD                       dwKeyChoice;
    union {
        PCRYPT_ALGORITHM_IDENTIFIER pEphemeralAlgorithm;
        PCERT_ID                    pSenderId;
    };
    CRYPT_DATA_BLOB             UserKeyingMaterial;

    DWORD                                       cRecipientEncryptedKeys;
    PCMSG_RECIPIENT_ENCRYPTED_KEY_ENCODE_INFO   *rgpRecipientEncryptedKeys;
} CMSG_KEY_AGREE_RECIPIENT_ENCODE_INFO, *PCMSG_KEY_AGREE_RECIPIENT_ENCODE_INFO;

#define CMSG_KEY_AGREE_EPHEMERAL_KEY_CHOICE         1
#define CMSG_KEY_AGREE_STATIC_KEY_CHOICE            2

typedef struct _CMSG_MAIL_LIST_RECIPIENT_ENCODE_INFO {
    DWORD                       cbSize;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    void                        *pvKeyEncryptionAuxInfo;
    HCRYPTPROV                  hCryptProv;
    DWORD                       dwKeyChoice;
    union {
        HCRYPTKEY                   hKeyEncryptionKey;
        void                        *pvKeyEncryptionKey;
    };
    CRYPT_DATA_BLOB             KeyId;
    FILETIME                    Date;
    PCRYPT_ATTRIBUTE_TYPE_VALUE pOtherAttr;
} CMSG_MAIL_LIST_RECIPIENT_ENCODE_INFO, *PCMSG_MAIL_LIST_RECIPIENT_ENCODE_INFO;

#define CMSG_MAIL_LIST_HANDLE_KEY_CHOICE    1

struct _CMSG_RECIPIENT_ENCODE_INFO {
    DWORD   dwRecipientChoice;
    union {
        PCMSG_KEY_TRANS_RECIPIENT_ENCODE_INFO   pKeyTrans;
        PCMSG_KEY_AGREE_RECIPIENT_ENCODE_INFO   pKeyAgree;
        PCMSG_MAIL_LIST_RECIPIENT_ENCODE_INFO   pMailList;
    };
};

#define CMSG_KEY_TRANS_RECIPIENT         1
#define CMSG_KEY_AGREE_RECIPIENT         2
#define CMSG_MAIL_LIST_RECIPIENT         3

typedef struct _CMSG_RC2_AUX_INFO {
    DWORD                       cbSize;
    DWORD                       dwBitLen;
} CMSG_RC2_AUX_INFO, *PCMSG_RC2_AUX_INFO;

typedef struct _CMSG_SP3_COMPATIBLE_AUX_INFO {
    DWORD                       cbSize;
    DWORD                       dwFlags;
} CMSG_SP3_COMPATIBLE_AUX_INFO, *PCMSG_SP3_COMPATIBLE_AUX_INFO;

#define CMSG_SP3_COMPATIBLE_ENCRYPT_FLAG    0x80000000

typedef struct _CMSG_RC4_AUX_INFO {
    DWORD                       cbSize;
    DWORD                       dwBitLen;
} CMSG_RC4_AUX_INFO, *PCMSG_RC4_AUX_INFO;

#define CMSG_RC4_NO_SALT_FLAG               0x40000000

typedef struct _CMSG_SIGNED_AND_ENVELOPED_ENCODE_INFO {
    DWORD                       cbSize;
    CMSG_SIGNED_ENCODE_INFO     SignedInfo;
    CMSG_ENVELOPED_ENCODE_INFO  EnvelopedInfo;
} CMSG_SIGNED_AND_ENVELOPED_ENCODE_INFO, *PCMSG_SIGNED_AND_ENVELOPED_ENCODE_INFO;

typedef struct _CMSG_HASHED_ENCODE_INFO {
    DWORD                       cbSize;
    HCRYPTPROV                  hCryptProv;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    void                        *pvHashAuxInfo;
} CMSG_HASHED_ENCODE_INFO, *PCMSG_HASHED_ENCODE_INFO;

typedef struct _CMSG_ENCRYPTED_ENCODE_INFO {
    DWORD                       cbSize;
    CRYPT_ALGORITHM_IDENTIFIER  ContentEncryptionAlgorithm;
    void                        *pvEncryptionAuxInfo;
} CMSG_ENCRYPTED_ENCODE_INFO, *PCMSG_ENCRYPTED_ENCODE_INFO;

typedef BOOL (WINAPI *PFN_CMSG_STREAM_OUTPUT)(
    const void *pvArg,
    BYTE *pbData,
    DWORD cbData,
    BOOL fFinal
    );

#define CMSG_INDEFINITE_LENGTH       (0xFFFFFFFF)

typedef struct _CMSG_STREAM_INFO {
    DWORD                   cbContent;
    PFN_CMSG_STREAM_OUTPUT  pfnStreamOutput;
    void                    *pvArg;
} CMSG_STREAM_INFO, *PCMSG_STREAM_INFO;

#define CMSG_BARE_CONTENT_FLAG              0x00000001
#define CMSG_LENGTH_ONLY_FLAG               0x00000002
#define CMSG_DETACHED_FLAG                  0x00000004
#define CMSG_AUTHENTICATED_ATTRIBUTES_FLAG  0x00000008
#define CMSG_CONTENTS_OCTETS_FLAG           0x00000010
#define CMSG_MAX_LENGTH_FLAG                0x00000020
#define CMSG_CMS_ENCAPSULATED_CONTENT_FLAG  0x00000040
#define CMSG_CRYPT_RELEASE_CONTEXT_FLAG     0x00008000

WINCRYPT32API
HCRYPTMSG
WINAPI
CryptMsgOpenToEncode(
    DWORD dwMsgEncodingType,
    DWORD dwFlags,
    DWORD dwMsgType,
    void const *pvMsgEncodeInfo,
    OPTIONAL LPSTR pszInnerContentObjID,
    OPTIONAL PCMSG_STREAM_INFO pStreamInfo
    );

WINCRYPT32API
DWORD
WINAPI
CryptMsgCalculateEncodedLength(
    DWORD dwMsgEncodingType,
    DWORD dwFlags,
    DWORD dwMsgType,
    void const *pvMsgEncodeInfo,
    OPTIONAL LPSTR pszInnerContentObjID,
    DWORD cbData
    );

WINCRYPT32API
HCRYPTMSG
WINAPI
CryptMsgOpenToDecode(
    DWORD dwMsgEncodingType,
    DWORD dwFlags,
    DWORD dwMsgType,
    HCRYPTPROV hCryptProv,
    OPTIONAL PCERT_INFO pRecipientInfo,
    OPTIONAL PCMSG_STREAM_INFO pStreamInfo
    );

WINCRYPT32API
HCRYPTMSG
WINAPI
CryptMsgDuplicate(
    HCRYPTMSG hCryptMsg
    );

WINCRYPT32API
BOOL
WINAPI
CryptMsgClose(
    HCRYPTMSG hCryptMsg
    );

WINCRYPT32API
BOOL
WINAPI
CryptMsgUpdate(
    HCRYPTMSG hCryptMsg,
    const BYTE *pbData,
    DWORD cbData,
    BOOL fFinal
    );

WINCRYPT32API
BOOL
WINAPI
CryptMsgGetParam(
    HCRYPTMSG hCryptMsg,
    DWORD dwParamType,
    DWORD dwIndex,
    void *pvData,
    DWORD *pcbData
    );

#define CMSG_TYPE_PARAM                              1
#define CMSG_CONTENT_PARAM                           2
#define CMSG_BARE_CONTENT_PARAM                      3
#define CMSG_INNER_CONTENT_TYPE_PARAM                4
#define CMSG_SIGNER_COUNT_PARAM                      5
#define CMSG_SIGNER_INFO_PARAM                       6
#define CMSG_SIGNER_CERT_INFO_PARAM                  7
#define CMSG_SIGNER_HASH_ALGORITHM_PARAM             8
#define CMSG_SIGNER_AUTH_ATTR_PARAM                  9
#define CMSG_SIGNER_UNAUTH_ATTR_PARAM                10
#define CMSG_CERT_COUNT_PARAM                        11
#define CMSG_CERT_PARAM                              12
#define CMSG_CRL_COUNT_PARAM                         13
#define CMSG_CRL_PARAM                               14
#define CMSG_ENVELOPE_ALGORITHM_PARAM                15
#define CMSG_RECIPIENT_COUNT_PARAM                   17
#define CMSG_RECIPIENT_INDEX_PARAM                   18
#define CMSG_RECIPIENT_INFO_PARAM                    19
#define CMSG_HASH_ALGORITHM_PARAM                    20
#define CMSG_HASH_DATA_PARAM                         21
#define CMSG_COMPUTED_HASH_PARAM                     22
#define CMSG_ENCRYPT_PARAM                           26
#define CMSG_ENCRYPTED_DIGEST                        27
#define CMSG_ENCODED_SIGNER                          28
#define CMSG_ENCODED_MESSAGE                         29
#define CMSG_VERSION_PARAM                           30
#define CMSG_ATTR_CERT_COUNT_PARAM                   31
#define CMSG_ATTR_CERT_PARAM                         32
#define CMSG_CMS_RECIPIENT_COUNT_PARAM               33
#define CMSG_CMS_RECIPIENT_INDEX_PARAM               34
#define CMSG_CMS_RECIPIENT_ENCRYPTED_KEY_INDEX_PARAM 35
#define CMSG_CMS_RECIPIENT_INFO_PARAM                36
#define CMSG_UNPROTECTED_ATTR_PARAM                  37
#define CMSG_SIGNER_CERT_ID_PARAM                    38
#define CMSG_CMS_SIGNER_INFO_PARAM                   39

typedef struct _CMSG_SIGNER_INFO {
    DWORD                       dwVersion;
    CERT_NAME_BLOB              Issuer;
    CRYPT_INTEGER_BLOB          SerialNumber;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    CRYPT_ALGORITHM_IDENTIFIER  HashEncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedHash;
    CRYPT_ATTRIBUTES            AuthAttrs;
    CRYPT_ATTRIBUTES            UnauthAttrs;
} CMSG_SIGNER_INFO, *PCMSG_SIGNER_INFO;

typedef struct _CMSG_CMS_SIGNER_INFO {
    DWORD                       dwVersion;
    CERT_ID                     SignerId;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    CRYPT_ALGORITHM_IDENTIFIER  HashEncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedHash;
    CRYPT_ATTRIBUTES            AuthAttrs;
    CRYPT_ATTRIBUTES            UnauthAttrs;
} CMSG_CMS_SIGNER_INFO, *PCMSG_CMS_SIGNER_INFO;

typedef CRYPT_ATTRIBUTES CMSG_ATTR;
typedef CRYPT_ATTRIBUTES *PCMSG_ATTR;

#define CMSG_SIGNED_DATA_V1                     1
#define CMSG_SIGNED_DATA_V3                     3
#define CMSG_SIGNED_DATA_PKCS_1_5_VERSION       CMSG_SIGNED_DATA_V1
#define CMSG_SIGNED_DATA_CMS_VERSION            CMSG_SIGNED_DATA_V3
#define CMSG_SIGNER_INFO_V1                     1
#define CMSG_SIGNER_INFO_V3                     3
#define CMSG_SIGNER_INFO_PKCS_1_5_VERSION       CMSG_SIGNER_INFO_V1
#define CMSG_SIGNER_INFO_CMS_VERSION            CMSG_SIGNER_INFO_V3
#define CMSG_HASHED_DATA_V0                     0
#define CMSG_HASHED_DATA_V2                     2
#define CMSG_HASHED_DATA_PKCS_1_5_VERSION       CMSG_HASHED_DATA_V0
#define CMSG_HASHED_DATA_CMS_VERSION            CMSG_HASHED_DATA_V2
#define CMSG_ENVELOPED_DATA_V0                  0
#define CMSG_ENVELOPED_DATA_V2                  2
#define CMSG_ENVELOPED_DATA_PKCS_1_5_VERSION    CMSG_ENVELOPED_DATA_V0
#define CMSG_ENVELOPED_DATA_CMS_VERSION         CMSG_ENVELOPED_DATA_V2

typedef struct _CMSG_KEY_TRANS_RECIPIENT_INFO {
    DWORD                       dwVersion;
    CERT_ID                     RecipientId;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedKey;
} CMSG_KEY_TRANS_RECIPIENT_INFO, *PCMSG_KEY_TRANS_RECIPIENT_INFO;

typedef struct _CMSG_RECIPIENT_ENCRYPTED_KEY_INFO {
    CERT_ID                     RecipientId;
    CRYPT_DATA_BLOB             EncryptedKey;
    FILETIME                    Date;
    PCRYPT_ATTRIBUTE_TYPE_VALUE pOtherAttr;
} CMSG_RECIPIENT_ENCRYPTED_KEY_INFO, *PCMSG_RECIPIENT_ENCRYPTED_KEY_INFO;

typedef struct _CMSG_KEY_AGREE_RECIPIENT_INFO {
    DWORD                       dwVersion;
    DWORD                       dwOriginatorChoice;
    union {
        CERT_ID                     OriginatorCertId;
        CERT_PUBLIC_KEY_INFO        OriginatorPublicKeyInfo;
    };
    CRYPT_DATA_BLOB             UserKeyingMaterial;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;

    DWORD                                cRecipientEncryptedKeys;
    PCMSG_RECIPIENT_ENCRYPTED_KEY_INFO   *rgpRecipientEncryptedKeys;
} CMSG_KEY_AGREE_RECIPIENT_INFO, *PCMSG_KEY_AGREE_RECIPIENT_INFO;

#define CMSG_KEY_AGREE_ORIGINATOR_CERT         1
#define CMSG_KEY_AGREE_ORIGINATOR_PUBLIC_KEY   2

typedef struct _CMSG_MAIL_LIST_RECIPIENT_INFO {
    DWORD                       dwVersion;
    CRYPT_DATA_BLOB             KeyId;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedKey;
    FILETIME                    Date;
    PCRYPT_ATTRIBUTE_TYPE_VALUE pOtherAttr;
} CMSG_MAIL_LIST_RECIPIENT_INFO, *PCMSG_MAIL_LIST_RECIPIENT_INFO;

typedef struct _CMSG_CMS_RECIPIENT_INFO {
    DWORD   dwRecipientChoice;
    union {
        PCMSG_KEY_TRANS_RECIPIENT_INFO   pKeyTrans;
        PCMSG_KEY_AGREE_RECIPIENT_INFO   pKeyAgree;
        PCMSG_MAIL_LIST_RECIPIENT_INFO   pMailList;
    };
} CMSG_CMS_RECIPIENT_INFO, *PCMSG_CMS_RECIPIENT_INFO;

#define CMSG_ENVELOPED_RECIPIENT_V0             0
#define CMSG_ENVELOPED_RECIPIENT_V2             2
#define CMSG_ENVELOPED_RECIPIENT_V3             3
#define CMSG_ENVELOPED_RECIPIENT_V4             4
#define CMSG_KEY_TRANS_PKCS_1_5_VERSION         CMSG_ENVELOPED_RECIPIENT_V0
#define CMSG_KEY_TRANS_CMS_VERSION              CMSG_ENVELOPED_RECIPIENT_V2
#define CMSG_KEY_AGREE_VERSION                  CMSG_ENVELOPED_RECIPIENT_V3
#define CMSG_MAIL_LIST_VERSION                  CMSG_ENVELOPED_RECIPIENT_V4

WINCRYPT32API
BOOL
WINAPI
CryptMsgControl(
    HCRYPTMSG hCryptMsg,
    DWORD dwFlags,
    DWORD dwCtrlType,
    void const *pvCtrlPara
    );

#define CMSG_CTRL_VERIFY_SIGNATURE       1
#define CMSG_CTRL_DECRYPT                2
#define CMSG_CTRL_VERIFY_HASH            5
#define CMSG_CTRL_ADD_SIGNER             6
#define CMSG_CTRL_DEL_SIGNER             7
#define CMSG_CTRL_ADD_SIGNER_UNAUTH_ATTR 8
#define CMSG_CTRL_DEL_SIGNER_UNAUTH_ATTR 9
#define CMSG_CTRL_ADD_CERT               10
#define CMSG_CTRL_DEL_CERT               11
#define CMSG_CTRL_ADD_CRL                12
#define CMSG_CTRL_DEL_CRL                13
#define CMSG_CTRL_ADD_ATTR_CERT          14
#define CMSG_CTRL_DEL_ATTR_CERT          15
#define CMSG_CTRL_KEY_TRANS_DECRYPT      16
#define CMSG_CTRL_KEY_AGREE_DECRYPT      17
#define CMSG_CTRL_MAIL_LIST_DECRYPT      18
#define CMSG_CTRL_VERIFY_SIGNATURE_EX    19
#define CMSG_CTRL_ADD_CMS_SIGNER_INFO    20

typedef struct _CMSG_CTRL_VERIFY_SIGNATURE_EX_PARA {
    DWORD               cbSize;
    HCRYPTPROV          hCryptProv;
    DWORD               dwSignerIndex;
    DWORD               dwSignerType;
    void                *pvSigner;
} CMSG_CTRL_VERIFY_SIGNATURE_EX_PARA, *PCMSG_CTRL_VERIFY_SIGNATURE_EX_PARA;

#define CMSG_VERIFY_SIGNER_PUBKEY                   1
#define CMSG_VERIFY_SIGNER_CERT                     2
#define CMSG_VERIFY_SIGNER_CHAIN                    3

typedef struct _CMSG_CTRL_DECRYPT_PARA {
    DWORD       cbSize;
    HCRYPTPROV  hCryptProv;
    DWORD       dwKeySpec;
    DWORD       dwRecipientIndex;
} CMSG_CTRL_DECRYPT_PARA, *PCMSG_CTRL_DECRYPT_PARA;

typedef struct _CMSG_CTRL_KEY_TRANS_DECRYPT_PARA {
    DWORD                           cbSize;
    HCRYPTPROV                      hCryptProv;
    DWORD                           dwKeySpec;
    PCMSG_KEY_TRANS_RECIPIENT_INFO  pKeyTrans;
    DWORD                           dwRecipientIndex;
} CMSG_CTRL_KEY_TRANS_DECRYPT_PARA, *PCMSG_CTRL_KEY_TRANS_DECRYPT_PARA;

typedef struct _CMSG_CTRL_KEY_AGREE_DECRYPT_PARA {
    DWORD                           cbSize;
    HCRYPTPROV                      hCryptProv;
    DWORD                           dwKeySpec;
    PCMSG_KEY_AGREE_RECIPIENT_INFO  pKeyAgree;
    DWORD                           dwRecipientIndex;
    DWORD                           dwRecipientEncryptedKeyIndex;
    CRYPT_BIT_BLOB                  OriginatorPublicKey;
} CMSG_CTRL_KEY_AGREE_DECRYPT_PARA, *PCMSG_CTRL_KEY_AGREE_DECRYPT_PARA;

typedef struct _CMSG_CTRL_MAIL_LIST_DECRYPT_PARA {
    DWORD                           cbSize;
    HCRYPTPROV                      hCryptProv;
    PCMSG_MAIL_LIST_RECIPIENT_INFO  pMailList;
    DWORD                           dwRecipientIndex;
    DWORD                           dwKeyChoice;
    union {
        HCRYPTKEY                       hKeyEncryptionKey;
        void                            *pvKeyEncryptionKey;
    };
} CMSG_CTRL_MAIL_LIST_DECRYPT_PARA, *PCMSG_CTRL_MAIL_LIST_DECRYPT_PARA;

typedef struct _CMSG_CTRL_ADD_SIGNER_UNAUTH_ATTR_PARA {
    DWORD               cbSize;
    DWORD               dwSignerIndex;
    CRYPT_DATA_BLOB     blob;
} CMSG_CTRL_ADD_SIGNER_UNAUTH_ATTR_PARA, *PCMSG_CTRL_ADD_SIGNER_UNAUTH_ATTR_PARA;

typedef struct _CMSG_CTRL_DEL_SIGNER_UNAUTH_ATTR_PARA {
    DWORD               cbSize;
    DWORD               dwSignerIndex;
    DWORD               dwUnauthAttrIndex;
} CMSG_CTRL_DEL_SIGNER_UNAUTH_ATTR_PARA, *PCMSG_CTRL_DEL_SIGNER_UNAUTH_ATTR_PARA;

BOOL
WINAPI
CryptMsgVerifyCountersignatureEncoded(
    HCRYPTPROV   hCryptProv,
    DWORD        dwEncodingType,
    PBYTE        pbSignerInfo,
    DWORD        cbSignerInfo,
    PBYTE        pbSignerInfoCountersignature,
    DWORD        cbSignerInfoCountersignature,
    PCERT_INFO   pciCountersigner
    );

BOOL
WINAPI
CryptMsgVerifyCountersignatureEncodedEx(
    HCRYPTPROV   hCryptProv,
    DWORD        dwEncodingType,
    PBYTE        pbSignerInfo,
    DWORD        cbSignerInfo,
    PBYTE        pbSignerInfoCountersignature,
    DWORD        cbSignerInfoCountersignature,
    DWORD        dwSignerType,
    void         *pvSigner,
    DWORD        dwFlags,
    OPTIONAL void *pvReserved
    );

BOOL
WINAPI
CryptMsgCountersign(
    HCRYPTMSG            hCryptMsg,
    DWORD                    dwIndex,
    DWORD                    cCountersigners,
    PCMSG_SIGNER_ENCODE_INFO rgCountersigners
    );

BOOL
WINAPI
CryptMsgCountersignEncoded(
    DWORD                    dwEncodingType,
    PBYTE                    pbSignerInfo,
    DWORD                    cbSignerInfo,
    DWORD                    cCountersigners,
    PCMSG_SIGNER_ENCODE_INFO rgCountersigners,
    PBYTE                   pbCountersignature,
    PDWORD               pcbCountersignature
    );

typedef void * (WINAPI *PFN_CMSG_ALLOC) (
    size_t cb
    );

typedef void (WINAPI *PFN_CMSG_FREE)(
    void *pv
    );

#define CMSG_OID_GEN_ENCRYPT_KEY_FUNC   "CryptMsgDllGenEncryptKey"
typedef BOOL (WINAPI *PFN_CMSG_GEN_ENCRYPT_KEY) (
    HCRYPTPROV               *phCryptProv,
    PCRYPT_ALGORITHM_IDENTIFIER  paiEncrypt,
    PVOID                        pvEncryptAuxInfo,
    PCERT_PUBLIC_KEY_INFO        pPublicKeyInfo,
    PFN_CMSG_ALLOC               pfnAlloc,
    HCRYPTKEY                   *phEncryptKey,
    PBYTE                       *ppbEncryptParameters,
    PDWORD                      pcbEncryptParameters
    );

#define CMSG_OID_EXPORT_ENCRYPT_KEY_FUNC   "CryptMsgDllExportEncryptKey"
typedef BOOL (WINAPI *PFN_CMSG_EXPORT_ENCRYPT_KEY) (
    HCRYPTPROV                   hCryptProv,
    HCRYPTKEY                    hEncryptKey,
    PCERT_PUBLIC_KEY_INFO        pPublicKeyInfo,
    PBYTE                       pbData,
    PDWORD                   pcbData
    );

#define CMSG_OID_IMPORT_ENCRYPT_KEY_FUNC   "CryptMsgDllImportEncryptKey"
typedef BOOL (WINAPI *PFN_CMSG_IMPORT_ENCRYPT_KEY) (
    HCRYPTPROV                   hCryptProv,
    DWORD                        dwKeySpec,
    PCRYPT_ALGORITHM_IDENTIFIER  paiEncrypt,
    PCRYPT_ALGORITHM_IDENTIFIER  paiPubKey,
    PBYTE                        pbEncodedKey,
    DWORD                        cbEncodedKey,
    HCRYPTKEY                   *phEncryptKey
    );

#define CMSG_DEFAULT_INSTALLABLE_FUNC_OID   ((LPCSTR) 1)

typedef struct _CMSG_CONTENT_ENCRYPT_INFO {
    DWORD                       cbSize;
    HCRYPTPROV                  hCryptProv;
    CRYPT_ALGORITHM_IDENTIFIER  ContentEncryptionAlgorithm;
    void                        *pvEncryptionAuxInfo;
    DWORD                       cRecipients;
    PCMSG_RECIPIENT_ENCODE_INFO rgCmsRecipients;
    PFN_CMSG_ALLOC              pfnAlloc;
    PFN_CMSG_FREE               pfnFree;
    DWORD                       dwEncryptFlags;
    HCRYPTKEY                   hContentEncryptKey;
    DWORD                       dwFlags;
} CMSG_CONTENT_ENCRYPT_INFO, *PCMSG_CONTENT_ENCRYPT_INFO;

#define CMSG_CONTENT_ENCRYPT_PAD_ENCODED_LEN_FLAG   0x00000001
#define CMSG_CONTENT_ENCRYPT_FREE_PARA_FLAG         0x00000001
#define CMSG_CONTENT_ENCRYPT_RELEASE_CONTEXT_FLAG   0x00008000

#define CMSG_OID_GEN_CONTENT_ENCRYPT_KEY_FUNC  "CryptMsgDllGenContentEncryptKey"
typedef BOOL (WINAPI *PFN_CMSG_GEN_CONTENT_ENCRYPT_KEY) (
    PCMSG_CONTENT_ENCRYPT_INFO pContentEncryptInfo,
    DWORD dwFlags,
    OPTIONAL void *pvReserved
    );

typedef struct _CMSG_KEY_TRANS_ENCRYPT_INFO {
    DWORD                       cbSize;
    DWORD                       dwRecipientIndex;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedKey;
    DWORD                       dwFlags;
} CMSG_KEY_TRANS_ENCRYPT_INFO, *PCMSG_KEY_TRANS_ENCRYPT_INFO;

#define CMSG_KEY_TRANS_ENCRYPT_FREE_PARA_FLAG       0x00000001

#define CMSG_OID_EXPORT_KEY_TRANS_FUNC  "CryptMsgDllExportKeyTrans"
typedef BOOL (WINAPI *PFN_CMSG_EXPORT_KEY_TRANS) (
    PCMSG_CONTENT_ENCRYPT_INFO pContentEncryptInfo,
    PCMSG_KEY_TRANS_RECIPIENT_ENCODE_INFO pKeyTransEncodeInfo,
    PCMSG_KEY_TRANS_ENCRYPT_INFO pKeyTransEncryptInfo,
    DWORD dwFlags,
    OPTIONAL void *pvReserved
    );

typedef struct _CMSG_KEY_AGREE_KEY_ENCRYPT_INFO {
    DWORD                       cbSize;
    CRYPT_DATA_BLOB             EncryptedKey;
} CMSG_KEY_AGREE_KEY_ENCRYPT_INFO, *PCMSG_KEY_AGREE_KEY_ENCRYPT_INFO;

typedef struct _CMSG_KEY_AGREE_ENCRYPT_INFO {
    DWORD                       cbSize;
    DWORD                       dwRecipientIndex;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    CRYPT_DATA_BLOB             UserKeyingMaterial;
    DWORD                       dwOriginatorChoice;
    union {
        CERT_ID                     OriginatorCertId;
        CERT_PUBLIC_KEY_INFO        OriginatorPublicKeyInfo;
    };
    DWORD                       cKeyAgreeKeyEncryptInfo;
    PCMSG_KEY_AGREE_KEY_ENCRYPT_INFO *rgpKeyAgreeKeyEncryptInfo;
    DWORD                       dwFlags;
} CMSG_KEY_AGREE_ENCRYPT_INFO, *PCMSG_KEY_AGREE_ENCRYPT_INFO;

#define CMSG_KEY_AGREE_ENCRYPT_FREE_PARA_FLAG           0x00000001
#define CMSG_KEY_AGREE_ENCRYPT_FREE_MATERIAL_FLAG       0x00000002
#define CMSG_KEY_AGREE_ENCRYPT_FREE_PUBKEY_ALG_FLAG     0x00000004
#define CMSG_KEY_AGREE_ENCRYPT_FREE_PUBKEY_PARA_FLAG    0x00000008
#define CMSG_KEY_AGREE_ENCRYPT_FREE_PUBKEY_BITS_FLAG    0x00000010

#define CMSG_OID_EXPORT_KEY_AGREE_FUNC  "CryptMsgDllExportKeyAgree"
typedef BOOL (WINAPI *PFN_CMSG_EXPORT_KEY_AGREE) (
    PCMSG_CONTENT_ENCRYPT_INFO pContentEncryptInfo,
    PCMSG_KEY_AGREE_RECIPIENT_ENCODE_INFO pKeyAgreeEncodeInfo,
    PCMSG_KEY_AGREE_ENCRYPT_INFO pKeyAgreeEncryptInfo,
    DWORD dwFlags,
    OPTIONAL void *pvReserved
    );

typedef struct _CMSG_MAIL_LIST_ENCRYPT_INFO {
    DWORD                       cbSize;
    DWORD                       dwRecipientIndex;
    CRYPT_ALGORITHM_IDENTIFIER  KeyEncryptionAlgorithm;
    CRYPT_DATA_BLOB             EncryptedKey;
    DWORD                       dwFlags;
} CMSG_MAIL_LIST_ENCRYPT_INFO, *PCMSG_MAIL_LIST_ENCRYPT_INFO;

#define CMSG_MAIL_LIST_ENCRYPT_FREE_PARA_FLAG       0x00000001

#define CMSG_OID_EXPORT_MAIL_LIST_FUNC  "CryptMsgDllExportMailList"
typedef BOOL (WINAPI *PFN_CMSG_EXPORT_MAIL_LIST) (
    PCMSG_CONTENT_ENCRYPT_INFO pContentEncryptInfo,
    PCMSG_MAIL_LIST_RECIPIENT_ENCODE_INFO pMailListEncodeInfo,
    PCMSG_MAIL_LIST_ENCRYPT_INFO pMailListEncryptInfo,
    DWORD dwFlags,
    OPTIONAL void *pvReserved
    );

#define CMSG_OID_IMPORT_KEY_TRANS_FUNC   "CryptMsgDllImportKeyTrans"
typedef BOOL (WINAPI *PFN_CMSG_IMPORT_KEY_TRANS) (
    PCRYPT_ALGORITHM_IDENTIFIER pContentEncryptionAlgorithm,
    PCMSG_CTRL_KEY_TRANS_DECRYPT_PARA pKeyTransDecryptPara,
    DWORD dwFlags,
    OPTIONAL void *pvReserved,
    HCRYPTKEY *phContentEncryptKey
    );

#define CMSG_OID_IMPORT_KEY_AGREE_FUNC   "CryptMsgDllImportKeyAgree"
typedef BOOL (WINAPI *PFN_CMSG_IMPORT_KEY_AGREE) (
    PCRYPT_ALGORITHM_IDENTIFIER pContentEncryptionAlgorithm,
    PCMSG_CTRL_KEY_AGREE_DECRYPT_PARA pKeyAgreeDecryptPara,
    DWORD dwFlags,
    OPTIONAL void *pvReserved,
    HCRYPTKEY *phContentEncryptKey
    );

#define CMSG_OID_IMPORT_MAIL_LIST_FUNC   "CryptMsgDllImportMailList"
typedef BOOL (WINAPI *PFN_CMSG_IMPORT_MAIL_LIST) (
    PCRYPT_ALGORITHM_IDENTIFIER pContentEncryptionAlgorithm,
    PCMSG_CTRL_MAIL_LIST_DECRYPT_PARA pMailListDecryptPara,
    DWORD dwFlags,
    OPTIONAL void *pvReserved,
    HCRYPTKEY *phContentEncryptKey
    );

typedef void *HCERTSTORE;

typedef struct _CERT_CONTEXT {
    DWORD                   dwCertEncodingType;
    BYTE                    *pbCertEncoded;
    DWORD                   cbCertEncoded;
    PCERT_INFO              pCertInfo;
    HCERTSTORE              hCertStore;
} CERT_CONTEXT, *PCERT_CONTEXT;
typedef const CERT_CONTEXT *PCCERT_CONTEXT;

typedef struct _CRL_CONTEXT {
    DWORD                   dwCertEncodingType;
    BYTE                    *pbCrlEncoded;
    DWORD                   cbCrlEncoded;
    PCRL_INFO               pCrlInfo;
    HCERTSTORE              hCertStore;
} CRL_CONTEXT, *PCRL_CONTEXT;
typedef const CRL_CONTEXT *PCCRL_CONTEXT;

typedef struct _CTL_CONTEXT {
    DWORD                   dwMsgAndCertEncodingType;
    BYTE                    *pbCtlEncoded;
    DWORD                   cbCtlEncoded;
    PCTL_INFO               pCtlInfo;
    HCERTSTORE              hCertStore;
    HCRYPTMSG               hCryptMsg;
    BYTE                    *pbCtlContent;
    DWORD                   cbCtlContent;
} CTL_CONTEXT, *PCTL_CONTEXT;
typedef const CTL_CONTEXT *PCCTL_CONTEXT;

#define CERT_KEY_PROV_HANDLE_PROP_ID        1
#define CERT_KEY_PROV_INFO_PROP_ID          2
#define CERT_SHA1_HASH_PROP_ID              3
#define CERT_MD5_HASH_PROP_ID               4
#define CERT_HASH_PROP_ID                   CERT_SHA1_HASH_PROP_ID
#define CERT_KEY_CONTEXT_PROP_ID            5
#define CERT_KEY_SPEC_PROP_ID               6
#define CERT_IE30_RESERVED_PROP_ID          7
#define CERT_PUBKEY_HASH_RESERVED_PROP_ID   8
#define CERT_ENHKEY_USAGE_PROP_ID           9
#define CERT_CTL_USAGE_PROP_ID              CERT_ENHKEY_USAGE_PROP_ID
#define CERT_NEXT_UPDATE_LOCATION_PROP_ID   10
#define CERT_FRIENDLY_NAME_PROP_ID          11
#define CERT_PVK_FILE_PROP_ID               12
#define CERT_DESCRIPTION_PROP_ID            13
#define CERT_ACCESS_STATE_PROP_ID           14
#define CERT_SIGNATURE_HASH_PROP_ID         15
#define CERT_SMART_CARD_DATA_PROP_ID        16
#define CERT_EFS_PROP_ID                    17
#define CERT_FORTEZZA_DATA_PROP_ID          18
#define CERT_ARCHIVED_PROP_ID               19
#define CERT_KEY_IDENTIFIER_PROP_ID         20
#define CERT_AUTO_ENROLL_PROP_ID            21
#define CERT_PUBKEY_ALG_PARA_PROP_ID        22
#define CERT_FIRST_RESERVED_PROP_ID         23
#define CERT_LAST_RESERVED_PROP_ID          0x00007FFF
#define CERT_FIRST_USER_PROP_ID             0x00008000
#define CERT_LAST_USER_PROP_ID              0x0000FFFF


#define IS_CERT_HASH_PROP_ID(X)     (CERT_SHA1_HASH_PROP_ID == (X) || \
                                        CERT_MD5_HASH_PROP_ID == (X) || \
                                        CERT_SIGNATURE_HASH_PROP_ID == (X))

#define CERT_ACCESS_STATE_WRITE_PERSIST_FLAG    0x1
#define CERT_ACCESS_STATE_SYSTEM_STORE_FLAG     0x2

typedef struct _CRYPT_KEY_PROV_PARAM {
    DWORD           dwParam;
    BYTE            *pbData;
    DWORD           cbData;
    DWORD           dwFlags;
} CRYPT_KEY_PROV_PARAM, *PCRYPT_KEY_PROV_PARAM;

typedef struct _CRYPT_KEY_PROV_INFO {
    LPWSTR                  pwszContainerName;
    LPWSTR                  pwszProvName;
    DWORD                   dwProvType;
    DWORD                   dwFlags;
    DWORD                   cProvParam;
    PCRYPT_KEY_PROV_PARAM   rgProvParam;
    DWORD                   dwKeySpec;
} CRYPT_KEY_PROV_INFO, *PCRYPT_KEY_PROV_INFO;

#define CERT_SET_KEY_PROV_HANDLE_PROP_ID    0x00000001
#define CERT_SET_KEY_CONTEXT_PROP_ID        0x00000001

typedef struct _CERT_KEY_CONTEXT {
    DWORD           cbSize;           // sizeof(CERT_KEY_CONTEXT)
    HCRYPTPROV      hCryptProv;
    DWORD           dwKeySpec;
} CERT_KEY_CONTEXT, *PCERT_KEY_CONTEXT;

#define CERT_STORE_PROV_MSG                 ((LPCSTR) 1)
#define CERT_STORE_PROV_MEMORY              ((LPCSTR) 2)
#define CERT_STORE_PROV_FILE                ((LPCSTR) 3)
#define CERT_STORE_PROV_REG                 ((LPCSTR) 4)
#define CERT_STORE_PROV_PKCS7               ((LPCSTR) 5)
#define CERT_STORE_PROV_SERIALIZED          ((LPCSTR) 6)
#define CERT_STORE_PROV_FILENAME_A          ((LPCSTR) 7)
#define CERT_STORE_PROV_FILENAME_W          ((LPCSTR) 8)
#define CERT_STORE_PROV_FILENAME            CERT_STORE_PROV_FILENAME_W
#define CERT_STORE_PROV_SYSTEM_A            ((LPCSTR) 9)
#define CERT_STORE_PROV_SYSTEM_W            ((LPCSTR) 10)
#define CERT_STORE_PROV_SYSTEM              CERT_STORE_PROV_SYSTEM_W
#define CERT_STORE_PROV_COLLECTION          ((LPCSTR) 11)
#define CERT_STORE_PROV_SYSTEM_REGISTRY_A   ((LPCSTR) 12)
#define CERT_STORE_PROV_SYSTEM_REGISTRY_W   ((LPCSTR) 13)
#define CERT_STORE_PROV_SYSTEM_REGISTRY     CERT_STORE_PROV_SYSTEM_REGISTRY_W
#define CERT_STORE_PROV_PHYSICAL_W          ((LPCSTR) 14)
#define CERT_STORE_PROV_PHYSICAL            CERT_STORE_PROV_PHYSICAL_W
#define CERT_STORE_PROV_SMART_CARD_W        ((LPCSTR) 15)
#define CERT_STORE_PROV_SMART_CARD          CERT_STORE_PROV_SMART_CARD_W
#define CERT_STORE_PROV_LDAP_W              ((LPCSTR) 16)
#define CERT_STORE_PROV_LDAP                CERT_STORE_PROV_LDAP_W
#define sz_CERT_STORE_PROV_MEMORY           "Memory"
#define sz_CERT_STORE_PROV_FILENAME_W       "File"
#define sz_CERT_STORE_PROV_FILENAME         sz_CERT_STORE_PROV_FILENAME_W
#define sz_CERT_STORE_PROV_SYSTEM_W         "System"
#define sz_CERT_STORE_PROV_SYSTEM           sz_CERT_STORE_PROV_SYSTEM_W
#define sz_CERT_STORE_PROV_PKCS7            "PKCS7"
#define sz_CERT_STORE_PROV_SERIALIZED       "Serialized"
#define sz_CERT_STORE_PROV_COLLECTION       "Collection"
#define sz_CERT_STORE_PROV_SYSTEM_REGISTRY_W "SystemRegistry"
#define sz_CERT_STORE_PROV_SYSTEM_REGISTRY  sz_CERT_STORE_PROV_SYSTEM_REGISTRY_W
#define sz_CERT_STORE_PROV_PHYSICAL_W       "Physical"
#define sz_CERT_STORE_PROV_PHYSICAL         sz_CERT_STORE_PROV_PHYSICAL_W
#define sz_CERT_STORE_PROV_SMART_CARD_W     "SmartCard"
#define sz_CERT_STORE_PROV_SMART_CARD       sz_CERT_STORE_PROV_SMART_CARD_W
#define sz_CERT_STORE_PROV_LDAP_W           "Ldap"
#define sz_CERT_STORE_PROV_LDAP             sz_CERT_STORE_PROV_LDAP_W
#define CERT_STORE_SIGNATURE_FLAG           0x00000001
#define CERT_STORE_TIME_VALIDITY_FLAG       0x00000002
#define CERT_STORE_REVOCATION_FLAG          0x00000004
#define CERT_STORE_NO_CRL_FLAG              0x00010000
#define CERT_STORE_NO_ISSUER_FLAG           0x00020000
#define CERT_STORE_NO_CRYPT_RELEASE_FLAG                0x00000001
#define CERT_STORE_SET_LOCALIZED_NAME_FLAG              0x00000002
#define CERT_STORE_DEFER_CLOSE_UNTIL_LAST_FREE_FLAG     0x00000004
#define CERT_STORE_DELETE_FLAG                          0x00000010
#define CERT_STORE_MANIFOLD_FLAG                        0x00000100
#define CERT_STORE_ENUM_ARCHIVED_FLAG                   0x00000200
#define CERT_STORE_UPDATE_KEYID_FLAG                    0x00000400
#define CERT_STORE_READONLY_FLAG                        0x00008000
#define CERT_STORE_OPEN_EXISTING_FLAG                   0x00004000
#define CERT_STORE_CREATE_NEW_FLAG                      0x00002000
#define CERT_STORE_MAXIMUM_ALLOWED_FLAG                 0x00001000
#define CERT_SYSTEM_STORE_MASK                  0xFFFF0000
#define CERT_SYSTEM_STORE_RELOCATE_FLAG         0x80000000

typedef struct _CERT_SYSTEM_STORE_RELOCATE_PARA {
    union {
        HKEY                hKeyBase;
        void                *pvBase;
    };
    union {
        void                *pvSystemStore;
        LPCSTR              pszSystemStore;
        LPCWSTR             pwszSystemStore;
    };
} CERT_SYSTEM_STORE_RELOCATE_PARA, *PCERT_SYSTEM_STORE_RELOCATE_PARA;

#define CERT_SYSTEM_STORE_UNPROTECTED_FLAG      0x40000000
#define CERT_SYSTEM_STORE_LOCATION_MASK         0x00FF0000
#define CERT_SYSTEM_STORE_LOCATION_SHIFT        16
#define CERT_SYSTEM_STORE_CURRENT_USER_ID       1
#define CERT_SYSTEM_STORE_LOCAL_MACHINE_ID      2
#define CERT_SYSTEM_STORE_CURRENT_SERVICE_ID    4
#define CERT_SYSTEM_STORE_SERVICES_ID           5
#define CERT_SYSTEM_STORE_USERS_ID              6
#define CERT_SYSTEM_STORE_CURRENT_USER_GROUP_POLICY_ID    7
#define CERT_SYSTEM_STORE_LOCAL_MACHINE_GROUP_POLICY_ID   8
#define CERT_SYSTEM_STORE_LOCAL_MACHINE_ENTERPRISE_ID     9
#define CERT_SYSTEM_STORE_CURRENT_USER          \
    (CERT_SYSTEM_STORE_CURRENT_USER_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT)
#define CERT_SYSTEM_STORE_LOCAL_MACHINE         \
    (CERT_SYSTEM_STORE_LOCAL_MACHINE_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT)
#define CERT_SYSTEM_STORE_CURRENT_SERVICE       \
    (CERT_SYSTEM_STORE_CURRENT_SERVICE_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT)
#define CERT_SYSTEM_STORE_SERVICES              \
    (CERT_SYSTEM_STORE_SERVICES_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT)
#define CERT_SYSTEM_STORE_USERS                 \
    (CERT_SYSTEM_STORE_USERS_ID << CERT_SYSTEM_STORE_LOCATION_SHIFT)

#define CERT_SYSTEM_STORE_CURRENT_USER_GROUP_POLICY   \
    (CERT_SYSTEM_STORE_CURRENT_USER_GROUP_POLICY_ID << \
        CERT_SYSTEM_STORE_LOCATION_SHIFT)
#define CERT_SYSTEM_STORE_LOCAL_MACHINE_GROUP_POLICY  \
    (CERT_SYSTEM_STORE_LOCAL_MACHINE_GROUP_POLICY_ID << \
        CERT_SYSTEM_STORE_LOCATION_SHIFT)

#define CERT_SYSTEM_STORE_LOCAL_MACHINE_ENTERPRISE  \
    (CERT_SYSTEM_STORE_LOCAL_MACHINE_ENTERPRISE_ID << \
        CERT_SYSTEM_STORE_LOCATION_SHIFT)

#define CERT_GROUP_POLICY_SYSTEM_STORE_REGPATH \
    L"Software\\Policies\\Microsoft\\SystemCertificates"

#define CERT_EFSBLOB_REGPATH    \
    CERT_GROUP_POLICY_SYSTEM_STORE_REGPATH L"\\EFS"
#define CERT_EFSBLOB_VALUE_NAME L"EFSBlob"
#define CERT_PROT_ROOT_FLAGS_REGPATH    \
    CERT_GROUP_POLICY_SYSTEM_STORE_REGPATH L"\\Root\\ProtectedRoots"
#define CERT_PROT_ROOT_FLAGS_VALUE_NAME L"Flags"
#define CERT_PROT_ROOT_DISABLE_CURRENT_USER_FLAG    0x1
#define CERT_PROT_ROOT_INHIBIT_ADD_AT_INIT_FLAG     0x2
#define CERT_PROT_ROOT_INHIBIT_PURGE_LM_FLAG        0x4
#define CERT_PROT_ROOT_ONLY_LM_GPT_FLAG             0x8
#define CERT_REGISTRY_STORE_REMOTE_FLAG         0x10000
#define CERT_REGISTRY_STORE_SERIALIZED_FLAG     0x20000
#define CERT_REGISTRY_STORE_CLIENT_GPT_FLAG     0x80000000
#define CERT_REGISTRY_STORE_LM_GPT_FLAG         0x01000000

typedef struct _CERT_REGISTRY_STORE_CLIENT_GPT_PARA {
    HKEY                hKeyBase;
    LPWSTR              pwszRegPath;
} CERT_REGISTRY_STORE_CLIENT_GPT_PARA, *PCERT_REGISTRY_STORE_CLIENT_GPT_PARA;

#define CERT_REGISTRY_STORE_ROAMING_FLAG        0x40000

typedef struct _CERT_REGISTRY_STORE_ROAMING_PARA {
    HKEY                hKey;
    LPWSTR              pwszStoreDirectory;
} CERT_REGISTRY_STORE_ROAMING_PARA, *PCERT_REGISTRY_STORE_ROAMING_PARA;

#define CERT_IE_DIRTY_FLAGS_REGPATH \
    L"Software\\Microsoft\\Cryptography\\IEDirtyFlags"

#define CERT_FILE_STORE_COMMIT_ENABLE_FLAG      0x10000

WINCRYPT32API
HCERTSTORE
WINAPI
CertOpenStore(
    LPCSTR lpszStoreProvider,
    DWORD dwEncodingType,
    HCRYPTPROV hCryptProv,
    DWORD dwFlags,
    const void *pvPara
    );

typedef void *HCERTSTOREPROV;

#define CRYPT_OID_OPEN_STORE_PROV_FUNC   "CertDllOpenStoreProv"

typedef struct _CERT_STORE_PROV_INFO {
    DWORD               cbSize;
    DWORD               cStoreProvFunc;
    void                **rgpvStoreProvFunc;
    HCERTSTOREPROV      hStoreProv;
    DWORD               dwStoreProvFlags;
    HCRYPTOIDFUNCADDR   hStoreProvFuncAddr2;
} CERT_STORE_PROV_INFO, *PCERT_STORE_PROV_INFO;

typedef BOOL (WINAPI *PFN_CERT_DLL_OPEN_STORE_PROV_FUNC)(
    LPCSTR lpszStoreProvider,
    DWORD dwEncodingType,
    HCRYPTPROV hCryptProv,
    DWORD dwFlags,
    const void *pvPara,
    HCERTSTORE hCertStore,
    PCERT_STORE_PROV_INFO pStoreProvInfo
    );

#define CERT_STORE_PROV_EXTERNAL_FLAG           0x1
#define CERT_STORE_PROV_DELETED_FLAG            0x2
#define CERT_STORE_PROV_NO_PERSIST_FLAG         0x4
#define CERT_STORE_PROV_SYSTEM_STORE_FLAG       0x8
#define CERT_STORE_PROV_CLOSE_FUNC              0
#define CERT_STORE_PROV_READ_CERT_FUNC          1
#define CERT_STORE_PROV_WRITE_CERT_FUNC         2
#define CERT_STORE_PROV_DELETE_CERT_FUNC        3
#define CERT_STORE_PROV_SET_CERT_PROPERTY_FUNC  4
#define CERT_STORE_PROV_READ_CRL_FUNC           5
#define CERT_STORE_PROV_WRITE_CRL_FUNC          6
#define CERT_STORE_PROV_DELETE_CRL_FUNC         7
#define CERT_STORE_PROV_SET_CRL_PROPERTY_FUNC   8
#define CERT_STORE_PROV_READ_CTL_FUNC           9
#define CERT_STORE_PROV_WRITE_CTL_FUNC          10
#define CERT_STORE_PROV_DELETE_CTL_FUNC         11
#define CERT_STORE_PROV_SET_CTL_PROPERTY_FUNC   12
#define CERT_STORE_PROV_CONTROL_FUNC            13
#define CERT_STORE_PROV_FIND_CERT_FUNC          14
#define CERT_STORE_PROV_FREE_FIND_CERT_FUNC     15
#define CERT_STORE_PROV_GET_CERT_PROPERTY_FUNC  16
#define CERT_STORE_PROV_FIND_CRL_FUNC           17
#define CERT_STORE_PROV_FREE_FIND_CRL_FUNC      18
#define CERT_STORE_PROV_GET_CRL_PROPERTY_FUNC   19
#define CERT_STORE_PROV_FIND_CTL_FUNC           20
#define CERT_STORE_PROV_FREE_FIND_CTL_FUNC      21
#define CERT_STORE_PROV_GET_CTL_PROPERTY_FUNC   22

typedef void (WINAPI *PFN_CERT_STORE_PROV_CLOSE)(
    HCERTSTOREPROV hStoreProv,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_READ_CERT)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_CONTEXT pStoreCertContext,
    DWORD dwFlags,
    PCCERT_CONTEXT *ppProvCertContext
    );

#define CERT_STORE_PROV_WRITE_ADD_FLAG      0x1

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_WRITE_CERT)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_CONTEXT pCertContext,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_DELETE_CERT)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_CONTEXT pCertContext,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_SET_CERT_PROPERTY)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_CONTEXT pCertContext,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_READ_CRL)(
    HCERTSTOREPROV hStoreProv,
    PCCRL_CONTEXT pStoreCrlContext,
    DWORD dwFlags,
    PCCRL_CONTEXT *ppProvCrlContext
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_WRITE_CRL)(
    HCERTSTOREPROV hStoreProv,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_DELETE_CRL)(
    HCERTSTOREPROV hStoreProv,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_SET_CRL_PROPERTY)(
    HCERTSTOREPROV hStoreProv,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_READ_CTL)(
    HCERTSTOREPROV hStoreProv,
    PCCTL_CONTEXT pStoreCtlContext,
    DWORD dwFlags,
    PCCTL_CONTEXT *ppProvCtlContext
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_WRITE_CTL)(
    HCERTSTOREPROV hStoreProv,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_DELETE_CTL)(
    HCERTSTOREPROV hStoreProv,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwFlags
                                                     );
typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_SET_CTL_PROPERTY)(
    HCERTSTOREPROV hStoreProv,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_CONTROL)(
    HCERTSTOREPROV hStoreProv,
    DWORD dwFlags,
    DWORD dwCtrlType,
    void const *pvCtrlPara
    );

typedef struct _CERT_STORE_PROV_FIND_INFO {
    DWORD               cbSize;
    DWORD               dwMsgAndCertEncodingType;
    DWORD               dwFindFlags;
    DWORD               dwFindType;
    const void          *pvFindPara;
} CERT_STORE_PROV_FIND_INFO, *PCERT_STORE_PROV_FIND_INFO;
typedef const CERT_STORE_PROV_FIND_INFO CCERT_STORE_PROV_FIND_INFO,
*PCCERT_STORE_PROV_FIND_INFO;

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_FIND_CERT)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_STORE_PROV_FIND_INFO pFindInfo,
    PCCERT_CONTEXT pPrevCertContext,
    DWORD dwFlags,
    void **ppvStoreProvFindInfo,
    PCCERT_CONTEXT *ppProvCertContext
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_FREE_FIND_CERT)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_CONTEXT pCertContext,
    void *pvStoreProvFindInfo,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_GET_CERT_PROPERTY)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_CONTEXT pCertContext,
    DWORD dwPropId,
    DWORD dwFlags,
    void *pvData,
    DWORD *pcbData
    );


typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_FIND_CRL)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_STORE_PROV_FIND_INFO pFindInfo,
    PCCRL_CONTEXT pPrevCrlContext,
    DWORD dwFlags,
    void **ppvStoreProvFindInfo,
    PCCRL_CONTEXT *ppProvCrlContext
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_FREE_FIND_CRL)(
    HCERTSTOREPROV hStoreProv,
    PCCRL_CONTEXT pCrlContext,
    void *pvStoreProvFindInfo,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_GET_CRL_PROPERTY)(
    HCERTSTOREPROV hStoreProv,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwPropId,
    DWORD dwFlags,
    void *pvData,
    DWORD *pcbData
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_FIND_CTL)(
    HCERTSTOREPROV hStoreProv,
    PCCERT_STORE_PROV_FIND_INFO pFindInfo,
    PCCTL_CONTEXT pPrevCtlContext,
    DWORD dwFlags,
    void **ppvStoreProvFindInfo,
    PCCTL_CONTEXT *ppProvCtlContext
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_FREE_FIND_CTL)(
    HCERTSTOREPROV hStoreProv,
    PCCTL_CONTEXT pCtlContext,
    void *pvStoreProvFindInfo,
    DWORD dwFlags
    );

typedef BOOL (WINAPI *PFN_CERT_STORE_PROV_GET_CTL_PROPERTY)(
    HCERTSTOREPROV hStoreProv,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwPropId,
    DWORD dwFlags,
    void *pvData,
    DWORD *pcbData
    );

WINCRYPT32API
HCERTSTORE
WINAPI
CertDuplicateStore(
    HCERTSTORE hCertStore
    );

#define CERT_STORE_SAVE_AS_STORE        1
#define CERT_STORE_SAVE_AS_PKCS7        2
#define CERT_STORE_SAVE_TO_FILE         1
#define CERT_STORE_SAVE_TO_MEMORY       2
#define CERT_STORE_SAVE_TO_FILENAME_A   3
#define CERT_STORE_SAVE_TO_FILENAME_W   4
#define CERT_STORE_SAVE_TO_FILENAME     CERT_STORE_SAVE_TO_FILENAME_W

WINCRYPT32API
BOOL
WINAPI
CertSaveStore(
    HCERTSTORE hCertStore,
    DWORD dwEncodingType,
    DWORD dwSaveAs,
    DWORD dwSaveTo,
    void *pvSaveToPara,
    DWORD dwFlags
    );

#define CERT_CLOSE_STORE_FORCE_FLAG         0x00000001
#define CERT_CLOSE_STORE_CHECK_FLAG         0x00000002

WINCRYPT32API
BOOL
WINAPI
CertCloseStore(
    HCERTSTORE hCertStore,
    DWORD dwFlags
    );

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertGetSubjectCertificateFromStore(
    HCERTSTORE hCertStore,
    DWORD dwCertEncodingType,
    PCERT_INFO pCertId
    );

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertEnumCertificatesInStore(
    HCERTSTORE hCertStore,
    PCCERT_CONTEXT pPrevCertContext
    );

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertFindCertificateInStore(
    HCERTSTORE hCertStore,
    DWORD dwCertEncodingType,
    DWORD dwFindFlags,
    DWORD dwFindType,
    const void *pvFindPara,
    PCCERT_CONTEXT pPrevCertContext
    );

#define CERT_COMPARE_MASK           0xFFFF
#define CERT_COMPARE_SHIFT          16
#define CERT_COMPARE_ANY            0
#define CERT_COMPARE_SHA1_HASH      1
#define CERT_COMPARE_NAME           2
#define CERT_COMPARE_ATTR           3
#define CERT_COMPARE_MD5_HASH       4
#define CERT_COMPARE_PROPERTY       5
#define CERT_COMPARE_PUBLIC_KEY     6
#define CERT_COMPARE_HASH           CERT_COMPARE_SHA1_HASH
#define CERT_COMPARE_NAME_STR_A     7
#define CERT_COMPARE_NAME_STR_W     8
#define CERT_COMPARE_KEY_SPEC       9
#define CERT_COMPARE_ENHKEY_USAGE   10
#define CERT_COMPARE_CTL_USAGE      CERT_COMPARE_ENHKEY_USAGE
#define CERT_COMPARE_SUBJECT_CERT   11
#define CERT_COMPARE_ISSUER_OF      12
#define CERT_COMPARE_EXISTING       13
#define CERT_COMPARE_SIGNATURE_HASH 14
#define CERT_COMPARE_KEY_IDENTIFIER 15
#define CERT_COMPARE_CERT_ID        16
#define CERT_FIND_ANY           (CERT_COMPARE_ANY << CERT_COMPARE_SHIFT)
#define CERT_FIND_SHA1_HASH     (CERT_COMPARE_SHA1_HASH << CERT_COMPARE_SHIFT)
#define CERT_FIND_MD5_HASH      (CERT_COMPARE_MD5_HASH << CERT_COMPARE_SHIFT)
#define CERT_FIND_SIGNATURE_HASH (CERT_COMPARE_SIGNATURE_HASH << CERT_COMPARE_SHIFT)
#define CERT_FIND_KEY_IDENTIFIER (CERT_COMPARE_KEY_IDENTIFIER << CERT_COMPARE_SHIFT)
#define CERT_FIND_HASH          CERT_FIND_SHA1_HASH
#define CERT_FIND_PROPERTY      (CERT_COMPARE_PROPERTY << CERT_COMPARE_SHIFT)
#define CERT_FIND_PUBLIC_KEY    (CERT_COMPARE_PUBLIC_KEY << CERT_COMPARE_SHIFT)
#define CERT_FIND_SUBJECT_NAME  (CERT_COMPARE_NAME << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_SUBJECT_FLAG)
#define CERT_FIND_SUBJECT_ATTR  (CERT_COMPARE_ATTR << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_SUBJECT_FLAG)
#define CERT_FIND_ISSUER_NAME   (CERT_COMPARE_NAME << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_ISSUER_FLAG)
#define CERT_FIND_ISSUER_ATTR   (CERT_COMPARE_ATTR << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_ISSUER_FLAG)
#define CERT_FIND_SUBJECT_STR_A (CERT_COMPARE_NAME_STR_A << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_SUBJECT_FLAG)
#define CERT_FIND_SUBJECT_STR_W (CERT_COMPARE_NAME_STR_W << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_SUBJECT_FLAG)
#define CERT_FIND_SUBJECT_STR   CERT_FIND_SUBJECT_STR_W
#define CERT_FIND_ISSUER_STR_A  (CERT_COMPARE_NAME_STR_A << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_ISSUER_FLAG)
#define CERT_FIND_ISSUER_STR_W  (CERT_COMPARE_NAME_STR_W << CERT_COMPARE_SHIFT | \
                                 CERT_INFO_ISSUER_FLAG)
#define CERT_FIND_ISSUER_STR    CERT_FIND_ISSUER_STR_W
#define CERT_FIND_KEY_SPEC      (CERT_COMPARE_KEY_SPEC << CERT_COMPARE_SHIFT)
#define CERT_FIND_ENHKEY_USAGE  (CERT_COMPARE_ENHKEY_USAGE << CERT_COMPARE_SHIFT)
#define CERT_FIND_CTL_USAGE     CERT_FIND_ENHKEY_USAGE
#define CERT_FIND_SUBJECT_CERT  (CERT_COMPARE_SUBJECT_CERT << CERT_COMPARE_SHIFT)
#define CERT_FIND_ISSUER_OF     (CERT_COMPARE_ISSUER_OF << CERT_COMPARE_SHIFT)
#define CERT_FIND_EXISTING      (CERT_COMPARE_EXISTING << CERT_COMPARE_SHIFT)
#define CERT_FIND_CERT_ID       (CERT_COMPARE_CERT_ID << CERT_COMPARE_SHIFT)
#define CERT_FIND_OPTIONAL_ENHKEY_USAGE_FLAG  0x1
#define CERT_FIND_EXT_ONLY_ENHKEY_USAGE_FLAG  0x2
#define CERT_FIND_PROP_ONLY_ENHKEY_USAGE_FLAG 0x4
#define CERT_FIND_NO_ENHKEY_USAGE_FLAG        0x8
#define CERT_FIND_OR_ENHKEY_USAGE_FLAG        0x10
#define CERT_FIND_VALID_ENHKEY_USAGE_FLAG     0x20
#define CERT_FIND_OPTIONAL_CTL_USAGE_FLAG   CERT_FIND_OPTIONAL_ENHKEY_USAGE_FLAG
#define CERT_FIND_EXT_ONLY_CTL_USAGE_FLAG \
        CERT_FIND_EXT_ONLY_ENHKEY_USAGE_FLAG
#define CERT_FIND_PROP_ONLY_CTL_USAGE_FLAG \
        CERT_FIND_PROP_ONLY_ENHKEY_USAGE_FLAG
#define CERT_FIND_NO_CTL_USAGE_FLAG         CERT_FIND_NO_ENHKEY_USAGE_FLAG
#define CERT_FIND_OR_CTL_USAGE_FLAG         CERT_FIND_OR_ENHKEY_USAGE_FLAG
#define CERT_FIND_VALID_CTL_USAGE_FLAG      CERT_FIND_VALID_ENHKEY_USAGE_FLAG

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertGetIssuerCertificateFromStore(
    HCERTSTORE hCertStore,
    PCCERT_CONTEXT pSubjectContext,
    OPTIONAL PCCERT_CONTEXT pPrevIssuerContext,
    DWORD *pdwFlags
    );

WINCRYPT32API
BOOL
WINAPI
CertVerifySubjectCertificateContext(
    PCCERT_CONTEXT pSubject,
    OPTIONAL PCCERT_CONTEXT pIssuer,
    DWORD *pdwFlags
    );

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertDuplicateCertificateContext(
    PCCERT_CONTEXT pCertContext
    );

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertCreateCertificateContext(
    DWORD dwCertEncodingType,
    const BYTE *pbCertEncoded,
    DWORD cbCertEncoded
    );

WINCRYPT32API
BOOL
WINAPI
CertFreeCertificateContext(
    PCCERT_CONTEXT pCertContext
    );

WINCRYPT32API
BOOL
WINAPI
CertSetCertificateContextProperty(
    PCCERT_CONTEXT pCertContext,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

#define CERT_SET_PROPERTY_IGNORE_PERSIST_ERROR_FLAG     0x80000000

WINCRYPT32API
BOOL
WINAPI
CertGetCertificateContextProperty(
    PCCERT_CONTEXT pCertContext,
    DWORD dwPropId,
    void *pvData,
    DWORD *pcbData
    );

WINCRYPT32API
DWORD
WINAPI
CertEnumCertificateContextProperties(
    PCCERT_CONTEXT pCertContext,
    DWORD dwPropId
    );

WINCRYPT32API
PCCRL_CONTEXT
WINAPI
CertGetCRLFromStore(
    HCERTSTORE hCertStore,
    OPTIONAL PCCERT_CONTEXT pIssuerContext,
    PCCRL_CONTEXT pPrevCrlContext,
    DWORD *pdwFlags
    );

WINCRYPT32API
PCCRL_CONTEXT
WINAPI
CertEnumCRLsInStore(
    HCERTSTORE hCertStore,
    PCCRL_CONTEXT pPrevCrlContext
    );

WINCRYPT32API
PCCRL_CONTEXT
WINAPI
CertFindCRLInStore(
    HCERTSTORE hCertStore,
    DWORD dwCertEncodingType,
    DWORD dwFindFlags,
    DWORD dwFindType,
    const void *pvFindPara,
    PCCRL_CONTEXT pPrevCrlContext
    );

#define CRL_FIND_ANY                0
#define CRL_FIND_ISSUED_BY          1
#define CRL_FIND_EXISTING           2
#define CRL_FIND_ISSUED_BY_AKI_FLAG         0x1
#define CRL_FIND_ISSUED_BY_SIGNATURE_FLAG   0x2

WINCRYPT32API
PCCRL_CONTEXT
WINAPI
CertDuplicateCRLContext(
    PCCRL_CONTEXT pCrlContext
    );

WINCRYPT32API
PCCRL_CONTEXT
WINAPI
CertCreateCRLContext(
    DWORD dwCertEncodingType,
    const BYTE *pbCrlEncoded,
    DWORD cbCrlEncoded
    );

WINCRYPT32API
BOOL
WINAPI
CertFreeCRLContext(
    PCCRL_CONTEXT pCrlContext
    );

WINCRYPT32API
BOOL
WINAPI
CertSetCRLContextProperty(
    PCCRL_CONTEXT pCrlContext,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

WINCRYPT32API
BOOL
WINAPI
CertGetCRLContextProperty(
    PCCRL_CONTEXT pCrlContext,
    DWORD dwPropId,
    void *pvData,
    DWORD *pcbData
    );

WINCRYPT32API
DWORD
WINAPI
CertEnumCRLContextProperties(
    PCCRL_CONTEXT pCrlContext,
    DWORD dwPropId
    );

WINCRYPT32API
BOOL
WINAPI
CertFindCertificateInCRL(
    PCCERT_CONTEXT pCert,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwFlags,
    OPTIONAL void *pvReserved,
    PCRL_ENTRY *ppCrlEntry
    );

#define CERT_STORE_ADD_NEW                                  1
#define CERT_STORE_ADD_USE_EXISTING                         2
#define CERT_STORE_ADD_REPLACE_EXISTING                     3
#define CERT_STORE_ADD_ALWAYS                               4
#define CERT_STORE_ADD_REPLACE_EXISTING_INHERIT_PROPERTIES  5
#define CERT_STORE_ADD_NEWER                                6
#define CERT_STORE_ADD_NEWER_INHERIT_PROPERTIES             7

WINCRYPT32API
BOOL
WINAPI
CertAddEncodedCertificateToStore(
    HCERTSTORE hCertStore,
    DWORD dwCertEncodingType,
    const BYTE *pbCertEncoded,
    DWORD cbCertEncoded,
    DWORD dwAddDisposition,
    OPTIONAL PCCERT_CONTEXT *ppCertContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddCertificateContextToStore(
    HCERTSTORE hCertStore,
    PCCERT_CONTEXT pCertContext,
    DWORD dwAddDisposition,
    OPTIONAL PCCERT_CONTEXT *ppStoreContext
    );

#define CERT_STORE_CERTIFICATE_CONTEXT  1
#define CERT_STORE_CRL_CONTEXT          2
#define CERT_STORE_CTL_CONTEXT          3
#define CERT_STORE_ALL_CONTEXT_FLAG             (~0UL)
#define CERT_STORE_CERTIFICATE_CONTEXT_FLAG     \
                (1 << CERT_STORE_CERTIFICATE_CONTEXT)
#define CERT_STORE_CRL_CONTEXT_FLAG             \
                (1 << CERT_STORE_CRL_CONTEXT)
#define CERT_STORE_CTL_CONTEXT_FLAG             \
                (1 << CERT_STORE_CTL_CONTEXT)

WINCRYPT32API
BOOL
WINAPI
CertAddSerializedElementToStore(
    HCERTSTORE hCertStore,
    const BYTE *pbElement,
    DWORD cbElement,
    DWORD dwAddDisposition,
    DWORD dwFlags,
    DWORD dwContextTypeFlags,
    OPTIONAL DWORD *pdwContextType,
    OPTIONAL const void **ppvContext
    );

WINCRYPT32API
BOOL
WINAPI
CertDeleteCertificateFromStore(
    PCCERT_CONTEXT pCertContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddEncodedCRLToStore(
    HCERTSTORE hCertStore,
    DWORD dwCertEncodingType,
    const BYTE *pbCrlEncoded,
    DWORD cbCrlEncoded,
    DWORD dwAddDisposition,
    OPTIONAL PCCRL_CONTEXT *ppCrlContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddCRLContextToStore(
    HCERTSTORE hCertStore,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwAddDisposition,
    OPTIONAL PCCRL_CONTEXT *ppStoreContext
    );

WINCRYPT32API
BOOL
WINAPI
CertDeleteCRLFromStore(
    PCCRL_CONTEXT pCrlContext
    );

WINCRYPT32API
BOOL
WINAPI
CertSerializeCertificateStoreElement(
    PCCERT_CONTEXT pCertContext,
    DWORD dwFlags,
    BYTE *pbElement,
    DWORD *pcbElement
    );

WINCRYPT32API
BOOL
WINAPI
CertSerializeCRLStoreElement(
    PCCRL_CONTEXT pCrlContext,
    DWORD dwFlags,
    BYTE *pbElement,
    DWORD *pcbElement
    );

WINCRYPT32API
PCCTL_CONTEXT
WINAPI
CertDuplicateCTLContext(
    PCCTL_CONTEXT pCtlContext
    );

WINCRYPT32API
PCCTL_CONTEXT
WINAPI
CertCreateCTLContext(
    DWORD dwMsgAndCertEncodingType,
    const BYTE *pbCtlEncoded,
    DWORD cbCtlEncoded
    );

WINCRYPT32API
BOOL
WINAPI
CertFreeCTLContext(
    PCCTL_CONTEXT pCtlContext
    );

WINCRYPT32API
BOOL
WINAPI
CertSetCTLContextProperty(
    PCCTL_CONTEXT pCtlContext,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

WINCRYPT32API
BOOL
WINAPI
CertGetCTLContextProperty(
    PCCTL_CONTEXT pCtlContext,
    DWORD dwPropId,
    void *pvData,
    DWORD *pcbData
    );

WINCRYPT32API
DWORD
WINAPI
CertEnumCTLContextProperties(
    PCCTL_CONTEXT pCtlContext,
    DWORD dwPropId
    );

WINCRYPT32API
PCCTL_CONTEXT
WINAPI
CertEnumCTLsInStore(
    HCERTSTORE hCertStore,
    PCCTL_CONTEXT pPrevCtlContext
    );

WINCRYPT32API
PCTL_ENTRY
WINAPI
CertFindSubjectInCTL(
    DWORD dwEncodingType,
    DWORD dwSubjectType,
    void *pvSubject,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwFlags
    );

#define CTL_ANY_SUBJECT_TYPE            1
#define CTL_CERT_SUBJECT_TYPE           2

typedef struct _CTL_ANY_SUBJECT_INFO {
    CRYPT_ALGORITHM_IDENTIFIER  SubjectAlgorithm;
    CRYPT_DATA_BLOB             SubjectIdentifier;
} CTL_ANY_SUBJECT_INFO, *PCTL_ANY_SUBJECT_INFO;

WINCRYPT32API
PCCTL_CONTEXT
WINAPI
CertFindCTLInStore(
    HCERTSTORE hCertStore,
    DWORD dwMsgAndCertEncodingType,
    DWORD dwFindFlags,
    DWORD dwFindType,
    const void *pvFindPara,
    PCCTL_CONTEXT pPrevCtlContext
    );

#define CTL_FIND_ANY                0
#define CTL_FIND_SHA1_HASH          1
#define CTL_FIND_MD5_HASH           2
#define CTL_FIND_USAGE              3
#define CTL_FIND_SUBJECT            4
#define CTL_FIND_EXISTING           5

typedef struct _CTL_FIND_USAGE_PARA {
    DWORD               cbSize;
    CTL_USAGE           SubjectUsage;   // optional
    CRYPT_DATA_BLOB     ListIdentifier; // optional
    PCERT_INFO          pSigner;        // optional
} CTL_FIND_USAGE_PARA, *PCTL_FIND_USAGE_PARA;

#define CTL_FIND_NO_LIST_ID_CBDATA  0xFFFFFFFF
#define CTL_FIND_NO_SIGNER_PTR      ((PCERT_INFO) -1)

#define CTL_FIND_SAME_USAGE_FLAG    0x1


typedef struct _CTL_FIND_SUBJECT_PARA {
    DWORD                   cbSize;
    PCTL_FIND_USAGE_PARA    pUsagePara; // optional
    DWORD                   dwSubjectType;
    void                    *pvSubject;
} CTL_FIND_SUBJECT_PARA, *PCTL_FIND_SUBJECT_PARA;

WINCRYPT32API
BOOL
WINAPI
CertAddEncodedCTLToStore(
    HCERTSTORE hCertStore,
    DWORD dwMsgAndCertEncodingType,
    const BYTE *pbCtlEncoded,
    DWORD cbCtlEncoded,
    DWORD dwAddDisposition,
    OPTIONAL PCCTL_CONTEXT *ppCtlContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddCTLContextToStore(
    HCERTSTORE hCertStore,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwAddDisposition,
    OPTIONAL PCCTL_CONTEXT *ppStoreContext
    );

WINCRYPT32API
BOOL
WINAPI
CertSerializeCTLStoreElement(
    PCCTL_CONTEXT pCtlContext,
    DWORD dwFlags,
    BYTE *pbElement,
    DWORD *pcbElement
    );

WINCRYPT32API
BOOL
WINAPI
CertDeleteCTLFromStore(
    PCCTL_CONTEXT pCtlContext
    );


WINCRYPT32API
BOOL
WINAPI
CertAddCertificateLinkToStore(
    HCERTSTORE hCertStore,
    PCCERT_CONTEXT pCertContext,
    DWORD dwAddDisposition,
    OPTIONAL PCCERT_CONTEXT *ppStoreContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddCRLLinkToStore(
    HCERTSTORE hCertStore,
    PCCRL_CONTEXT pCrlContext,
    DWORD dwAddDisposition,
    OPTIONAL PCCRL_CONTEXT *ppStoreContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddCTLLinkToStore(
    HCERTSTORE hCertStore,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwAddDisposition,
    OPTIONAL PCCTL_CONTEXT *ppStoreContext
    );

WINCRYPT32API
BOOL
WINAPI
CertAddStoreToCollection(
    HCERTSTORE hCollectionStore,
    OPTIONAL HCERTSTORE hSiblingStore,
    DWORD dwUpdateFlags,
    DWORD dwPriority
    );

WINCRYPT32API
void
WINAPI
CertRemoveStoreFromCollection(
    HCERTSTORE hCollectionStore,
    HCERTSTORE hSiblingStore
    );


WINCRYPT32API
BOOL
WINAPI
CertControlStore(
    HCERTSTORE hCertStore,
    DWORD dwFlags,
    DWORD dwCtrlType,
    void const *pvCtrlPara
    );

#define CERT_STORE_CTRL_RESYNC              1
#define CERT_STORE_CTRL_NOTIFY_CHANGE       2
#define CERT_STORE_CTRL_COMMIT              3
#define CERT_STORE_CTRL_AUTO_RESYNC         4
#define CERT_STORE_CTRL_COMMIT_FORCE_FLAG   0x1
#define CERT_STORE_CTRL_COMMIT_CLEAR_FLAG   0x2
#define CERT_STORE_LOCALIZED_NAME_PROP_ID   0x1000

WINCRYPT32API
BOOL
WINAPI
CertSetStoreProperty(
    HCERTSTORE hCertStore,
    DWORD dwPropId,
    DWORD dwFlags,
    const void *pvData
    );

WINCRYPT32API
BOOL
WINAPI
CertGetStoreProperty(
    HCERTSTORE hCertStore,
    DWORD dwPropId,
    void *pvData,
    DWORD *pcbData
    );


typedef struct _CERT_CREATE_CONTEXT_PARA {
    DWORD                   cbSize;
    PFN_CRYPT_FREE          pfnFree;            // OPTIONAL
    void                    *pvFree;            // OPTIONAL
} CERT_CREATE_CONTEXT_PARA, *PCERT_CREATE_CONTEXT_PARA;

WINCRYPT32API
const void *
WINAPI
CertCreateContext(
    DWORD dwContextType,
    DWORD dwEncodingType,
    const BYTE *pbEncoded,
    DWORD cbEncoded,
    DWORD dwFlags,
    OPTIONAL PCERT_CREATE_CONTEXT_PARA pCreatePara
    );

#define CERT_CREATE_CONTEXT_NOCOPY_FLAG     0x1
#define CERT_CREATE_CONTEXT_SORTED_FLAG     0x2
#define CERT_CREATE_CONTEXT_NO_HCRYPTMSG_FLAG   0x4
#define CERT_CREATE_CONTEXT_NO_ENTRY_FLAG       0x8

typedef struct _CERT_SYSTEM_STORE_INFO {
    DWORD   cbSize;
} CERT_SYSTEM_STORE_INFO, *PCERT_SYSTEM_STORE_INFO;

typedef struct _CERT_PHYSICAL_STORE_INFO {
    DWORD               cbSize;
    LPSTR               pszOpenStoreProvider;   // REG_SZ
    DWORD               dwOpenEncodingType;     // REG_DWORD
    DWORD               dwOpenFlags;            // REG_DWORD
    CRYPT_DATA_BLOB     OpenParameters;         // REG_BINARY
    DWORD               dwFlags;                // REG_DWORD
    DWORD               dwPriority;             // REG_DWORD
} CERT_PHYSICAL_STORE_INFO, *PCERT_PHYSICAL_STORE_INFO;

#define CERT_PHYSICAL_STORE_ADD_ENABLE_FLAG                     0x1
#define CERT_PHYSICAL_STORE_OPEN_DISABLE_FLAG                   0x2
#define CERT_PHYSICAL_STORE_REMOTE_OPEN_DISABLE_FLAG            0x4
#define CERT_PHYSICAL_STORE_INSERT_COMPUTER_NAME_ENABLE_FLAG    0x8

WINCRYPT32API
BOOL
WINAPI
CertRegisterSystemStore(
    const void *pvSystemStore,
    DWORD dwFlags,
    PCERT_SYSTEM_STORE_INFO pStoreInfo,
    OPTIONAL void *pvReserved
    );

WINCRYPT32API
BOOL
WINAPI
CertRegisterPhysicalStore(
    const void *pvSystemStore,
    DWORD dwFlags,
    LPCWSTR pwszStoreName,
    PCERT_PHYSICAL_STORE_INFO pStoreInfo,
    OPTIONAL void *pvReserved
    );

WINCRYPT32API
BOOL
WINAPI
CertUnregisterSystemStore(
    const void *pvSystemStore,
    DWORD dwFlags
    );
WINCRYPT32API
BOOL
WINAPI
CertUnregisterPhysicalStore(
    const void *pvSystemStore,
    DWORD dwFlags,
    LPCWSTR pwszStoreName
    );

typedef BOOL (WINAPI *PFN_CERT_ENUM_SYSTEM_STORE_LOCATION)(
    LPCWSTR pwszStoreLocation,
    DWORD dwFlags,
    OPTIONAL void *pvReserved,
    OPTIONAL void *pvArg
    );

typedef BOOL (WINAPI *PFN_CERT_ENUM_SYSTEM_STORE)(
    const void *pvSystemStore,
    DWORD dwFlags,
    PCERT_SYSTEM_STORE_INFO pStoreInfo,
    OPTIONAL void *pvReserved,
    OPTIONAL void *pvArg
    );

typedef BOOL (WINAPI *PFN_CERT_ENUM_PHYSICAL_STORE)(
    const void *pvSystemStore,
    DWORD dwFlags,
    LPCWSTR pwszStoreName,
    PCERT_PHYSICAL_STORE_INFO pStoreInfo,
    OPTIONAL void *pvReserved,
    OPTIONAL void *pvArg
    );

#define CERT_PHYSICAL_STORE_PREDEFINED_ENUM_FLAG    0x1
#define CERT_PHYSICAL_STORE_DEFAULT_NAME            L".Default"
#define CERT_PHYSICAL_STORE_GROUP_POLICY_NAME       L".GroupPolicy"
#define CERT_PHYSICAL_STORE_LOCAL_MACHINE_NAME      L".LocalMachine"
#define CERT_PHYSICAL_STORE_DS_USER_CERTIFICATE_NAME L".UserCertificate"
#define CERT_PHYSICAL_STORE_LOCAL_MACHINE_GROUP_POLICY_NAME \
            L".LocalMachineGroupPolicy"
#define CERT_PHYSICAL_STORE_ENTERPRISE_NAME         L".Enterprise"

WINCRYPT32API
BOOL
WINAPI
CertEnumSystemStoreLocation(
    DWORD dwFlags,
    void *pvArg,
    PFN_CERT_ENUM_SYSTEM_STORE_LOCATION pfnEnum
    );

WINCRYPT32API
BOOL
WINAPI
CertEnumSystemStore(
    DWORD dwFlags,
    OPTIONAL void *pvSystemStoreLocationPara,
    void *pvArg,
    PFN_CERT_ENUM_SYSTEM_STORE pfnEnum
    );

WINCRYPT32API
BOOL
WINAPI
CertEnumPhysicalStore(
    const void *pvSystemStore,
    DWORD dwFlags,
    void *pvArg,
    PFN_CERT_ENUM_PHYSICAL_STORE pfnEnum
    );

#define CRYPT_OID_OPEN_SYSTEM_STORE_PROV_FUNC   "CertDllOpenSystemStoreProv"
#define CRYPT_OID_REGISTER_SYSTEM_STORE_FUNC    "CertDllRegisterSystemStore"
#define CRYPT_OID_UNREGISTER_SYSTEM_STORE_FUNC  "CertDllUnregisterSystemStore"
#define CRYPT_OID_ENUM_SYSTEM_STORE_FUNC        "CertDllEnumSystemStore"
#define CRYPT_OID_REGISTER_PHYSICAL_STORE_FUNC  "CertDllRegisterPhysicalStore"
#define CRYPT_OID_UNREGISTER_PHYSICAL_STORE_FUNC "CertDllUnregisterPhysicalStore"
#define CRYPT_OID_ENUM_PHYSICAL_STORE_FUNC      "CertDllEnumPhysicalStore"
#define CRYPT_OID_SYSTEM_STORE_LOCATION_VALUE_NAME  L"SystemStoreLocation"

WINCRYPT32API
BOOL
WINAPI
CertGetEnhancedKeyUsage(
    PCCERT_CONTEXT pCertContext,
    DWORD dwFlags,
    PCERT_ENHKEY_USAGE pUsage,
    DWORD *pcbUsage
    );

WINCRYPT32API
BOOL
WINAPI
CertSetEnhancedKeyUsage(
    PCCERT_CONTEXT pCertContext,
    PCERT_ENHKEY_USAGE pUsage
    );

WINCRYPT32API
BOOL
WINAPI
CertAddEnhancedKeyUsageIdentifier(
    PCCERT_CONTEXT pCertContext,
    LPCSTR pszUsageIdentifier
    );

WINCRYPT32API
BOOL
WINAPI
CertRemoveEnhancedKeyUsageIdentifier(
    PCCERT_CONTEXT pCertContext,
    LPCSTR pszUsageIdentifier
    );

WINCRYPT32API
BOOL
WINAPI
CertGetValidUsages(
         DWORD           cCerts,
         PCCERT_CONTEXT  *rghCerts,
        int             *cNumOIDs,
        LPSTR           *rghOIDs,
     DWORD           *pcbOIDs);

WINCRYPT32API
BOOL
WINAPI
CryptMsgGetAndVerifySigner(
    HCRYPTMSG hCryptMsg,
    DWORD cSignerStore,
    OPTIONAL HCERTSTORE *rghSignerStore,
    DWORD dwFlags,
    OPTIONAL PCCERT_CONTEXT *ppSigner,
    OPTIONAL DWORD *pdwSignerIndex
    );

#define CMSG_TRUSTED_SIGNER_FLAG            0x1
#define CMSG_SIGNER_ONLY_FLAG               0x2
#define CMSG_USE_SIGNER_INDEX_FLAG          0x4
WINCRYPT32API
BOOL
WINAPI
CryptMsgSignCTL(
    DWORD dwMsgEncodingType,
    BYTE *pbCtlContent,
    DWORD cbCtlContent,
    PCMSG_SIGNED_ENCODE_INFO pSignInfo,
    DWORD dwFlags,
    BYTE *pbEncoded,
    DWORD *pcbEncoded
    );

#define CMSG_CMS_ENCAPSULATED_CTL_FLAG  0x00008000

WINCRYPT32API
BOOL
WINAPI
CryptMsgEncodeAndSignCTL(
    DWORD dwMsgEncodingType,
    PCTL_INFO pCtlInfo,
    PCMSG_SIGNED_ENCODE_INFO pSignInfo,
    DWORD dwFlags,
    BYTE *pbEncoded,
    DWORD *pcbEncoded
    );

#define CMSG_ENCODE_SORTED_CTL_FLAG                     0x1
#define CMSG_ENCODE_HASHED_SUBJECT_IDENTIFIER_FLAG      0x2

WINCRYPT32API
BOOL
WINAPI
CertFindSubjectInSortedCTL(
    PCRYPT_DATA_BLOB pSubjectIdentifier,
    PCCTL_CONTEXT pCtlContext,
    DWORD dwFlags,
    void *pvReserved,
    OPTIONAL PCRYPT_DER_BLOB pEncodedAttributes
    );

WINCRYPT32API
BOOL
WINAPI
CertEnumSubjectInSortedCTL(
    PCCTL_CONTEXT pCtlContext,
    void **ppvNextSubject,
    OPTIONAL PCRYPT_DER_BLOB pSubjectIdentifier,
    OPTIONAL PCRYPT_DER_BLOB pEncodedAttributes
    );

typedef struct _CTL_VERIFY_USAGE_PARA {
    DWORD                   cbSize;
    CRYPT_DATA_BLOB         ListIdentifier;
    DWORD                   cCtlStore;
    HCERTSTORE              *rghCtlStore;
    DWORD                   cSignerStore;
    HCERTSTORE              *rghSignerStore;
} CTL_VERIFY_USAGE_PARA, *PCTL_VERIFY_USAGE_PARA;

typedef struct _CTL_VERIFY_USAGE_STATUS {
    DWORD                   cbSize;
    DWORD                   dwError;
    DWORD                   dwFlags;
    PCCTL_CONTEXT           *ppCtl;
    DWORD                   dwCtlEntryIndex;
    PCCERT_CONTEXT          *ppSigner;
    DWORD                   dwSignerIndex;
} CTL_VERIFY_USAGE_STATUS, *PCTL_VERIFY_USAGE_STATUS;

#define CERT_VERIFY_INHIBIT_CTL_UPDATE_FLAG     0x1
#define CERT_VERIFY_TRUSTED_SIGNERS_FLAG        0x2
#define CERT_VERIFY_NO_TIME_CHECK_FLAG          0x4
#define CERT_VERIFY_ALLOW_MORE_USAGE_FLAG       0x8

#define CERT_VERIFY_UPDATED_CTL_FLAG            0x1

WINCRYPT32API
BOOL
WINAPI
CertVerifyCTLUsage(
    DWORD dwEncodingType,
    DWORD dwSubjectType,
    void *pvSubject,
    PCTL_USAGE pSubjectUsage,
    DWORD dwFlags,
    OPTIONAL PCTL_VERIFY_USAGE_PARA pVerifyUsagePara,
    PCTL_VERIFY_USAGE_STATUS pVerifyUsageStatus
    );

typedef struct _CERT_REVOCATION_PARA {
    DWORD                   cbSize;
    PCCERT_CONTEXT          pIssuerCert;
    DWORD                   cCertStore;
    HCERTSTORE              *rgCertStore;
    HCERTSTORE              hCrlStore;
    LPFILETIME              pftTimeToUse;
} CERT_REVOCATION_PARA, *PCERT_REVOCATION_PARA;

typedef struct _CERT_REVOCATION_STATUS {
    DWORD                   cbSize;
    DWORD                   dwIndex;
    DWORD                   dwError;
    DWORD                   dwReason;
} CERT_REVOCATION_STATUS, *PCERT_REVOCATION_STATUS;

WINCRYPT32API
BOOL
WINAPI
CertVerifyRevocation(
    DWORD dwEncodingType,
    DWORD dwRevType,
    DWORD cContext,
    PVOID rgpvContext[],
    DWORD dwFlags,
    OPTIONAL PCERT_REVOCATION_PARA pRevPara,
    PCERT_REVOCATION_STATUS pRevStatus
    );

#define CERT_CONTEXT_REVOCATION_TYPE        1
#define CERT_VERIFY_REV_CHAIN_FLAG              0x00000001
#define CERT_VERIFY_CACHE_ONLY_BASED_REVOCATION 0x00000002

BOOL
WINAPI
CertCompareIntegerBlob(
    PCRYPT_INTEGER_BLOB pInt1,
    PCRYPT_INTEGER_BLOB pInt2
    );

WINCRYPT32API
BOOL
WINAPI
CertCompareCertificate(
    DWORD dwCertEncodingType,
    PCERT_INFO pCertId1,
    PCERT_INFO pCertId2
    );

WINCRYPT32API
BOOL
WINAPI
CertCompareCertificateName(
    DWORD dwCertEncodingType,
    PCERT_NAME_BLOB pCertName1,
    PCERT_NAME_BLOB pCertName2
    );

WINCRYPT32API
BOOL
WINAPI
CertIsRDNAttrsInCertificateName(
    DWORD dwCertEncodingType,
    DWORD dwFlags,
    PCERT_NAME_BLOB pCertName,
    PCERT_RDN pRDN
    );

#define CERT_UNICODE_IS_RDN_ATTRS_FLAG              0x1
#define CERT_CASE_INSENSITIVE_IS_RDN_ATTRS_FLAG     0x2

WINCRYPT32API
BOOL
WINAPI
CertComparePublicKeyInfo(
    DWORD dwCertEncodingType,
    PCERT_PUBLIC_KEY_INFO pPublicKey1,
    PCERT_PUBLIC_KEY_INFO pPublicKey2
    );

WINCRYPT32API
DWORD
WINAPI
CertGetPublicKeyLength(
    DWORD dwCertEncodingType,
    PCERT_PUBLIC_KEY_INFO pPublicKey
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyCertificateSignature(
    HCRYPTPROV               hCryptProv,
    DWORD                    dwCertEncodingType,
    const BYTE *             pbEncoded,
    DWORD                    cbEncoded,
    PCERT_PUBLIC_KEY_INFO    pPublicKey
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyCertificateSignatureEx(
    OPTIONAL HCRYPTPROV hCryptProv,
    DWORD dwCertEncodingType,
    DWORD dwSubjectType,
    void *pvSubject,
    DWORD dwIssuerType,
    void *pvIssuer,
    DWORD dwFlags,
    OPTIONAL void *pvReserved
    );

#define CRYPT_VERIFY_CERT_SIGN_SUBJECT_BLOB         1
#define CRYPT_VERIFY_CERT_SIGN_SUBJECT_CERT         2
#define CRYPT_VERIFY_CERT_SIGN_SUBJECT_CRL          3
#define CRYPT_VERIFY_CERT_SIGN_ISSUER_PUBKEY        1
#define CRYPT_VERIFY_CERT_SIGN_ISSUER_CERT          2
#define CRYPT_VERIFY_CERT_SIGN_ISSUER_CHAIN         3

WINCRYPT32API
BOOL
WINAPI
CryptHashToBeSigned(
    HCRYPTPROV hCryptProv,
    DWORD dwCertEncodingType,
    const BYTE *pbEncoded,
    DWORD cbEncoded,
    BYTE *pbComputedHash,
    DWORD *pcbComputedHash
    );

WINCRYPT32API
BOOL
WINAPI
CryptHashCertificate(
    HCRYPTPROV hCryptProv,
    ALG_ID Algid,
    DWORD dwFlags,
    const BYTE *pbEncoded,
    DWORD cbEncoded,
    BYTE *pbComputedHash,
    DWORD *pcbComputedHash
    );

WINCRYPT32API
BOOL
WINAPI
CryptSignCertificate(
    HCRYPTPROV hCryptProv,
    DWORD dwKeySpec,
    DWORD dwCertEncodingType,
    const BYTE *pbEncodedToBeSigned,
    DWORD cbEncodedToBeSigned,
    PCRYPT_ALGORITHM_IDENTIFIER pSignatureAlgorithm,
    OPTIONAL const void *pvHashAuxInfo,
    BYTE *pbSignature,
    DWORD *pcbSignature
    );

WINCRYPT32API
BOOL
WINAPI
CryptSignAndEncodeCertificate(
    HCRYPTPROV hCryptProv,
    DWORD dwKeySpec,
    DWORD dwCertEncodingType,
    LPCSTR lpszStructType,       // "to be signed"
    const void *pvStructInfo,
    PCRYPT_ALGORITHM_IDENTIFIER pSignatureAlgorithm,
    OPTIONAL const void *pvHashAuxInfo,
    PBYTE pbEncoded,
    DWORD *pcbEncoded
    );

WINCRYPT32API
LONG
WINAPI
CertVerifyTimeValidity(
    LPFILETIME pTimeToVerify,
    PCERT_INFO pCertInfo
    );

WINCRYPT32API
LONG
WINAPI
CertVerifyCRLTimeValidity(
    LPFILETIME pTimeToVerify,
    PCRL_INFO pCrlInfo
    );

WINCRYPT32API
BOOL
WINAPI
CertVerifyValidityNesting(
    PCERT_INFO pSubjectInfo,
    PCERT_INFO pIssuerInfo
    );

WINCRYPT32API
BOOL
WINAPI
CertVerifyCRLRevocation(
    DWORD dwCertEncodingType,
    PCERT_INFO pCertId,          // Only the Issuer and SerialNumber
    // fields are used
    DWORD cCrlInfo,
    PCRL_INFO rgpCrlInfo[]
    );

WINCRYPT32API
LPCSTR
WINAPI
CertAlgIdToOID(
    DWORD dwAlgId
    );

WINCRYPT32API
DWORD
WINAPI
CertOIDToAlgId(
    LPCSTR pszObjId
    );

WINCRYPT32API
PCERT_EXTENSION
WINAPI
CertFindExtension(
    LPCSTR pszObjId,
    DWORD cExtensions,
    CERT_EXTENSION rgExtensions[]
    );

WINCRYPT32API
PCRYPT_ATTRIBUTE
WINAPI
CertFindAttribute(
    LPCSTR pszObjId,
    DWORD cAttr,
    CRYPT_ATTRIBUTE rgAttr[]
    );

WINCRYPT32API
PCERT_RDN_ATTR
WINAPI
CertFindRDNAttr(
    LPCSTR pszObjId,
    PCERT_NAME_INFO pName
    );

WINCRYPT32API
BOOL
WINAPI
CertGetIntendedKeyUsage(
    DWORD dwCertEncodingType,
    PCERT_INFO pCertInfo,
    BYTE *pbKeyUsage,
    DWORD cbKeyUsage
    );

typedef void *HCRYPTDEFAULTCONTEXT;

WINCRYPT32API
BOOL
WINAPI
CryptInstallDefaultContext(
    HCRYPTPROV hCryptProv,
    DWORD dwDefaultType,
    const void *pvDefaultPara,
    DWORD dwFlags,
    void *pvReserved,
    HCRYPTDEFAULTCONTEXT *phDefaultContext
    );

#define CRYPT_DEFAULT_CONTEXT_AUTO_RELEASE_FLAG             0x00000001
#define CRYPT_DEFAULT_CONTEXT_PROCESS_FLAG                  0x00000002
#define CRYPT_DEFAULT_CONTEXT_CERT_SIGN_OID         1
#define CRYPT_DEFAULT_CONTEXT_MULTI_CERT_SIGN_OID   2

typedef struct _CRYPT_DEFAULT_CONTEXT_MULTI_OID_PARA {
    DWORD               cOID;
    LPSTR               *rgpszOID;
} CRYPT_DEFAULT_CONTEXT_MULTI_OID_PARA, *PCRYPT_DEFAULT_CONTEXT_MULTI_OID_PARA;

WINCRYPT32API
BOOL
WINAPI
CryptUninstallDefaultContext(
    HCRYPTDEFAULTCONTEXT hDefaultContext,
    DWORD dwFlags,
    void *pvReserved
    );

WINCRYPT32API
BOOL
WINAPI
CryptExportPublicKeyInfo(
    HCRYPTPROV hCryptProv,
    DWORD dwKeySpec,
    DWORD dwCertEncodingType,
    PCERT_PUBLIC_KEY_INFO pInfo,
    DWORD *pcbInfo
    );

#define CRYPT_OID_EXPORT_PUBLIC_KEY_INFO_FUNC   "CryptDllExportPublicKeyInfoEx"

WINCRYPT32API
BOOL
WINAPI
CryptExportPublicKeyInfoEx(
    HCRYPTPROV hCryptProv,
    DWORD dwKeySpec,
    DWORD dwCertEncodingType,
    LPSTR pszPublicKeyObjId,
    DWORD dwFlags,
    OPTIONAL void *pvAuxInfo,
    PCERT_PUBLIC_KEY_INFO pInfo,
    DWORD *pcbInfo
    );

WINCRYPT32API
BOOL
WINAPI
CryptImportPublicKeyInfo(
    HCRYPTPROV hCryptProv,
    DWORD dwCertEncodingType,
    PCERT_PUBLIC_KEY_INFO pInfo,
    HCRYPTKEY *phKey
    );

#define CRYPT_OID_IMPORT_PUBLIC_KEY_INFO_FUNC   "CryptDllImportPublicKeyInfoEx"

WINCRYPT32API
BOOL
WINAPI
CryptImportPublicKeyInfoEx(
    HCRYPTPROV hCryptProv,
    DWORD dwCertEncodingType,
    PCERT_PUBLIC_KEY_INFO pInfo,
    ALG_ID aiKeyAlg,
    DWORD dwFlags,
    OPTIONAL void *pvAuxInfo,
    HCRYPTKEY *phKey
    );

WINCRYPT32API
BOOL
WINAPI
CryptAcquireCertificatePrivateKey(
    PCCERT_CONTEXT pCert,
    DWORD dwFlags,
    void *pvReserved,
    HCRYPTPROV *phCryptProv,
    OPTIONAL DWORD *pdwKeySpec,
    OPTIONAL BOOL *pfCallerFreeProv
    );

#define CRYPT_ACQUIRE_CACHE_FLAG                0x1
#define CRYPT_ACQUIRE_USE_PROV_INFO_FLAG        0x2
#define CRYPT_ACQUIRE_COMPARE_KEY_FLAG          0x4

WINCRYPT32API
BOOL
WINAPI
CryptFindCertificateKeyProvInfo(
    PCCERT_CONTEXT pCert,
    DWORD dwFlags,
    void *pvReserved
    );

#define CRYPT_FIND_USER_KEYSET_FLAG        0x1
#define CRYPT_FIND_MACHINE_KEYSET_FLAG     0x2

typedef BOOL (WINAPI *PFN_IMPORT_PRIV_KEY_FUNC) (
    HCRYPTPROV              hCryptProv,         // in
    CRYPT_PRIVATE_KEY_INFO  *pPrivateKeyInfo,   // in
    DWORD                   dwFlags,            // in, optional
    void                    *pvAuxInfo          // in, optional
    );

#define CRYPT_OID_IMPORT_PRIVATE_KEY_INFO_FUNC   "CryptDllImportPrivateKeyInfoEx"

WINCRYPT32API
BOOL
WINAPI
CryptImportPKCS8(
    CRYPT_PKCS8_IMPORT_PARAMS           sImportParams,          // in
    DWORD                               dwFlags,                // in, optional
    HCRYPTPROV                          *phCryptProv,           // out, optional
    void                                *pvAuxInfo              // in, optional
    );

typedef BOOL (WINAPI *PFN_EXPORT_PRIV_KEY_FUNC) (
    HCRYPTPROV              hCryptProv,         // in
    DWORD                   dwKeySpec,          // in
    LPSTR                   pszPrivateKeyObjId, // in
    DWORD                   dwFlags,            // in
    void                    *pvAuxInfo,         // in
    CRYPT_PRIVATE_KEY_INFO  *pPrivateKeyInfo,   // out
    DWORD                   *pcbPrivateKeyBlob  // in, out
    );

#define CRYPT_OID_EXPORT_PRIVATE_KEY_INFO_FUNC   "CryptDllExportPrivateKeyInfoEx"
#define CRYPT_DELETE_KEYSET 0x0001

WINCRYPT32API
BOOL
WINAPI
CryptExportPKCS8(
    HCRYPTPROV  hCryptProv,         // in
    DWORD       dwKeySpec,          // in
    LPSTR       pszPrivateKeyObjId, // in
    DWORD       dwFlags,            // in
    void        *pvAuxInfo,         // in
    BYTE        *pbPrivateKeyBlob,  // out
    DWORD       *pcbPrivateKeyBlob  // in, out
    );

WINCRYPT32API
BOOL
WINAPI
CryptExportPKCS8Ex(
    CRYPT_PKCS8_EXPORT_PARAMS* psExportParams, // in
    DWORD       dwFlags,            // in
    void        *pvAuxInfo,         // in
    BYTE        *pbPrivateKeyBlob,  // out
    DWORD       *pcbPrivateKeyBlob  // in, out
    );

WINCRYPT32API
BOOL
WINAPI
CryptHashPublicKeyInfo(
    HCRYPTPROV hCryptProv,
    ALG_ID Algid,
    DWORD dwFlags,
    DWORD dwCertEncodingType,
    PCERT_PUBLIC_KEY_INFO pInfo,
    BYTE *pbComputedHash,
    DWORD *pcbComputedHash
    );

WINCRYPT32API
DWORD
WINAPI
CertRDNValueToStrA(
    DWORD dwValueType,
    PCERT_RDN_VALUE_BLOB pValue,
    OPTIONAL LPSTR psz,
    DWORD csz
    );

WINCRYPT32API
DWORD
WINAPI
CertRDNValueToStrW(
    DWORD dwValueType,
    PCERT_RDN_VALUE_BLOB pValue,
    OPTIONAL LPWSTR psz,
    DWORD csz
    );
#ifdef UNICODE
#define CertRDNValueToStr  CertRDNValueToStrW
#else
#define CertRDNValueToStr  CertRDNValueToStrA
#endif // !UNICODE

WINCRYPT32API
DWORD
WINAPI
CertNameToStrA(
    DWORD dwCertEncodingType,
    PCERT_NAME_BLOB pName,
    DWORD dwStrType,
    OPTIONAL LPSTR psz,
    DWORD csz
    );

WINCRYPT32API
DWORD
WINAPI
CertNameToStrW(
    DWORD dwCertEncodingType,
    PCERT_NAME_BLOB pName,
    DWORD dwStrType,
    OPTIONAL LPWSTR psz,
    DWORD csz
    );
#ifdef UNICODE
#define CertNameToStr  CertNameToStrW
#else
#define CertNameToStr  CertNameToStrA
#endif // !UNICODE

#define CERT_SIMPLE_NAME_STR        1
#define CERT_OID_NAME_STR           2
#define CERT_X500_NAME_STR          3

#define CERT_NAME_STR_SEMICOLON_FLAG    0x40000000
#define CERT_NAME_STR_NO_PLUS_FLAG      0x20000000
#define CERT_NAME_STR_NO_QUOTING_FLAG   0x10000000
#define CERT_NAME_STR_CRLF_FLAG         0x08000000
#define CERT_NAME_STR_COMMA_FLAG        0x04000000
#define CERT_NAME_STR_REVERSE_FLAG      0x02000000

#define CERT_NAME_STR_DISABLE_IE4_UTF8_FLAG     0x00010000
#define CERT_NAME_STR_ENABLE_T61_UNICODE_FLAG   0x00020000
#define CERT_NAME_STR_ENABLE_UTF8_UNICODE_FLAG  0x00040000

WINCRYPT32API
BOOL
WINAPI
CertStrToNameA(
    DWORD dwCertEncodingType,
    LPCSTR pszX500,
    DWORD dwStrType,
    OPTIONAL void *pvReserved,
    BYTE *pbEncoded,
    DWORD *pcbEncoded,
    OPTIONAL LPCSTR *ppszError
    );

WINCRYPT32API
BOOL
WINAPI
CertStrToNameW(
    DWORD dwCertEncodingType,
    LPCWSTR pszX500,
    DWORD dwStrType,
    OPTIONAL void *pvReserved,
    BYTE *pbEncoded,
    DWORD *pcbEncoded,
    OPTIONAL LPCWSTR *ppszError
    );
#ifdef UNICODE
#define CertStrToName  CertStrToNameW
#else
#define CertStrToName  CertStrToNameA
#endif // !UNICODE

WINCRYPT32API
DWORD
WINAPI
CertGetNameStringA(
    PCCERT_CONTEXT pCertContext,
    DWORD dwType,
    DWORD dwFlags,
    void *pvTypePara,
    OPTIONAL LPSTR pszNameString,
    DWORD cchNameString
    );

WINCRYPT32API
DWORD
WINAPI
CertGetNameStringW(
    PCCERT_CONTEXT pCertContext,
    DWORD dwType,
    DWORD dwFlags,
    void *pvTypePara,
    OPTIONAL LPWSTR pszNameString,
    DWORD cchNameString
    );
#ifdef UNICODE
#define CertGetNameString  CertGetNameStringW
#else
#define CertGetNameString  CertGetNameStringA
#endif // !UNICODE

#define CERT_NAME_EMAIL_TYPE            1
#define CERT_NAME_RDN_TYPE              2
#define CERT_NAME_ATTR_TYPE             3
#define CERT_NAME_SIMPLE_DISPLAY_TYPE   4
#define CERT_NAME_FRIENDLY_DISPLAY_TYPE 5

#define CERT_NAME_ISSUER_FLAG           0x1
#define CERT_NAME_DISABLE_IE4_UTF8_FLAG 0x00010000

typedef PCCERT_CONTEXT (WINAPI *PFN_CRYPT_GET_SIGNER_CERTIFICATE)(
    void *pvGetArg,
    DWORD dwCertEncodingType,
    PCERT_INFO pSignerId,    // Only the Issuer and SerialNumber
                                // fields have been updated
    HCERTSTORE hMsgCertStore
    );

typedef struct _CRYPT_SIGN_MESSAGE_PARA {
    DWORD                       cbSize;
    DWORD                       dwMsgEncodingType;
    PCCERT_CONTEXT              pSigningCert;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    void                        *pvHashAuxInfo;
    DWORD                       cMsgCert;
    PCCERT_CONTEXT              *rgpMsgCert;
    DWORD                       cMsgCrl;
    PCCRL_CONTEXT               *rgpMsgCrl;
    DWORD                       cAuthAttr;
    PCRYPT_ATTRIBUTE            rgAuthAttr;
    DWORD                       cUnauthAttr;
    PCRYPT_ATTRIBUTE            rgUnauthAttr;
    DWORD                       dwFlags;
    DWORD                       dwInnerContentType;

#ifdef CRYPT_SIGN_MESSAGE_PARA_HAS_CMS_FIELDS
    CRYPT_ALGORITHM_IDENTIFIER  HashEncryptionAlgorithm;
    void                        *pvHashEncryptionAuxInfo;
#endif
} CRYPT_SIGN_MESSAGE_PARA, *PCRYPT_SIGN_MESSAGE_PARA;

#define CRYPT_MESSAGE_BARE_CONTENT_OUT_FLAG     0x1
#define CRYPT_MESSAGE_ENCAPSULATED_CONTENT_OUT_FLAG 0x2
#define CRYPT_MESSAGE_KEYID_SIGNER_FLAG         0x4

typedef struct _CRYPT_VERIFY_MESSAGE_PARA {
    DWORD                               cbSize;
    DWORD                               dwMsgAndCertEncodingType;
    HCRYPTPROV                          hCryptProv;
    PFN_CRYPT_GET_SIGNER_CERTIFICATE    pfnGetSignerCertificate;
    void                                *pvGetArg;
} CRYPT_VERIFY_MESSAGE_PARA, *PCRYPT_VERIFY_MESSAGE_PARA;

typedef struct _CRYPT_ENCRYPT_MESSAGE_PARA {
    DWORD                       cbSize;
    DWORD                       dwMsgEncodingType;
    HCRYPTPROV                  hCryptProv;
    CRYPT_ALGORITHM_IDENTIFIER  ContentEncryptionAlgorithm;
    void                        *pvEncryptionAuxInfo;
    DWORD                       dwFlags;
    DWORD                       dwInnerContentType;
} CRYPT_ENCRYPT_MESSAGE_PARA, *PCRYPT_ENCRYPT_MESSAGE_PARA;

#define CRYPT_MESSAGE_KEYID_RECIPIENT_FLAG          0x4

typedef struct _CRYPT_DECRYPT_MESSAGE_PARA {
    DWORD                   cbSize;
    DWORD                   dwMsgAndCertEncodingType;
    DWORD                   cCertStore;
    HCERTSTORE              *rghCertStore;
} CRYPT_DECRYPT_MESSAGE_PARA, *PCRYPT_DECRYPT_MESSAGE_PARA;

typedef struct _CRYPT_HASH_MESSAGE_PARA {
    DWORD                       cbSize;
    DWORD                       dwMsgEncodingType;
    HCRYPTPROV                  hCryptProv;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    void                        *pvHashAuxInfo;
} CRYPT_HASH_MESSAGE_PARA, *PCRYPT_HASH_MESSAGE_PARA;

typedef struct _CRYPT_KEY_SIGN_MESSAGE_PARA {
    DWORD                       cbSize;
    DWORD                       dwMsgAndCertEncodingType;
    HCRYPTPROV                  hCryptProv;
    DWORD                       dwKeySpec;
    CRYPT_ALGORITHM_IDENTIFIER  HashAlgorithm;
    void                        *pvHashAuxInfo;
    CRYPT_ALGORITHM_IDENTIFIER  PubKeyAlgorithm;
} CRYPT_KEY_SIGN_MESSAGE_PARA, *PCRYPT_KEY_SIGN_MESSAGE_PARA;

typedef struct _CRYPT_KEY_VERIFY_MESSAGE_PARA {
    DWORD                   cbSize;
    DWORD                   dwMsgEncodingType;
    HCRYPTPROV              hCryptProv;
} CRYPT_KEY_VERIFY_MESSAGE_PARA, *PCRYPT_KEY_VERIFY_MESSAGE_PARA;

WINCRYPT32API
BOOL
WINAPI
CryptSignMessage(
    PCRYPT_SIGN_MESSAGE_PARA pSignPara,
    BOOL fDetachedSignature,
    DWORD cToBeSigned,
    const BYTE *rgpbToBeSigned[],
    DWORD rgcbToBeSigned[],
    BYTE *pbSignedBlob,
    DWORD *pcbSignedBlob
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyMessageSignature(
    PCRYPT_VERIFY_MESSAGE_PARA pVerifyPara,
    DWORD dwSignerIndex,
    const BYTE *pbSignedBlob,
    DWORD cbSignedBlob,
    BYTE OPTIONAL *pbDecoded,
    OPTIONAL DWORD *pcbDecoded,
    OPTIONAL PCCERT_CONTEXT *ppSignerCert
    );

WINCRYPT32API
LONG
WINAPI
CryptGetMessageSignerCount(
    DWORD dwMsgEncodingType,
    const BYTE *pbSignedBlob,
    DWORD cbSignedBlob
    );

WINCRYPT32API
HCERTSTORE
WINAPI
CryptGetMessageCertificates(
    DWORD dwMsgAndCertEncodingType,
    HCRYPTPROV hCryptProv,           // passed to CertOpenStore
    DWORD dwFlags,                   // passed to CertOpenStore
    const BYTE *pbSignedBlob,
    DWORD cbSignedBlob
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyDetachedMessageSignature(
    PCRYPT_VERIFY_MESSAGE_PARA pVerifyPara,
    DWORD dwSignerIndex,
    const BYTE *pbDetachedSignBlob,
    DWORD cbDetachedSignBlob,
    DWORD cToBeSigned,
    const BYTE *rgpbToBeSigned[],
    DWORD rgcbToBeSigned[],
    OPTIONAL PCCERT_CONTEXT *ppSignerCert
    );

WINCRYPT32API
BOOL
WINAPI
CryptEncryptMessage(
    PCRYPT_ENCRYPT_MESSAGE_PARA pEncryptPara,
    DWORD cRecipientCert,
    PCCERT_CONTEXT rgpRecipientCert[],
    const BYTE *pbToBeEncrypted,
    DWORD cbToBeEncrypted,
    BYTE *pbEncryptedBlob,
    DWORD *pcbEncryptedBlob
    );

WINCRYPT32API
BOOL
WINAPI
CryptDecryptMessage(
    PCRYPT_DECRYPT_MESSAGE_PARA pDecryptPara,
    const BYTE *pbEncryptedBlob,
    DWORD cbEncryptedBlob,
    OPTIONAL BYTE *pbDecrypted,
    OPTIONAL DWORD *pcbDecrypted,
    OPTIONAL PCCERT_CONTEXT *ppXchgCert
    );

WINCRYPT32API
BOOL
WINAPI
CryptSignAndEncryptMessage(
    PCRYPT_SIGN_MESSAGE_PARA pSignPara,
    PCRYPT_ENCRYPT_MESSAGE_PARA pEncryptPara,
    DWORD cRecipientCert,
    PCCERT_CONTEXT rgpRecipientCert[],
    const BYTE *pbToBeSignedAndEncrypted,
    DWORD cbToBeSignedAndEncrypted,
    BYTE *pbSignedAndEncryptedBlob,
    DWORD *pcbSignedAndEncryptedBlob
    );

WINCRYPT32API
BOOL
WINAPI
CryptDecryptAndVerifyMessageSignature(
    PCRYPT_DECRYPT_MESSAGE_PARA pDecryptPara,
    PCRYPT_VERIFY_MESSAGE_PARA pVerifyPara,
    DWORD dwSignerIndex,
    const BYTE *pbEncryptedBlob,
    DWORD cbEncryptedBlob,
    OPTIONAL BYTE *pbDecrypted,
    OPTIONAL DWORD *pcbDecrypted,
    OPTIONAL PCCERT_CONTEXT *ppXchgCert,
    OPTIONAL PCCERT_CONTEXT *ppSignerCert
    );

WINCRYPT32API
BOOL
WINAPI
CryptDecodeMessage(
    DWORD dwMsgTypeFlags,
    PCRYPT_DECRYPT_MESSAGE_PARA pDecryptPara,
    PCRYPT_VERIFY_MESSAGE_PARA pVerifyPara,
    DWORD dwSignerIndex,
    const BYTE *pbEncodedBlob,
    DWORD cbEncodedBlob,
    DWORD dwPrevInnerContentType,
    OPTIONAL DWORD *pdwMsgType,
    OPTIONAL DWORD *pdwInnerContentType,
    OPTIONAL BYTE *pbDecoded,
    OPTIONAL DWORD *pcbDecoded,
    OPTIONAL PCCERT_CONTEXT *ppXchgCert,
    OPTIONAL PCCERT_CONTEXT *ppSignerCert
    );

WINCRYPT32API
BOOL
WINAPI
CryptHashMessage(
    PCRYPT_HASH_MESSAGE_PARA pHashPara,
    BOOL fDetachedHash,
    DWORD cToBeHashed,
    const BYTE *rgpbToBeHashed[],
    DWORD rgcbToBeHashed[],
    OPTIONAL BYTE *pbHashedBlob,
    OPTIONAL DWORD *pcbHashedBlob,
    OPTIONAL BYTE *pbComputedHash,
    OPTIONAL DWORD *pcbComputedHash
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyMessageHash(
    PCRYPT_HASH_MESSAGE_PARA pHashPara,
    BYTE *pbHashedBlob,
    DWORD cbHashedBlob,
    OPTIONAL BYTE *pbToBeHashed,
    OPTIONAL DWORD *pcbToBeHashed,
    OPTIONAL BYTE *pbComputedHash,
    OPTIONAL DWORD *pcbComputedHash
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyDetachedMessageHash(
    PCRYPT_HASH_MESSAGE_PARA pHashPara,
    BYTE *pbDetachedHashBlob,
    DWORD cbDetachedHashBlob,
    DWORD cToBeHashed,
    const BYTE *rgpbToBeHashed[],
    DWORD rgcbToBeHashed[],
    OPTIONAL BYTE *pbComputedHash,
    OPTIONAL DWORD *pcbComputedHash
    );
WINCRYPT32API
BOOL
WINAPI
CryptSignMessageWithKey(
    PCRYPT_KEY_SIGN_MESSAGE_PARA pSignPara,
    const BYTE *pbToBeSigned,
    DWORD cbToBeSigned,
    BYTE *pbSignedBlob,
    DWORD *pcbSignedBlob
    );

WINCRYPT32API
BOOL
WINAPI
CryptVerifyMessageSignatureWithKey(
    PCRYPT_KEY_VERIFY_MESSAGE_PARA pVerifyPara,
    OPTIONAL PCERT_PUBLIC_KEY_INFO pPublicKeyInfo,
    const BYTE *pbSignedBlob,
    DWORD cbSignedBlob,
    OPTIONAL BYTE *pbDecoded,
    OPTIONAL DWORD *pcbDecoded
    );

WINCRYPT32API
HCERTSTORE
WINAPI
CertOpenSystemStoreA(
    HCRYPTPROV      hProv,
    LPCSTR            szSubsystemProtocol
    );
WINCRYPT32API
HCERTSTORE
WINAPI
CertOpenSystemStoreW(
    HCRYPTPROV      hProv,
    LPCWSTR            szSubsystemProtocol
    );
#ifdef UNICODE
#define CertOpenSystemStore  CertOpenSystemStoreW
#else
#define CertOpenSystemStore  CertOpenSystemStoreA
#endif // !UNICODE

WINCRYPT32API
BOOL
WINAPI
CertAddEncodedCertificateToSystemStoreA(
    LPCSTR            szCertStoreName,
    const BYTE *    pbCertEncoded,
    DWORD           cbCertEncoded
    );
WINCRYPT32API
BOOL
WINAPI
CertAddEncodedCertificateToSystemStoreW(
    LPCWSTR            szCertStoreName,
    const BYTE *    pbCertEncoded,
    DWORD           cbCertEncoded
    );

#ifdef UNICODE
#define CertAddEncodedCertificateToSystemStore  CertAddEncodedCertificateToSystemStoreW
#else
#define CertAddEncodedCertificateToSystemStore  CertAddEncodedCertificateToSystemStoreA
#endif // !UNICODE

typedef struct _CERT_CHAIN {
    DWORD                   cCerts;
    PCERT_BLOB              certs;
    CRYPT_KEY_PROV_INFO     keyLocatorInfo;
} CERT_CHAIN, *PCERT_CHAIN;

HRESULT
WINAPI
FindCertsByIssuer(
    PCERT_CHAIN pCertChains,
    DWORD *pcbCertChains,
    DWORD *pcCertChains,
    BYTE* pbEncodedIssuerName,
    DWORD cbEncodedIssuerName,
    LPCWSTR pwszPurpose,
    DWORD dwKeySpec
    );

WINCRYPT32API
BOOL
WINAPI
CryptQueryObject(
    DWORD            dwObjectType,
    const void       *pvObject,
    DWORD            dwExpectedContentTypeFlags,
    DWORD            dwExpectedFormatTypeFlags,
    DWORD            dwFlags,
    DWORD            *pdwMsgAndCertEncodingType,
    DWORD            *pdwContentType,
    DWORD            *pdwFormatType,
    HCERTSTORE       *phCertStore,
    HCRYPTMSG        *phMsg,
    const void       **ppvContext
    );

#define     CERT_QUERY_OBJECT_FILE         0x00000001
#define     CERT_QUERY_OBJECT_BLOB         0x00000002
#define     CERT_QUERY_CONTENT_CERT                 1
#define     CERT_QUERY_CONTENT_CTL                  2
#define     CERT_QUERY_CONTENT_CRL                  3
#define     CERT_QUERY_CONTENT_SERIALIZED_STORE     4
#define     CERT_QUERY_CONTENT_SERIALIZED_CERT      5
#define     CERT_QUERY_CONTENT_SERIALIZED_CTL       6
#define     CERT_QUERY_CONTENT_SERIALIZED_CRL       7
#define     CERT_QUERY_CONTENT_PKCS7_SIGNED         8
#define     CERT_QUERY_CONTENT_PKCS7_UNSIGNED       9
#define     CERT_QUERY_CONTENT_PKCS7_SIGNED_EMBED   10
#define     CERT_QUERY_CONTENT_PKCS10               11
#define     CERT_QUERY_CONTENT_PFX					12

#define     CERT_QUERY_CONTENT_FLAG_CERT   \
                ( 1 << CERT_QUERY_CONTENT_CERT)

#define     CERT_QUERY_CONTENT_FLAG_CTL   \
                ( 1 << CERT_QUERY_CONTENT_CTL)

#define     CERT_QUERY_CONTENT_FLAG_CRL   \
                ( 1 << CERT_QUERY_CONTENT_CRL)

#define     CERT_QUERY_CONTENT_FLAG_SERIALIZED_STORE   \
                ( 1 << CERT_QUERY_CONTENT_SERIALIZED_STORE)

#define     CERT_QUERY_CONTENT_FLAG_SERIALIZED_CERT   \
                ( 1 << CERT_QUERY_CONTENT_SERIALIZED_CERT)

#define     CERT_QUERY_CONTENT_FLAG_SERIALIZED_CTL   \
                ( 1 << CERT_QUERY_CONTENT_SERIALIZED_CTL)

#define     CERT_QUERY_CONTENT_FLAG_SERIALIZED_CRL   \
                ( 1 << CERT_QUERY_CONTENT_SERIALIZED_CRL)

#define     CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED   \
                ( 1 << CERT_QUERY_CONTENT_PKCS7_SIGNED)

#define     CERT_QUERY_CONTENT_FLAG_PKCS7_UNSIGNED   \
                ( 1 << CERT_QUERY_CONTENT_PKCS7_UNSIGNED)

#define     CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED  \
                ( 1 << CERT_QUERY_CONTENT_PKCS7_SIGNED_EMBED)

#define     CERT_QUERY_CONTENT_FLAG_PKCS10   \
                ( 1 << CERT_QUERY_CONTENT_PKCS10)

#define     CERT_QUERY_CONTENT_FLAG_PFX      \
                ( 1 << CERT_QUERY_CONTENT_PFX)

#define     CERT_QUERY_CONTENT_FLAG_ALL                         \
                CERT_QUERY_CONTENT_FLAG_CERT |                  \
                CERT_QUERY_CONTENT_FLAG_CTL  |                  \
                CERT_QUERY_CONTENT_FLAG_CRL  |                  \
                CERT_QUERY_CONTENT_FLAG_SERIALIZED_STORE |      \
                CERT_QUERY_CONTENT_FLAG_SERIALIZED_CERT  |      \
                CERT_QUERY_CONTENT_FLAG_SERIALIZED_CTL   |      \
                CERT_QUERY_CONTENT_FLAG_SERIALIZED_CRL   |      \
                CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED     |      \
                CERT_QUERY_CONTENT_FLAG_PKCS7_UNSIGNED   |      \
                CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED_EMBED |    \
                CERT_QUERY_CONTENT_FLAG_PKCS10			   |    \
                CERT_QUERY_CONTENT_FLAG_PFX

#define     CERT_QUERY_FORMAT_BINARY                1
#define     CERT_QUERY_FORMAT_BASE64_ENCODED        2
#define     CERT_QUERY_FORMAT_FLAG_BINARY         \
                ( 1 << CERT_QUERY_FORMAT_BINARY)

#define     CERT_QUERY_FORMAT_FLAG_BASE64_ENCODED \
                ( 1 << CERT_QUERY_FORMAT_BASE64_ENCODED)

#define     CERT_QUERY_FORMAT_FLAG_ALL              \
            CERT_QUERY_FORMAT_FLAG_BINARY   |       \
            CERT_QUERY_FORMAT_FLAG_BASE64_ENCODED

WINCRYPT32API
LPVOID
WINAPI
CryptMemAlloc (
    ULONG cbSize
    );

WINCRYPT32API
LPVOID
WINAPI
CryptMemRealloc (
    LPVOID pv,
    ULONG cbSize
    );

WINCRYPT32API
VOID
WINAPI
CryptMemFree (
    LPVOID pv
    );

typedef HANDLE HCRYPTASYNC, *PHCRYPTASYNC;

typedef VOID (WINAPI *PFN_CRYPT_ASYNC_PARAM_FREE_FUNC) (
    LPSTR pszParamOid,
    LPVOID pvParam
    );

WINCRYPT32API
BOOL
WINAPI
CryptCreateAsyncHandle (
    DWORD dwFlags,
    PHCRYPTASYNC phAsync
    );

WINCRYPT32API
BOOL
WINAPI
CryptSetAsyncParam (
    HCRYPTASYNC hAsync,
    LPSTR pszParamOid,
    LPVOID pvParam,
    OPTIONAL PFN_CRYPT_ASYNC_PARAM_FREE_FUNC pfnFree
    );

WINCRYPT32API
BOOL
WINAPI
CryptGetAsyncParam (
    HCRYPTASYNC hAsync,
    LPSTR pszParamOid,
    LPVOID* ppvParam,
    OPTIONAL PFN_CRYPT_ASYNC_PARAM_FREE_FUNC* ppfnFree
    );

WINCRYPT32API
BOOL
WINAPI
CryptCloseAsyncHandle (
    HCRYPTASYNC hAsync
    );

typedef struct _CRYPT_BLOB_ARRAY {
    DWORD            cBlob;
    PCRYPT_DATA_BLOB rgBlob;
} CRYPT_BLOB_ARRAY, *PCRYPT_BLOB_ARRAY;

typedef struct _CRYPT_CREDENTIALS {
    DWORD  cbSize;
    LPCSTR pszCredentialsOid;
    LPVOID pvCredentials;
} CRYPT_CREDENTIALS, *PCRYPT_CREDENTIALS;

#define CREDENTIAL_OID_PASSWORD_CREDENTIALS_A ((LPCSTR)1)
#define CREDENTIAL_OID_PASSWORD_CREDENTIALS_W ((LPCSTR)2)

#ifdef UNICODE
#define CREDENTIAL_OID_PASSWORD_CREDENTIALS CREDENTIAL_OID_PASSWORD_CREDENTIALS_W
#else
#define CREDENTIAL_OID_PASSWORD_CREDENTIALS CREDENTIAL_OID_PASSWORD_CREDENTIALS_A
#endif //UNICODE

typedef struct _CRYPT_PASSWORD_CREDENTIALSA {
    DWORD   cbSize;
    LPSTR   pszUsername;
    LPSTR   pszPassword;
} CRYPT_PASSWORD_CREDENTIALSA, *PCRYPT_PASSWORD_CREDENTIALSA;
typedef struct _CRYPT_PASSWORD_CREDENTIALSW {
    DWORD   cbSize;
    LPWSTR  pszUsername;
    LPWSTR  pszPassword;
} CRYPT_PASSWORD_CREDENTIALSW, *PCRYPT_PASSWORD_CREDENTIALSW;
#ifdef UNICODE
typedef CRYPT_PASSWORD_CREDENTIALSW CRYPT_PASSWORD_CREDENTIALS;
typedef PCRYPT_PASSWORD_CREDENTIALSW PCRYPT_PASSWORD_CREDENTIALS;
#else
typedef CRYPT_PASSWORD_CREDENTIALSA CRYPT_PASSWORD_CREDENTIALS;
typedef PCRYPT_PASSWORD_CREDENTIALSA PCRYPT_PASSWORD_CREDENTIALS;
#endif // UNICODE

#define SCHEME_OID_RETRIEVE_ENCODED_OBJECT_FUNC "SchemeDllRetrieveEncodedObject"

typedef VOID (WINAPI *PFN_FREE_ENCODED_OBJECT_FUNC) (
    LPCSTR pszObjectOid,
    PCRYPT_BLOB_ARRAY pObject,
    LPVOID pvFreeContext
    );

#define CONTEXT_OID_CREATE_OBJECT_CONTEXT_FUNC "ContextDllCreateObjectContext"
#define CONTEXT_OID_CERTIFICATE ((LPCSTR)1)
#define CONTEXT_OID_CRL         ((LPCSTR)2)
#define CONTEXT_OID_CTL         ((LPCSTR)3)
#define CONTEXT_OID_PKCS7       ((LPCSTR)4)
#define CONTEXT_OID_CAPI2_ANY   ((LPCSTR)5)

#define CRYPT_RETRIEVE_MULTIPLE_OBJECTS 0x00000001
#define CRYPT_CACHE_ONLY_RETRIEVAL      0x00000002
#define CRYPT_WIRE_ONLY_RETRIEVAL       0x00000004
#define CRYPT_DONT_CACHE_RESULT         0x00000008
#define CRYPT_ASYNC_RETRIEVAL           0x00000010
#define CRYPT_VERIFY_CONTEXT_SIGNATURE  0x00000020
#define CRYPT_VERIFY_DATA_HASH          0x00000040
#define CRYPT_KEEP_TIME_VALID           0x00000080
#define CRYPT_DONT_VERIFY_SIGNATURE     0x00000100
#define CRYPT_DONT_CHECK_TIME_VALIDITY  0x00000200

WINCRYPT32API
BOOL
WINAPI
CryptRetrieveObjectByUrlA (
    LPCSTR pszUrl,
    LPCSTR pszObjectOid,
    DWORD dwRetrievalFlags,
    DWORD dwTimeout,
    LPVOID* ppvObject,
    HCRYPTASYNC hAsyncRetrieve,
    OPTIONAL PCRYPT_CREDENTIALS pCredentials,
    OPTIONAL LPVOID pvVerify,
    OPTIONAL LPVOID pvReserved
    );
WINCRYPT32API
BOOL
WINAPI
CryptRetrieveObjectByUrlW (
    LPCWSTR pszUrl,
    LPCSTR pszObjectOid,
    DWORD dwRetrievalFlags,
    DWORD dwTimeout,
    LPVOID* ppvObject,
    HCRYPTASYNC hAsyncRetrieve,
    OPTIONAL PCRYPT_CREDENTIALS pCredentials,
    OPTIONAL LPVOID pvVerify,
    OPTIONAL LPVOID pvReserved
    );
#ifdef UNICODE
#define CryptRetrieveObjectByUrl  CryptRetrieveObjectByUrlW
#else
#define CryptRetrieveObjectByUrl  CryptRetrieveObjectByUrlA
#endif // !UNICODE

typedef BOOL (WINAPI *PFN_CRYPT_CANCEL_RETRIEVAL)(
    DWORD dwFlags,
    void  *pvArg
    );

WINCRYPT32API
BOOL
WINAPI
CryptInstallCancelRetrieval(
    PFN_CRYPT_CANCEL_RETRIEVAL pfnCancel, 
    const void *pvArg,
    DWORD dwFlags,
    void *pvReserved
);


WINCRYPT32API
BOOL
WINAPI
CryptUninstallCancelRetrieval(
	DWORD dwFlags,
	void  *pvReserved
	);


WINCRYPT32API
BOOL
WINAPI
CryptCancelAsyncRetrieval (
    HCRYPTASYNC hAsyncRetrieval
    );

#define CRYPT_PARAM_ASYNC_RETRIEVAL_COMPLETION ((LPCSTR)1)

typedef VOID (WINAPI *PFN_CRYPT_ASYNC_RETRIEVAL_COMPLETION_FUNC) (
    LPVOID pvCompletion,
    DWORD dwCompletionCode,
    LPCSTR pszUrl,
    LPSTR pszObjectOid,
    LPVOID pvObject
    );

typedef struct _CRYPT_ASYNC_RETRIEVAL_COMPLETION {
    PFN_CRYPT_ASYNC_RETRIEVAL_COMPLETION_FUNC pfnCompletion;
    LPVOID pvCompletion;
} CRYPT_ASYNC_RETRIEVAL_COMPLETION, *PCRYPT_ASYNC_RETRIEVAL_COMPLETION;

#define CRYPT_PARAM_CANCEL_ASYNC_RETRIEVAL ((LPCSTR)2)

typedef BOOL (WINAPI *PFN_CANCEL_ASYNC_RETRIEVAL_FUNC) (
    HCRYPTASYNC hAsyncRetrieve
    );

#define CRYPT_GET_URL_FROM_PROPERTY         0x00000001
#define CRYPT_GET_URL_FROM_EXTENSION        0x00000002
#define CRYPT_GET_URL_FROM_UNAUTH_ATTRIBUTE 0x00000004
#define CRYPT_GET_URL_FROM_AUTH_ATTRIBUTE   0x00000008

typedef struct _CRYPT_URL_ARRAY {
    DWORD   cUrl;
    LPWSTR* rgwszUrl;
} CRYPT_URL_ARRAY, *PCRYPT_URL_ARRAY;

typedef struct _CRYPT_URL_INFO {
    DWORD cbSize;
} CRYPT_URL_INFO, *PCRYPT_URL_INFO;

WINCRYPT32API
BOOL
WINAPI
CryptGetObjectUrl (
    LPCSTR pszUrlOid,
    LPVOID pvPara,
    DWORD dwFlags,
    OPTIONAL PCRYPT_URL_ARRAY pUrlArray,
    DWORD* pcbUrlArray,
    OPTIONAL PCRYPT_URL_INFO pUrlInfo,
    OPTIONAL DWORD* pcbUrlInfo,
    OPTIONAL LPVOID pvReserved
    );

#define URL_OID_GET_OBJECT_URL_FUNC "UrlDllGetObjectUrl"
#define URL_OID_CERTIFICATE_ISSUER         ((LPCSTR)1)
#define URL_OID_CERTIFICATE_CRL_DIST_POINT ((LPCSTR)2)
#define URL_OID_CTL_ISSUER                 ((LPCSTR)3)
#define URL_OID_CTL_NEXT_UPDATE            ((LPCSTR)4)
#define URL_OID_CRL_ISSUER                 ((LPCSTR)5)

WINCRYPT32API
BOOL
WINAPI
CryptGetTimeValidObject (
    LPCSTR pszTimeValidOid,
    LPVOID pvPara,
    PCCERT_CONTEXT pIssuer,
    OPTIONAL LPFILETIME pftValidFor,
    DWORD dwFlags,
    DWORD dwTimeout,
    OPTIONAL LPVOID* ppvObject,
    OPTIONAL PCRYPT_CREDENTIALS pCredentials,
    OPTIONAL LPVOID pvReserved
    );

#define TIME_VALID_OID_GET_OBJECT_FUNC "TimeValidDllGetObject"
#define TIME_VALID_OID_GET_CTL           ((LPCSTR)1)
#define TIME_VALID_OID_GET_CRL           ((LPCSTR)2)
#define TIME_VALID_OID_GET_CRL_FROM_CERT ((LPCSTR)3)

WINCRYPT32API
BOOL
WINAPI
CryptFlushTimeValidObject (
     LPCSTR pszFlushTimeValidOid,
     LPVOID pvPara,
     PCCERT_CONTEXT pIssuer,
     DWORD dwFlags,
     LPVOID pvReserved
     );

#define TIME_VALID_OID_FLUSH_OBJECT_FUNC "TimeValidDllFlushObject"

#define TIME_VALID_OID_FLUSH_CTL           ((LPCSTR)1)
#define TIME_VALID_OID_FLUSH_CRL           ((LPCSTR)2)
#define TIME_VALID_OID_FLUSH_CRL_FROM_CERT ((LPCSTR)3)

typedef struct  _CRYPTPROTECT_PROMPTSTRUCT
{
    DWORD cbSize;
    DWORD dwPromptFlags;
    HWND  hwndApp;
    LPCWSTR szPrompt;
} CRYPTPROTECT_PROMPTSTRUCT, *PCRYPTPROTECT_PROMPTSTRUCT;

#define CRYPTPROTECT_DEFAULT_PROVIDER   { 0xdf9d8cd0, 0x1501, 0x11d1, {0x8c, 0x7a, 0x00, 0xc0, 0x4f, 0xc2, 0x97, 0xeb} }
#define CRYPTPROTECT_PROMPT_ON_UNPROTECT     0x1
#define CRYPTPROTECT_PROMPT_ON_PROTECT       0x2
#define CRYPTPROTECT_PROMPT_RESERVED	     0x04
#define CRYPTPROTECT_PROMPT_REQUIRE_STRONG   0x10
#define CRYPTPROTECT_LOCAL_MACHINE       0x4
#define CRYPTPROTECT_CRED_SYNC           0x8
#define CRYPTPROTECT_FIRST_RESERVED_FLAGVAL    0x0FFFFFFF
#define CRYPTPROTECT_LAST_RESERVED_FLAGVAL     0xFFFFFFFF

WINCRYPT32API
BOOL
WINAPI
CryptProtectData(
                 DATA_BLOB*      pDataIn,
                 LPCWSTR         szDataDescr,
    OPTIONAL     DATA_BLOB*      pOptionalEntropy,
                 PVOID           pvReserved,
    OPTIONAL     CRYPTPROTECT_PROMPTSTRUCT*  pPromptStruct,
                 DWORD           dwFlags,
                DATA_BLOB*      pDataOut
    );

WINCRYPT32API
BOOL
WINAPI
CryptUnprotectData(
                 DATA_BLOB*      pDataIn,
    OPTIONAL    LPWSTR*         ppszDataDescr,
    OPTIONAL     DATA_BLOB*      pOptionalEntropy,
                 PVOID           pvReserved,
    OPTIONAL     CRYPTPROTECT_PROMPTSTRUCT*  pPromptStruct,
                 DWORD           dwFlags,
                DATA_BLOB*      pDataOut
    );

WINCRYPT32API
PCCERT_CONTEXT
WINAPI
CertCreateSelfSignCertificate(
             HCRYPTPROV                  hProv,
             PCERT_NAME_BLOB             pSubjectIssuerBlob,
             DWORD                       dwFlags,
    OPTIONAL    PCRYPT_KEY_PROV_INFO        pKeyProvInfo,
    OPTIONAL    PCRYPT_ALGORITHM_IDENTIFIER pSignatureAlgorithm,
    OPTIONAL    PSYSTEMTIME                 pStartTime,
    OPTIONAL    PSYSTEMTIME                 pEndTime,
    OPTIONAL    PCERT_EXTENSIONS            pExtensions
    );

#define CERT_CREATE_SELFSIGN_NO_SIGN    1
#define CERT_CREATE_SELFSIGN_NO_KEY_INFO 2

WINCRYPT32API
BOOL
WINAPI
CryptGetKeyIdentifierProperty(
    const CRYPT_HASH_BLOB *pKeyIdentifier,
    DWORD dwPropId,
    DWORD dwFlags,
    OPTIONAL LPCWSTR pwszComputerName,
    OPTIONAL void *pvReserved,
    void *pvData,
    DWORD *pcbData
    );

#define CRYPT_KEYID_MACHINE_FLAG        0x00000020
#define CRYPT_KEYID_ALLOC_FLAG          0x00008000

WINCRYPT32API
BOOL
WINAPI
CryptSetKeyIdentifierProperty(
    const CRYPT_HASH_BLOB *pKeyIdentifier,
    DWORD dwPropId,
    DWORD dwFlags,
    OPTIONAL LPCWSTR pwszComputerName,
    OPTIONAL void *pvReserved,
    const void *pvData
    );

#define CRYPT_KEYID_DELETE_FLAG         0x00000010
#define CRYPT_KEYID_SET_NEW_FLAG        0x00002000

typedef BOOL (WINAPI *PFN_CRYPT_ENUM_KEYID_PROP)(
    const CRYPT_HASH_BLOB *pKeyIdentifier,
    DWORD dwFlags,
    void *pvReserved,
    void *pvArg,
    DWORD cProp,
    DWORD *rgdwPropId,
    void **rgpvData,
    DWORD *rgcbData
    );

WINCRYPT32API
BOOL
WINAPI
CryptEnumKeyIdentifierProperties(
    OPTIONAL const CRYPT_HASH_BLOB *pKeyIdentifier,
    DWORD dwPropId,
    DWORD dwFlags,
    OPTIONAL LPCWSTR pwszComputerName,
    OPTIONAL void *pvReserved,
    OPTIONAL void *pvArg,
    PFN_CRYPT_ENUM_KEYID_PROP pfnEnum
    );

WINCRYPT32API
BOOL
WINAPI
CryptCreateKeyIdentifierFromCSP(
    DWORD dwCertEncodingType,
    OPTIONAL LPCSTR pszPubKeyOID,
    const PUBLICKEYSTRUC *pPubKeyStruc,
    DWORD cbPubKeyStruc,
    DWORD dwFlags,
    OPTIONAL void *pvReserved,
    BYTE *pbHash,
    DWORD *pcbHash
    );

typedef HANDLE HCERTCHAINENGINE;

#define HCCE_CURRENT_USER  ((HCERTCHAINENGINE)NULL)
#define HCCE_LOCAL_MACHINE ((HCERTCHAINENGINE)0x1)
#define CERT_CHAIN_CACHE_END_CERT           0x00000001
#define CERT_CHAIN_THREAD_STORE_SYNC        0x00000002
#define CERT_CHAIN_CACHE_ONLY_URL_RETRIEVAL 0x00000004
#define CERT_CHAIN_USE_LOCAL_MACHINE_STORE  0x00000008
#define CERT_CHAIN_ENABLE_CACHE_AUTO_UPDATE 0x00000010

typedef struct _CERT_CHAIN_ENGINE_CONFIG {

    DWORD       cbSize;
    HCERTSTORE  hRestrictedRoot;
    HCERTSTORE  hRestrictedTrust;
    HCERTSTORE  hRestrictedOther;
    DWORD       cAdditionalStore;
    HCERTSTORE* rghAdditionalStore;
    DWORD       dwFlags;
    DWORD       dwUrlRetrievalTimeout;
    DWORD       MaximumCachedCertificates;
    DWORD       CycleDetectionModulus;

} CERT_CHAIN_ENGINE_CONFIG, *PCERT_CHAIN_ENGINE_CONFIG;

WINCRYPT32API
BOOL
WINAPI
CertCreateCertificateChainEngine (
    PCERT_CHAIN_ENGINE_CONFIG pConfig,
    HCERTCHAINENGINE* phChainEngine
    );

WINCRYPT32API
VOID
WINAPI
CertFreeCertificateChainEngine (
    HCERTCHAINENGINE hChainEngine
    );

WINCRYPT32API
BOOL
WINAPI
CertResyncCertificateChainEngine (
    HCERTCHAINENGINE hChainEngine
    );

typedef struct _CERT_TRUST_STATUS {

    DWORD dwErrorStatus;
    DWORD dwInfoStatus;

} CERT_TRUST_STATUS, *PCERT_TRUST_STATUS;

#define CERT_TRUST_NO_ERROR                   0x00000000
#define CERT_TRUST_IS_NOT_TIME_VALID          0x00000001
#define CERT_TRUST_IS_NOT_TIME_NESTED         0x00000002
#define CERT_TRUST_IS_REVOKED                 0x00000004
#define CERT_TRUST_IS_NOT_SIGNATURE_VALID     0x00000008
#define CERT_TRUST_IS_NOT_VALID_FOR_USAGE     0x00000010
#define CERT_TRUST_IS_UNTRUSTED_ROOT          0x00000020
#define CERT_TRUST_REVOCATION_STATUS_UNKNOWN  0x00000040
#define CERT_TRUST_IS_CYCLIC                  0x00000080
#define CERT_TRUST_IS_PARTIAL_CHAIN           0x00010000
#define CERT_TRUST_CTL_IS_NOT_TIME_VALID      0x00020000
#define CERT_TRUST_CTL_IS_NOT_SIGNATURE_VALID 0x00040000
#define CERT_TRUST_CTL_IS_NOT_VALID_FOR_USAGE 0x00080000
#define CERT_TRUST_HAS_EXACT_MATCH_ISSUER     0x00000001
#define CERT_TRUST_HAS_KEY_MATCH_ISSUER       0x00000002
#define CERT_TRUST_HAS_NAME_MATCH_ISSUER      0x00000004
#define CERT_TRUST_IS_SELF_SIGNED             0x00000008
#define CERT_TRUST_IS_COMPLEX_CHAIN           0x00010000

typedef struct _CERT_REVOCATION_INFO {

    DWORD  cbSize;
    DWORD  dwRevocationResult;
    LPCSTR pszRevocationOid;
    LPVOID pvOidSpecificInfo;

} CERT_REVOCATION_INFO, *PCERT_REVOCATION_INFO;

typedef struct _CERT_TRUST_LIST_INFO {

    DWORD         cbSize;
    PCTL_ENTRY    pCtlEntry;
    PCCTL_CONTEXT pCtlContext;

} CERT_TRUST_LIST_INFO, *PCERT_TRUST_LIST_INFO;

typedef struct _CERT_CHAIN_ELEMENT {

    DWORD                 cbSize;
    PCCERT_CONTEXT        pCertContext;
    CERT_TRUST_STATUS     TrustStatus;
    PCERT_REVOCATION_INFO pRevocationInfo;

} CERT_CHAIN_ELEMENT, *PCERT_CHAIN_ELEMENT;

typedef struct _CERT_SIMPLE_CHAIN {

    DWORD                 cbSize;
    CERT_TRUST_STATUS     TrustStatus;
    DWORD                 cElement;
    PCERT_CHAIN_ELEMENT*  rgpElement;
    PCERT_TRUST_LIST_INFO pTrustListInfo;

} CERT_SIMPLE_CHAIN, *PCERT_SIMPLE_CHAIN;

typedef struct _CERT_CHAIN_CONTEXT {

    DWORD               cbSize;
    CERT_TRUST_STATUS   TrustStatus;
    DWORD               cChain;
    PCERT_SIMPLE_CHAIN* rgpChain;

} CERT_CHAIN_CONTEXT, *PCERT_CHAIN_CONTEXT;

typedef const CERT_CHAIN_CONTEXT *PCCERT_CHAIN_CONTEXT;
#define USAGE_MATCH_TYPE_AND 0x00000000
#define USAGE_MATCH_TYPE_OR  0x00000001

typedef struct _CERT_USAGE_MATCH {

    DWORD             dwType;
    CERT_ENHKEY_USAGE Usage;

} CERT_USAGE_MATCH, *PCERT_USAGE_MATCH;

typedef struct _CTL_USAGE_MATCH {

    DWORD     dwType;
    CTL_USAGE Usage;

} CTL_USAGE_MATCH, *PCTL_USAGE_MATCH;

typedef struct _CERT_CHAIN_PARA {

    DWORD            cbSize;
    CERT_USAGE_MATCH RequestedUsage;

} CERT_CHAIN_PARA, *PCERT_CHAIN_PARA;

#define CERT_CHAIN_REVOCATION_CHECK_END_CERT           0x10000000
#define CERT_CHAIN_REVOCATION_CHECK_CHAIN              0x20000000
#define CERT_CHAIN_REVOCATION_CHECK_CHAIN_EXCLUDE_ROOT 0x40000000
#define CERT_CHAIN_REVOCATION_CHECK_CACHE_ONLY         0x80000000

WINCRYPT32API
BOOL
WINAPI
CertGetCertificateChain (
    OPTIONAL HCERTCHAINENGINE hChainEngine,
    PCCERT_CONTEXT pCertContext,
    OPTIONAL LPFILETIME pTime,
    OPTIONAL HCERTSTORE hAdditionalStore,
    PCERT_CHAIN_PARA pChainPara,
    DWORD dwFlags,
    LPVOID pvReserved,
    PCCERT_CHAIN_CONTEXT* ppChainContext
    );

WINCRYPT32API
VOID
WINAPI
CertFreeCertificateChain (
    PCCERT_CHAIN_CONTEXT pChainContext
    );

WINCRYPT32API
PCCERT_CHAIN_CONTEXT
WINAPI
CertDuplicateCertificateChain (
    PCCERT_CHAIN_CONTEXT pChainContext
    );

#define REVOCATION_OID_CRL_REVOCATION ((LPCSTR)1)

typedef struct _CRL_REVOCATION_INFO {

    PCRL_ENTRY           pCrlEntry;
    PCCRL_CONTEXT        pCrlContext;
    PCCERT_CHAIN_CONTEXT pCrlIssuerChain;

} CRL_REVOCATION_INFO, *PCRL_REVOCATION_INFO;

WINCRYPT32API
PCCERT_CHAIN_CONTEXT
WINAPI
CertFindChainInStore(
    HCERTSTORE hCertStore,
    DWORD dwCertEncodingType,
    DWORD dwFindFlags,
    DWORD dwFindType,
    const void *pvFindPara,
    PCCERT_CHAIN_CONTEXT pPrevChainContext
    );

#define CERT_CHAIN_FIND_BY_ISSUER       1

typedef BOOL (WINAPI *PFN_CERT_CHAIN_FIND_BY_ISSUER_CALLBACK)(
    PCCERT_CONTEXT pCert,
    void *pvFindArg
    );

typedef struct _CERT_CHAIN_FIND_BY_ISSUER_PARA {
    DWORD                                   cbSize;
    LPCSTR                                  pszUsageIdentifier;
    DWORD                                   dwKeySpec;
    DWORD                                   dwAcquirePrivateKeyFlags;
    DWORD                                   cIssuer;
    CERT_NAME_BLOB                          *rgIssuer;
    PFN_CERT_CHAIN_FIND_BY_ISSUER_CALLBACK pfnFindCallback;
    void                                    *pvFindArg;
} CERT_CHAIN_FIND_BY_ISSUER_PARA, *PCERT_CHAIN_FIND_ISSUER_PARA;
#define CERT_CHAIN_FIND_BY_ISSUER_COMPARE_KEY_FLAG          0x0001
#define CERT_CHAIN_FIND_BY_ISSUER_COMPLEX_CHAIN_FLAG        0x0002
#define CERT_CHAIN_FIND_BY_ISSUER_CACHE_ONLY_URL_FLAG       0x0004
#define CERT_CHAIN_FIND_BY_ISSUER_LOCAL_MACHINE_FLAG        0x0008
#define CERT_CHAIN_FIND_BY_ISSUER_NO_KEY_FLAG               0x4000

#define CERT_CHAIN_FIND_BY_ISSUER_CACHE_ONLY_FLAG           0x8000

typedef struct _CERT_CHAIN_POLICY_PARA {
    DWORD                   cbSize;
    DWORD                   dwFlags;
    void                    *pvExtraPolicyPara;     // pszPolicyOID specific
} CERT_CHAIN_POLICY_PARA, *PCERT_CHAIN_POLICY_PARA;

typedef struct _CERT_CHAIN_POLICY_STATUS {
    DWORD                   cbSize;
    DWORD                   dwError;
    LONG                    lChainIndex;
    LONG                    lElementIndex;
    void                    *pvExtraPolicyStatus;   // pszPolicyOID specific
} CERT_CHAIN_POLICY_STATUS, *PCERT_CHAIN_POLICY_STATUS;

// Common chain policy flags
#define CERT_CHAIN_POLICY_IGNORE_NOT_TIME_VALID_FLAG                0x00000001
#define CERT_CHAIN_POLICY_IGNORE_CTL_NOT_TIME_VALID_FLAG            0x00000002
#define CERT_CHAIN_POLICY_IGNORE_NOT_TIME_NESTED_FLAG               0x00000004

#define CERT_CHAIN_POLICY_IGNORE_ALL_NOT_TIME_VALID_FLAGS ( \
    CERT_CHAIN_POLICY_IGNORE_NOT_TIME_VALID_FLAG                | \
    CERT_CHAIN_POLICY_IGNORE_CTL_NOT_TIME_VALID_FLAG            | \
    CERT_CHAIN_POLICY_IGNORE_NOT_TIME_NESTED_FLAG                 \
    )

#define CERT_CHAIN_POLICY_ALLOW_UNKNOWN_CA_FLAG                     0x00000010
#define CERT_CHAIN_POLICY_IGNORE_WRONG_USAGE_FLAG                   0x00000020
#define CERT_CHAIN_POLICY_IGNORE_END_REV_UNKNOWN_FLAG               0x00000100
#define CERT_CHAIN_POLICY_IGNORE_CTL_SIGNER_REV_UNKNOWN_FLAG        0x00000200
#define CERT_CHAIN_POLICY_IGNORE_CA_REV_UNKNOWN_FLAG                0x00000400
#define CERT_CHAIN_POLICY_IGNORE_ROOT_REV_UNKNOWN_FLAG              0x00000800
#define CERT_CHAIN_POLICY_IGNORE_ALL_REV_UNKNOWN_FLAGS ( \
    CERT_CHAIN_POLICY_IGNORE_END_REV_UNKNOWN_FLAG         | \
    CERT_CHAIN_POLICY_IGNORE_CTL_SIGNER_REV_UNKNOWN_FLAG  | \
    CERT_CHAIN_POLICY_IGNORE_CA_REV_UNKNOWN_FLAG          | \
    CERT_CHAIN_POLICY_IGNORE_ROOT_REV_UNKNOWN_FLAG          \
    )

#define CERT_CHAIN_POLICY_ALLOW_TESTROOT_FLAG                       0x00008000
#define CERT_CHAIN_POLICY_TRUST_TESTROOT_FLAG                       0x00004000

WINCRYPT32API
BOOL
WINAPI
CertVerifyCertificateChainPolicy(
    LPCSTR pszPolicyOID,
    PCCERT_CHAIN_CONTEXT pChainContext,
    PCERT_CHAIN_POLICY_PARA pPolicyPara,
    PCERT_CHAIN_POLICY_STATUS pPolicyStatus
    );

#define CRYPT_OID_VERIFY_CERTIFICATE_CHAIN_POLICY_FUNC  \
    "CertDllVerifyCertificateChainPolicy"

#define CERT_CHAIN_POLICY_BASE              ((LPCSTR) 1)
#define CERT_CHAIN_POLICY_AUTHENTICODE      ((LPCSTR) 2)
#define CERT_CHAIN_POLICY_AUTHENTICODE_TS   ((LPCSTR) 3)
#define CERT_CHAIN_POLICY_SSL               ((LPCSTR) 4)
#define CERT_CHAIN_POLICY_BASIC_CONSTRAINTS ((LPCSTR) 5)
#define CERT_CHAIN_POLICY_NT_AUTH           ((LPCSTR) 6)

typedef struct _AUTHENTICODE_EXTRA_CERT_CHAIN_POLICY_PARA {
    DWORD               cbSize;
    DWORD               dwRegPolicySettings;
    PCMSG_SIGNER_INFO   pSignerInfo;                // optional
} AUTHENTICODE_EXTRA_CERT_CHAIN_POLICY_PARA,
    *PAUTHENTICODE_EXTRA_CERT_CHAIN_POLICY_PARA;

typedef struct _AUTHENTICODE_EXTRA_CERT_CHAIN_POLICY_STATUS {
    DWORD               cbSize;
    BOOL                fCommercial;        // obtained from signer statement
} AUTHENTICODE_EXTRA_CERT_CHAIN_POLICY_STATUS,
    *PAUTHENTICODE_EXTRA_CERT_CHAIN_POLICY_STATUS;

typedef struct _AUTHENTICODE_TS_EXTRA_CERT_CHAIN_POLICY_PARA {
    DWORD               cbSize;
    DWORD               dwRegPolicySettings;
    BOOL                fCommercial;
} AUTHENTICODE_TS_EXTRA_CERT_CHAIN_POLICY_PARA,
    *PAUTHENTICODE_TS_EXTRA_CERT_CHAIN_POLICY_PARA;

typedef struct _HTTPSPolicyCallbackData
{
    union {
        DWORD           cbStruct;       // sizeof(HTTPSPolicyCallbackData);
        DWORD           cbSize;         // sizeof(HTTPSPolicyCallbackData);
    };

    DWORD           dwAuthType;
#                       define      AUTHTYPE_CLIENT         1
#                       define      AUTHTYPE_SERVER         2

    DWORD           fdwChecks;

    WCHAR           *pwszServerName; // used to check against CN=xxxx

} HTTPSPolicyCallbackData, *PHTTPSPolicyCallbackData,
    SSL_EXTRA_CERT_CHAIN_POLICY_PARA, *PSSL_EXTRA_CERT_CHAIN_POLICY_PARA;

#define BASIC_CONSTRAINTS_CERT_CHAIN_POLICY_CA_FLAG         0x80000000
#define BASIC_CONSTRAINTS_CERT_CHAIN_POLICY_END_ENTITY_FLAG 0x40000000

#pragma warning(pop)

#endif // __WINCRYPT_H__


