/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#pragma warning( disable: 4049 )

#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __oaidl_h__
#define __oaidl_h__

#ifndef __ICreateTypeInfo_FWD_DEFINED__
#define __ICreateTypeInfo_FWD_DEFINED__
typedef interface ICreateTypeInfo ICreateTypeInfo;
#endif 	/* __ICreateTypeInfo_FWD_DEFINED__ */

#ifndef __ICreateTypeInfo2_FWD_DEFINED__
#define __ICreateTypeInfo2_FWD_DEFINED__
typedef interface ICreateTypeInfo2 ICreateTypeInfo2;
#endif 	/* __ICreateTypeInfo2_FWD_DEFINED__ */

#ifndef __ICreateTypeLib_FWD_DEFINED__
#define __ICreateTypeLib_FWD_DEFINED__
typedef interface ICreateTypeLib ICreateTypeLib;
#endif 	/* __ICreateTypeLib_FWD_DEFINED__ */

#ifndef __ICreateTypeLib2_FWD_DEFINED__
#define __ICreateTypeLib2_FWD_DEFINED__
typedef interface ICreateTypeLib2 ICreateTypeLib2;
#endif 	/* __ICreateTypeLib2_FWD_DEFINED__ */

#ifndef __IDispatch_FWD_DEFINED__
#define __IDispatch_FWD_DEFINED__
typedef interface IDispatch IDispatch;
#endif 	/* __IDispatch_FWD_DEFINED__ */

#ifndef __IEnumVARIANT_FWD_DEFINED__
#define __IEnumVARIANT_FWD_DEFINED__
typedef interface IEnumVARIANT IEnumVARIANT;
#endif 	/* __IEnumVARIANT_FWD_DEFINED__ */

#ifndef __ITypeComp_FWD_DEFINED__
#define __ITypeComp_FWD_DEFINED__
typedef interface ITypeComp ITypeComp;
#endif 	/* __ITypeComp_FWD_DEFINED__ */

#ifndef __ITypeInfo_FWD_DEFINED__
#define __ITypeInfo_FWD_DEFINED__
typedef interface ITypeInfo ITypeInfo;
#endif 	/* __ITypeInfo_FWD_DEFINED__ */

#ifndef __ITypeInfo2_FWD_DEFINED__
#define __ITypeInfo2_FWD_DEFINED__
typedef interface ITypeInfo2 ITypeInfo2;
#endif 	/* __ITypeInfo2_FWD_DEFINED__ */

#ifndef __ITypeLib_FWD_DEFINED__
#define __ITypeLib_FWD_DEFINED__
typedef interface ITypeLib ITypeLib;
#endif 	/* __ITypeLib_FWD_DEFINED__ */

#ifndef __ITypeLib2_FWD_DEFINED__
#define __ITypeLib2_FWD_DEFINED__
typedef interface ITypeLib2 ITypeLib2;
#endif 	/* __ITypeLib2_FWD_DEFINED__ */

#ifndef __ITypeChangeEvents_FWD_DEFINED__
#define __ITypeChangeEvents_FWD_DEFINED__
typedef interface ITypeChangeEvents ITypeChangeEvents;
#endif 	/* __ITypeChangeEvents_FWD_DEFINED__ */

#ifndef __IErrorInfo_FWD_DEFINED__
#define __IErrorInfo_FWD_DEFINED__
typedef interface IErrorInfo IErrorInfo;
#endif 	/* __IErrorInfo_FWD_DEFINED__ */

#ifndef __ICreateErrorInfo_FWD_DEFINED__
#define __ICreateErrorInfo_FWD_DEFINED__
typedef interface ICreateErrorInfo ICreateErrorInfo;
#endif 	/* __ICreateErrorInfo_FWD_DEFINED__ */

#ifndef __ISupportErrorInfo_FWD_DEFINED__
#define __ISupportErrorInfo_FWD_DEFINED__
typedef interface ISupportErrorInfo ISupportErrorInfo;
#endif 	/* __ISupportErrorInfo_FWD_DEFINED__ */

#ifndef __ITypeFactory_FWD_DEFINED__
#define __ITypeFactory_FWD_DEFINED__
typedef interface ITypeFactory ITypeFactory;
#endif 	/* __ITypeFactory_FWD_DEFINED__ */

#ifndef __ITypeMarshal_FWD_DEFINED__
#define __ITypeMarshal_FWD_DEFINED__
typedef interface ITypeMarshal ITypeMarshal;
#endif 	/* __ITypeMarshal_FWD_DEFINED__ */

#ifndef __IRecordInfo_FWD_DEFINED__
#define __IRecordInfo_FWD_DEFINED__
typedef interface IRecordInfo IRecordInfo;
#endif 	/* __IRecordInfo_FWD_DEFINED__ */

#ifndef __IErrorLog_FWD_DEFINED__
#define __IErrorLog_FWD_DEFINED__
typedef interface IErrorLog IErrorLog;
#endif 	/* __IErrorLog_FWD_DEFINED__ */

#ifndef __IPropertyBag_FWD_DEFINED__
#define __IPropertyBag_FWD_DEFINED__
typedef interface IPropertyBag IPropertyBag;
#endif 	/* __IPropertyBag_FWD_DEFINED__ */

#include "objidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * );

#pragma warning(push)
#pragma warning(disable:4201)

#pragma once

extern RPC_IF_HANDLE __MIDL_itf_oaidl_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_oaidl_0000_v0_0_s_ifspec;

#ifndef __IOleAutomationTypes_INTERFACE_DEFINED__
#define __IOleAutomationTypes_INTERFACE_DEFINED__

typedef CY CURRENCY;

typedef struct tagSAFEARRAYBOUND
{
    ULONG cElements;
    LONG lLbound;
}	SAFEARRAYBOUND;

typedef struct tagSAFEARRAYBOUND __RPC_FAR *LPSAFEARRAYBOUND;
typedef struct _wireVARIANT __RPC_FAR *wireVARIANT;
typedef struct _wireBRECORD __RPC_FAR *wireBRECORD;

typedef struct _wireSAFEARR_BSTR
{
    ULONG Size;
    wireBSTR __RPC_FAR *aBstr;
}	SAFEARR_BSTR;

typedef struct _wireSAFEARR_UNKNOWN
{
    ULONG Size;
    IUnknown __RPC_FAR *__RPC_FAR *apUnknown;
}	SAFEARR_UNKNOWN;

typedef struct _wireSAFEARR_DISPATCH
{
    ULONG Size;
    IDispatch __RPC_FAR *__RPC_FAR *apDispatch;
}	SAFEARR_DISPATCH;

typedef struct _wireSAFEARR_VARIANT
{
    ULONG Size;
    wireVARIANT __RPC_FAR *aVariant;
}	SAFEARR_VARIANT;

typedef struct _wireSAFEARR_BRECORD
{
    ULONG Size;
    wireBRECORD __RPC_FAR *aRecord;
}	SAFEARR_BRECORD;

typedef struct _wireSAFEARR_HAVEIID
{
    ULONG Size;
    IUnknown __RPC_FAR *__RPC_FAR *apUnknown;
    IID iid;
}	SAFEARR_HAVEIID;

typedef 
enum tagSF_TYPE
{	SF_ERROR	= VT_ERROR,
	SF_I1	= VT_I1,
	SF_I2	= VT_I2,
	SF_I4	= VT_I4,
	SF_I8	= VT_I8,
	SF_BSTR	= VT_BSTR,
	SF_UNKNOWN	= VT_UNKNOWN,
	SF_DISPATCH	= VT_DISPATCH,
	SF_VARIANT	= VT_VARIANT,
	SF_RECORD	= VT_RECORD,
	SF_HAVEIID	= VT_UNKNOWN | VT_RESERVED
}	SF_TYPE;

typedef struct _wireSAFEARRAY_UNION
{
    ULONG sfType;
    union __MIDL_IOleAutomationTypes_0001
    {
        SAFEARR_BSTR BstrStr;
        SAFEARR_UNKNOWN UnknownStr;
        SAFEARR_DISPATCH DispatchStr;
        SAFEARR_VARIANT VariantStr;
        SAFEARR_BRECORD RecordStr;
        SAFEARR_HAVEIID HaveIidStr;
        BYTE_SIZEDARR ByteStr;
        WORD_SIZEDARR WordStr;
        DWORD_SIZEDARR LongStr;
        HYPER_SIZEDARR HyperStr;
    }	u;
}	SAFEARRAYUNION;

typedef struct _wireSAFEARRAY
{
    USHORT cDims;
    USHORT fFeatures;
    ULONG cbElements;
    ULONG cLocks;
    SAFEARRAYUNION uArrayStructs;
    SAFEARRAYBOUND rgsabound[ 1 ];
}	__RPC_FAR *wireSAFEARRAY;

typedef wireSAFEARRAY __RPC_FAR *wirePSAFEARRAY;

typedef struct tagSAFEARRAY
{
    USHORT cDims;
    USHORT fFeatures;
    ULONG cbElements;
    ULONG cLocks;
    PVOID pvData;
    SAFEARRAYBOUND rgsabound[ 1 ];
}	SAFEARRAY;

typedef SAFEARRAY __RPC_FAR *LPSAFEARRAY;

#define	FADF_AUTO	( 0x1 )
#define	FADF_STATIC	( 0x2 )
#define	FADF_EMBEDDED	( 0x4 )
#define	FADF_FIXEDSIZE	( 0x10 )
#define	FADF_RECORD	( 0x20 )
#define	FADF_HAVEIID	( 0x40 )
#define	FADF_HAVEVARTYPE	( 0x80 )
#define	FADF_BSTR	( 0x100 )
#define	FADF_UNKNOWN	( 0x200 )
#define	FADF_DISPATCH	( 0x400 )
#define	FADF_VARIANT	( 0x800 )
#define	FADF_RESERVED	( 0xf008 )

#if (__STDC__ && !defined(_FORCENAMELESSUNION)) || defined(NONAMELESSUNION)
#define __VARIANT_NAME_1 n1
#define __VARIANT_NAME_2 n2
#define __VARIANT_NAME_3 n3
#define __VARIANT_NAME_4 brecVal
#else
#define __tagVARIANT
#define __VARIANT_NAME_1
#define __VARIANT_NAME_2
#define __VARIANT_NAME_3
#define __tagBRECORD
#define __VARIANT_NAME_4
#endif
typedef struct tagVARIANT VARIANT;

struct tagVARIANT
{
    union 
        {
        struct __tagVARIANT
            {
            VARTYPE vt;
            WORD wReserved1;
            WORD wReserved2;
            WORD wReserved3;
            union 
                {
                ULONGLONG ullVal;
                LONGLONG llVal;
                LONG lVal;
                BYTE bVal;
                SHORT iVal;
                FLOAT fltVal;
                DOUBLE dblVal;
                VARIANT_BOOL boolVal;
                VARIANT_BOOL bool;
                SCODE scode;
                CY cyVal;
                DATE date;
                BSTR bstrVal;
                IUnknown __RPC_FAR *punkVal;
                IDispatch __RPC_FAR *pdispVal;
                SAFEARRAY __RPC_FAR *parray;
                BYTE __RPC_FAR *pbVal;
                SHORT __RPC_FAR *piVal;
                LONG __RPC_FAR *plVal;
                LONGLONG __RPC_FAR *pllVal;
                FLOAT __RPC_FAR *pfltVal;
                DOUBLE __RPC_FAR *pdblVal;
                VARIANT_BOOL __RPC_FAR *pboolVal;
                VARIANT_BOOL __RPC_FAR *pbool;
                SCODE __RPC_FAR *pscode;
                CY __RPC_FAR *pcyVal;
                DATE __RPC_FAR *pdate;
                BSTR __RPC_FAR *pbstrVal;
                IUnknown __RPC_FAR *__RPC_FAR *ppunkVal;
                IDispatch __RPC_FAR *__RPC_FAR *ppdispVal;
                SAFEARRAY __RPC_FAR *__RPC_FAR *pparray;
                VARIANT __RPC_FAR *pvarVal;
                PVOID byref;
                CHAR cVal;
                USHORT uiVal;
                ULONG ulVal;
                INT intVal;
                UINT uintVal;
                DECIMAL __RPC_FAR *pdecVal;
                CHAR __RPC_FAR *pcVal;
                USHORT __RPC_FAR *puiVal;
                ULONG __RPC_FAR *pulVal;
                ULONGLONG __RPC_FAR *pullVal;
                INT __RPC_FAR *pintVal;
                UINT __RPC_FAR *puintVal;
                struct __tagBRECORD
                    {
                    PVOID pvRecord;
                    IRecordInfo __RPC_FAR *pRecInfo;
                    }	__VARIANT_NAME_4;
                }	__VARIANT_NAME_3;
            }	__VARIANT_NAME_2;
        DECIMAL decVal;
        }	__VARIANT_NAME_1;
};
typedef VARIANT __RPC_FAR *LPVARIANT;
typedef VARIANT VARIANTARG;
typedef VARIANT __RPC_FAR *LPVARIANTARG;

struct _wireBRECORD
{
    ULONG fFlags;
    ULONG clSize;
    IRecordInfo __RPC_FAR *pRecInfo;
    byte __RPC_FAR *pRecord;
};
struct _wireVARIANT
{
    DWORD clSize;
    DWORD rpcReserved;
    USHORT vt;
    USHORT wReserved1;
    USHORT wReserved2;
    USHORT wReserved3;
    union 
    {
        LONG lVal;
        BYTE bVal;
        SHORT iVal;
        FLOAT fltVal;
        DOUBLE dblVal;
        VARIANT_BOOL boolVal;
        SCODE scode;
        CY cyVal;
        DATE date;
        wireBSTR bstrVal;
        IUnknown __RPC_FAR *punkVal;
        IDispatch __RPC_FAR *pdispVal;
        wirePSAFEARRAY parray;
        wireBRECORD brecVal;
        BYTE __RPC_FAR *pbVal;
        SHORT __RPC_FAR *piVal;
        LONG __RPC_FAR *plVal;
        FLOAT __RPC_FAR *pfltVal;
        DOUBLE __RPC_FAR *pdblVal;
        VARIANT_BOOL __RPC_FAR *pboolVal;
        SCODE __RPC_FAR *pscode;
        CY __RPC_FAR *pcyVal;
        DATE __RPC_FAR *pdate;
        wireBSTR __RPC_FAR *pbstrVal;
        IUnknown __RPC_FAR *__RPC_FAR *ppunkVal;
        IDispatch __RPC_FAR *__RPC_FAR *ppdispVal;
        wirePSAFEARRAY __RPC_FAR *pparray;
        wireVARIANT __RPC_FAR *pvarVal;
        CHAR cVal;
        USHORT uiVal;
        ULONG ulVal;
        INT intVal;
        UINT uintVal;
        DECIMAL decVal;
        DECIMAL __RPC_FAR *pdecVal;
        CHAR __RPC_FAR *pcVal;
        USHORT __RPC_FAR *puiVal;
        ULONG __RPC_FAR *pulVal;
        INT __RPC_FAR *pintVal;
        UINT __RPC_FAR *puintVal;
    }	;
};
typedef LONG DISPID;
typedef DISPID MEMBERID;
typedef DWORD HREFTYPE;
typedef
enum tagTYPEKIND
{
	TKIND_ENUM	= 0,
	TKIND_RECORD	= TKIND_ENUM + 1,
	TKIND_MODULE	= TKIND_RECORD + 1,
	TKIND_INTERFACE	= TKIND_MODULE + 1,
	TKIND_DISPATCH	= TKIND_INTERFACE + 1,
	TKIND_COCLASS	= TKIND_DISPATCH + 1,
	TKIND_ALIAS	= TKIND_COCLASS + 1,
	TKIND_UNION	= TKIND_ALIAS + 1,
	TKIND_MAX	= TKIND_UNION + 1
}	TYPEKIND;

typedef struct tagTYPEDESC
{
    union 
    {
        struct tagTYPEDESC __RPC_FAR *lptdesc;
        struct tagARRAYDESC __RPC_FAR *lpadesc;
        HREFTYPE hreftype;
    };
    VARTYPE vt;
}	TYPEDESC;

typedef struct tagARRAYDESC
{
    TYPEDESC tdescElem;
    USHORT cDims;
    SAFEARRAYBOUND rgbounds[ 1 ];
}	ARRAYDESC;

typedef struct tagPARAMDESCEX
{
    ULONG cBytes;
    VARIANTARG varDefaultValue;
}	PARAMDESCEX;

typedef struct tagPARAMDESCEX __RPC_FAR *LPPARAMDESCEX;

typedef struct tagPARAMDESC
{
    LPPARAMDESCEX pparamdescex;
    USHORT wParamFlags;
}PARAMDESC;

typedef struct tagPARAMDESC __RPC_FAR *LPPARAMDESC;

#define	PARAMFLAG_NONE	( 0 )
#define	PARAMFLAG_FIN	( 0x1 )
#define	PARAMFLAG_FOUT	( 0x2 )
#define	PARAMFLAG_FLCID	( 0x4 )
#define	PARAMFLAG_FRETVAL	( 0x8 )
#define	PARAMFLAG_FOPT	( 0x10 )
#define	PARAMFLAG_FHASDEFAULT	( 0x20 )
#define	PARAMFLAG_FHASCUSTDATA	( 0x40 )

typedef struct tagIDLDESC
{
    ULONG_PTR dwReserved;
    USHORT wIDLFlags;
}IDLDESC;

typedef struct tagIDLDESC __RPC_FAR *LPIDLDESC;

#define	IDLFLAG_NONE	( PARAMFLAG_NONE )
#define	IDLFLAG_FIN	( PARAMFLAG_FIN )
#define	IDLFLAG_FOUT	( PARAMFLAG_FOUT )
#define	IDLFLAG_FLCID	( PARAMFLAG_FLCID )
#define	IDLFLAG_FRETVAL	( PARAMFLAG_FRETVAL )

#if 0
typedef struct tagELEMDESC
{
    TYPEDESC tdesc;
    PARAMDESC paramdesc;
}ELEMDESC;

#else
typedef struct tagELEMDESC {
    TYPEDESC tdesc;
    union {
        IDLDESC idldesc;
        PARAMDESC paramdesc;
    };
} ELEMDESC, * LPELEMDESC;
#endif
typedef struct tagTYPEATTR
{
    GUID guid;
    LCID lcid;
    DWORD dwReserved;
    MEMBERID memidConstructor;
    MEMBERID memidDestructor;
    LPOLESTR lpstrSchema;
    ULONG cbSizeInstance;
    TYPEKIND typekind;
    WORD cFuncs;
    WORD cVars;
    WORD cImplTypes;
    WORD cbSizeVft;
    WORD cbAlignment;
    WORD wTypeFlags;
    WORD wMajorVerNum;
    WORD wMinorVerNum;
    TYPEDESC tdescAlias;
    IDLDESC idldescType;
}	TYPEATTR;

typedef struct tagTYPEATTR __RPC_FAR *LPTYPEATTR;

typedef struct tagDISPPARAMS
{
    VARIANTARG __RPC_FAR *rgvarg;
    DISPID __RPC_FAR *rgdispidNamedArgs;
    UINT cArgs;
    UINT cNamedArgs;
}	DISPPARAMS;

#if 0
typedef struct tagEXCEPINFO
    {
    WORD wCode;
    WORD wReserved;
    BSTR bstrSource;
    BSTR bstrDescription;
    BSTR bstrHelpFile;
    DWORD dwHelpContext;
    ULONG pvReserved;
    ULONG pfnDeferredFillIn;
    SCODE scode;
    }	EXCEPINFO;

#else /* 0 */
typedef struct tagEXCEPINFO {
    WORD  wCode;
    WORD  wReserved;
    BSTR  bstrSource;
    BSTR  bstrDescription;
    BSTR  bstrHelpFile;
    DWORD dwHelpContext;
    PVOID pvReserved;
    HRESULT (__stdcall *pfnDeferredFillIn)(struct tagEXCEPINFO *);
    SCODE scode;
} EXCEPINFO, * LPEXCEPINFO;
#endif /* 0 */
typedef 
enum tagCALLCONV
{
	CC_FASTCALL	= 0,
	CC_CDECL	= 1,
	CC_MSCPASCAL	= CC_CDECL + 1,
	CC_PASCAL	= CC_MSCPASCAL,
	CC_MACPASCAL	= CC_PASCAL + 1,
	CC_STDCALL	= CC_MACPASCAL + 1,
	CC_FPFASTCALL	= CC_STDCALL + 1,
	CC_SYSCALL	= CC_FPFASTCALL + 1,
	CC_MPWCDECL	= CC_SYSCALL + 1,
	CC_MPWPASCAL	= CC_MPWCDECL + 1,
	CC_MAX	= CC_MPWPASCAL + 1
}	CALLCONV;

typedef
enum tagFUNCKIND
{
	FUNC_VIRTUAL = 0,
	FUNC_PUREVIRTUAL = FUNC_VIRTUAL + 1,
	FUNC_NONVIRTUAL	= FUNC_PUREVIRTUAL + 1,
	FUNC_STATIC	= FUNC_NONVIRTUAL + 1,
	FUNC_DISPATCH = FUNC_STATIC + 1
}	FUNCKIND;

typedef
enum tagINVOKEKIND
{
	INVOKE_FUNC	= 1,
	INVOKE_PROPERTYGET = 2,
	INVOKE_PROPERTYPUT = 4,
	INVOKE_PROPERTYPUTREF = 8
}	INVOKEKIND;

typedef struct tagFUNCDESC
{
    MEMBERID memid;
    SCODE __RPC_FAR *lprgscode;
    ELEMDESC __RPC_FAR *lprgelemdescParam;
    FUNCKIND funckind;
    INVOKEKIND invkind;
    CALLCONV callconv;
    SHORT cParams;
    SHORT cParamsOpt;
    SHORT oVft;
    SHORT cScodes;
    ELEMDESC elemdescFunc;
    WORD wFuncFlags;
}	FUNCDESC;

typedef struct tagFUNCDESC __RPC_FAR *LPFUNCDESC;

typedef
enum tagVARKIND
{
	VAR_PERINSTANCE	= 0,
	VAR_STATIC = VAR_PERINSTANCE + 1,
	VAR_CONST = VAR_STATIC + 1,
	VAR_DISPATCH = VAR_CONST + 1
}	VARKIND;

#define	IMPLTYPEFLAG_FDEFAULT	( 0x1 )
#define	IMPLTYPEFLAG_FSOURCE	( 0x2 )
#define	IMPLTYPEFLAG_FRESTRICTED	( 0x4 )
#define	IMPLTYPEFLAG_FDEFAULTVTABLE	( 0x8 )

typedef struct tagVARDESC
{
    MEMBERID memid;
    LPOLESTR lpstrSchema;
    union 
    {
        ULONG oInst;
        VARIANT __RPC_FAR *lpvarValue;
    };
    ELEMDESC elemdescVar;
    WORD wVarFlags;
    VARKIND varkind;
}	VARDESC;

typedef struct tagVARDESC __RPC_FAR *LPVARDESC;

typedef 
enum tagTYPEFLAGS
{
	TYPEFLAG_FAPPOBJECT	= 0x1,
	TYPEFLAG_FCANCREATE	= 0x2,
	TYPEFLAG_FLICENSED	= 0x4,
	TYPEFLAG_FPREDECLID	= 0x8,
	TYPEFLAG_FHIDDEN	= 0x10,
	TYPEFLAG_FCONTROL	= 0x20,
	TYPEFLAG_FDUAL	= 0x40,
	TYPEFLAG_FNONEXTENSIBLE	= 0x80,
	TYPEFLAG_FOLEAUTOMATION	= 0x100,
	TYPEFLAG_FRESTRICTED	= 0x200,
	TYPEFLAG_FAGGREGATABLE	= 0x400,
	TYPEFLAG_FREPLACEABLE	= 0x800,
	TYPEFLAG_FDISPATCHABLE	= 0x1000,
	TYPEFLAG_FREVERSEBIND	= 0x2000,
	TYPEFLAG_FPROXY	= 0x4000
}	TYPEFLAGS;

typedef 
enum tagFUNCFLAGS
{
	FUNCFLAG_FRESTRICTED	= 0x1,
	FUNCFLAG_FSOURCE	= 0x2,
	FUNCFLAG_FBINDABLE	= 0x4,
	FUNCFLAG_FREQUESTEDIT	= 0x8,
	FUNCFLAG_FDISPLAYBIND	= 0x10,
	FUNCFLAG_FDEFAULTBIND	= 0x20,
	FUNCFLAG_FHIDDEN	= 0x40,
	FUNCFLAG_FUSESGETLASTERROR	= 0x80,
	FUNCFLAG_FDEFAULTCOLLELEM	= 0x100,
	FUNCFLAG_FUIDEFAULT	= 0x200,
	FUNCFLAG_FNONBROWSABLE	= 0x400,
	FUNCFLAG_FREPLACEABLE	= 0x800,
	FUNCFLAG_FIMMEDIATEBIND	= 0x1000
}	FUNCFLAGS;

typedef 
enum tagVARFLAGS
{
	VARFLAG_FREADONLY = 0x1,
	VARFLAG_FSOURCE	= 0x2,
	VARFLAG_FBINDABLE = 0x4,
	VARFLAG_FREQUESTEDIT = 0x8,
	VARFLAG_FDISPLAYBIND = 0x10,
	VARFLAG_FDEFAULTBIND = 0x20,
	VARFLAG_FHIDDEN	= 0x40,
	VARFLAG_FRESTRICTED	= 0x80,
	VARFLAG_FDEFAULTCOLLELEM = 0x100,
	VARFLAG_FUIDEFAULT = 0x200,
	VARFLAG_FNONBROWSABLE = 0x400,
	VARFLAG_FREPLACEABLE = 0x800,
	VARFLAG_FIMMEDIATEBIND = 0x1000
}	VARFLAGS;

typedef struct tagCLEANLOCALSTORAGE
{
    IUnknown __RPC_FAR *pInterface;
    PVOID pStorage;
    DWORD flags;
}	CLEANLOCALSTORAGE;

typedef struct tagCUSTDATAITEM
    {
    GUID guid;
    VARIANTARG varValue;
    }	CUSTDATAITEM;

typedef struct tagCUSTDATAITEM __RPC_FAR *LPCUSTDATAITEM;

typedef struct tagCUSTDATA
{
    DWORD cCustData;
    LPCUSTDATAITEM prgCustData;
}	CUSTDATA;

typedef struct tagCUSTDATA __RPC_FAR *LPCUSTDATA;

extern RPC_IF_HANDLE IOleAutomationTypes_v1_0_c_ifspec;
extern RPC_IF_HANDLE IOleAutomationTypes_v1_0_s_ifspec;
#endif /* __IOleAutomationTypes_INTERFACE_DEFINED__ */

#ifndef __ICreateTypeInfo_INTERFACE_DEFINED__
#define __ICreateTypeInfo_INTERFACE_DEFINED__
typedef ICreateTypeInfo __RPC_FAR *LPCREATETYPEINFO;

EXTERN_C const IID IID_ICreateTypeInfo;

typedef struct ICreateTypeInfoVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICreateTypeInfo __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICreateTypeInfo __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICreateTypeInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetGuid )( 
            ICreateTypeInfo __RPC_FAR * This,
            REFGUID guid);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTypeFlags )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT uTypeFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDocString )( 
            ICreateTypeInfo __RPC_FAR * This,
            LPOLESTR pStrDoc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpContext )( 
            ICreateTypeInfo __RPC_FAR * This,
            DWORD dwHelpContext);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVersion )( 
            ICreateTypeInfo __RPC_FAR * This,
            WORD wMajorVerNum,
            WORD wMinorVerNum);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddRefTypeInfo )( 
            ICreateTypeInfo __RPC_FAR * This,
            ITypeInfo __RPC_FAR *pTInfo,
            HREFTYPE __RPC_FAR *phRefType);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddFuncDesc )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            FUNCDESC __RPC_FAR *pFuncDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddImplType )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            HREFTYPE hRefType);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetImplTypeFlags )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            INT implTypeFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetAlignment )( 
            ICreateTypeInfo __RPC_FAR * This,
            WORD cbAlignment);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSchema )( 
            ICreateTypeInfo __RPC_FAR * This,
            LPOLESTR pStrSchema);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddVarDesc )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            VARDESC __RPC_FAR *pVarDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncAndParamNames )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            LPOLESTR __RPC_FAR *rgszNames,
            UINT cNames);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarName )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            LPOLESTR szName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTypeDescAlias )( 
            ICreateTypeInfo __RPC_FAR * This,
            TYPEDESC __RPC_FAR *pTDescAlias);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DefineFuncAsDllEntry )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            LPOLESTR szDllName,
            LPOLESTR szProcName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncDocString )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            LPOLESTR szDocString);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarDocString )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            LPOLESTR szDocString);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncHelpContext )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            DWORD dwHelpContext);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarHelpContext )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            DWORD dwHelpContext);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetMops )( 
            ICreateTypeInfo __RPC_FAR * This,
            UINT index,
            BSTR bstrMops);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTypeIdldesc )( 
            ICreateTypeInfo __RPC_FAR * This,
            IDLDESC __RPC_FAR *pIdlDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LayOut )( 
            ICreateTypeInfo __RPC_FAR * This);
        
	END_INTERFACE
    } ICreateTypeInfoVtbl;

    interface ICreateTypeInfo
    {
        CONST_VTBL struct ICreateTypeInfoVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ICreateTypeInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICreateTypeInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICreateTypeInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ICreateTypeInfo_SetGuid(This,guid)	\
    (This)->lpVtbl -> SetGuid(This,guid)

#define ICreateTypeInfo_SetTypeFlags(This,uTypeFlags)	\
    (This)->lpVtbl -> SetTypeFlags(This,uTypeFlags)

#define ICreateTypeInfo_SetDocString(This,pStrDoc)	\
    (This)->lpVtbl -> SetDocString(This,pStrDoc)

#define ICreateTypeInfo_SetHelpContext(This,dwHelpContext)	\
    (This)->lpVtbl -> SetHelpContext(This,dwHelpContext)

#define ICreateTypeInfo_SetVersion(This,wMajorVerNum,wMinorVerNum)	\
    (This)->lpVtbl -> SetVersion(This,wMajorVerNum,wMinorVerNum)

#define ICreateTypeInfo_AddRefTypeInfo(This,pTInfo,phRefType)	\
    (This)->lpVtbl -> AddRefTypeInfo(This,pTInfo,phRefType)

#define ICreateTypeInfo_AddFuncDesc(This,index,pFuncDesc)	\
    (This)->lpVtbl -> AddFuncDesc(This,index,pFuncDesc)

#define ICreateTypeInfo_AddImplType(This,index,hRefType)	\
    (This)->lpVtbl -> AddImplType(This,index,hRefType)

#define ICreateTypeInfo_SetImplTypeFlags(This,index,implTypeFlags)	\
    (This)->lpVtbl -> SetImplTypeFlags(This,index,implTypeFlags)

#define ICreateTypeInfo_SetAlignment(This,cbAlignment)	\
    (This)->lpVtbl -> SetAlignment(This,cbAlignment)

#define ICreateTypeInfo_SetSchema(This,pStrSchema)	\
    (This)->lpVtbl -> SetSchema(This,pStrSchema)

#define ICreateTypeInfo_AddVarDesc(This,index,pVarDesc)	\
    (This)->lpVtbl -> AddVarDesc(This,index,pVarDesc)

#define ICreateTypeInfo_SetFuncAndParamNames(This,index,rgszNames,cNames)	\
    (This)->lpVtbl -> SetFuncAndParamNames(This,index,rgszNames,cNames)

#define ICreateTypeInfo_SetVarName(This,index,szName)	\
    (This)->lpVtbl -> SetVarName(This,index,szName)

#define ICreateTypeInfo_SetTypeDescAlias(This,pTDescAlias)	\
    (This)->lpVtbl -> SetTypeDescAlias(This,pTDescAlias)

#define ICreateTypeInfo_DefineFuncAsDllEntry(This,index,szDllName,szProcName)	\
    (This)->lpVtbl -> DefineFuncAsDllEntry(This,index,szDllName,szProcName)

#define ICreateTypeInfo_SetFuncDocString(This,index,szDocString)	\
    (This)->lpVtbl -> SetFuncDocString(This,index,szDocString)

#define ICreateTypeInfo_SetVarDocString(This,index,szDocString)	\
    (This)->lpVtbl -> SetVarDocString(This,index,szDocString)

#define ICreateTypeInfo_SetFuncHelpContext(This,index,dwHelpContext)	\
    (This)->lpVtbl -> SetFuncHelpContext(This,index,dwHelpContext)

#define ICreateTypeInfo_SetVarHelpContext(This,index,dwHelpContext)	\
    (This)->lpVtbl -> SetVarHelpContext(This,index,dwHelpContext)

#define ICreateTypeInfo_SetMops(This,index,bstrMops)	\
    (This)->lpVtbl -> SetMops(This,index,bstrMops)

#define ICreateTypeInfo_SetTypeIdldesc(This,pIdlDesc)	\
    (This)->lpVtbl -> SetTypeIdldesc(This,pIdlDesc)

#define ICreateTypeInfo_LayOut(This)	\
    (This)->lpVtbl -> LayOut(This)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetGuid_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    REFGUID guid);

void __RPC_STUB ICreateTypeInfo_SetGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetTypeFlags_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT uTypeFlags);

void __RPC_STUB ICreateTypeInfo_SetTypeFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetDocString_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    LPOLESTR pStrDoc);

void __RPC_STUB ICreateTypeInfo_SetDocString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetHelpContext_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    DWORD dwHelpContext);

void __RPC_STUB ICreateTypeInfo_SetHelpContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetVersion_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    WORD wMajorVerNum,
    WORD wMinorVerNum);

void __RPC_STUB ICreateTypeInfo_SetVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_AddRefTypeInfo_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    ITypeInfo __RPC_FAR *pTInfo,
    HREFTYPE __RPC_FAR *phRefType);

void __RPC_STUB ICreateTypeInfo_AddRefTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_AddFuncDesc_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    FUNCDESC __RPC_FAR *pFuncDesc);

void __RPC_STUB ICreateTypeInfo_AddFuncDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_AddImplType_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    HREFTYPE hRefType);

void __RPC_STUB ICreateTypeInfo_AddImplType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetImplTypeFlags_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    INT implTypeFlags);

void __RPC_STUB ICreateTypeInfo_SetImplTypeFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetAlignment_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    WORD cbAlignment);

void __RPC_STUB ICreateTypeInfo_SetAlignment_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetSchema_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    LPOLESTR pStrSchema);

void __RPC_STUB ICreateTypeInfo_SetSchema_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_AddVarDesc_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    VARDESC __RPC_FAR *pVarDesc);

void __RPC_STUB ICreateTypeInfo_AddVarDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetFuncAndParamNames_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    LPOLESTR __RPC_FAR *rgszNames,
    UINT cNames);

void __RPC_STUB ICreateTypeInfo_SetFuncAndParamNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetVarName_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    LPOLESTR szName);

void __RPC_STUB ICreateTypeInfo_SetVarName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetTypeDescAlias_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    TYPEDESC __RPC_FAR *pTDescAlias);

void __RPC_STUB ICreateTypeInfo_SetTypeDescAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_DefineFuncAsDllEntry_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    LPOLESTR szDllName,
    LPOLESTR szProcName);

void __RPC_STUB ICreateTypeInfo_DefineFuncAsDllEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetFuncDocString_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    LPOLESTR szDocString);

void __RPC_STUB ICreateTypeInfo_SetFuncDocString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetVarDocString_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    LPOLESTR szDocString);

void __RPC_STUB ICreateTypeInfo_SetVarDocString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetFuncHelpContext_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    DWORD dwHelpContext);

void __RPC_STUB ICreateTypeInfo_SetFuncHelpContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetVarHelpContext_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    DWORD dwHelpContext);

void __RPC_STUB ICreateTypeInfo_SetVarHelpContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetMops_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    UINT index,
    BSTR bstrMops);

void __RPC_STUB ICreateTypeInfo_SetMops_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_SetTypeIdldesc_Proxy( 
    ICreateTypeInfo __RPC_FAR * This,
    IDLDESC __RPC_FAR *pIdlDesc);

void __RPC_STUB ICreateTypeInfo_SetTypeIdldesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo_LayOut_Proxy( 
    ICreateTypeInfo __RPC_FAR * This);

void __RPC_STUB ICreateTypeInfo_LayOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ICreateTypeInfo_INTERFACE_DEFINED__ */

#ifndef __ICreateTypeInfo2_INTERFACE_DEFINED__
#define __ICreateTypeInfo2_INTERFACE_DEFINED__

typedef ICreateTypeInfo2 __RPC_FAR *LPCREATETYPEINFO2;

EXTERN_C const IID IID_ICreateTypeInfo2;

typedef struct ICreateTypeInfo2Vtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICreateTypeInfo2 __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICreateTypeInfo2 __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetGuid )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            REFGUID guid);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTypeFlags )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT uTypeFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDocString )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            LPOLESTR pStrDoc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpContext )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            DWORD dwHelpContext);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVersion )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            WORD wMajorVerNum,
            WORD wMinorVerNum);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddRefTypeInfo )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            ITypeInfo __RPC_FAR *pTInfo,
            HREFTYPE __RPC_FAR *phRefType);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddFuncDesc )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            FUNCDESC __RPC_FAR *pFuncDesc);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddImplType )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            HREFTYPE hRefType);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetImplTypeFlags )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            INT implTypeFlags);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetAlignment )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            WORD cbAlignment);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSchema )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            LPOLESTR pStrSchema);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddVarDesc )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            VARDESC __RPC_FAR *pVarDesc);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncAndParamNames )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            LPOLESTR __RPC_FAR *rgszNames,
            UINT cNames);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarName )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            LPOLESTR szName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTypeDescAlias )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            TYPEDESC __RPC_FAR *pTDescAlias);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DefineFuncAsDllEntry )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            LPOLESTR szDllName,
            LPOLESTR szProcName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncDocString )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            LPOLESTR szDocString);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarDocString )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            LPOLESTR szDocString);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncHelpContext )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            DWORD dwHelpContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarHelpContext )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            DWORD dwHelpContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetMops )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            BSTR bstrMops);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTypeIdldesc )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            IDLDESC __RPC_FAR *pIdlDesc);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *LayOut )( 
            ICreateTypeInfo2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteFuncDesc )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteFuncDescByMemId )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            INVOKEKIND invKind);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteVarDesc )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteVarDescByMemId )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            MEMBERID memid);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteImplType )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCustData )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncCustData )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetParamCustData )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT indexFunc,
            UINT indexParam,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarCustData )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetImplTypeCustData )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpStringContext )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            ULONG dwHelpStringContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetFuncHelpStringContext )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            ULONG dwHelpStringContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVarHelpStringContext )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            UINT index,
            ULONG dwHelpStringContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invalidate )( 
            ICreateTypeInfo2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetName )( 
            ICreateTypeInfo2 __RPC_FAR * This,
            LPOLESTR szName);
        
        END_INTERFACE
    } ICreateTypeInfo2Vtbl;

    interface ICreateTypeInfo2
    {
        CONST_VTBL struct ICreateTypeInfo2Vtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ICreateTypeInfo2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICreateTypeInfo2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICreateTypeInfo2_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ICreateTypeInfo2_SetGuid(This,guid)	\
    (This)->lpVtbl -> SetGuid(This,guid)

#define ICreateTypeInfo2_SetTypeFlags(This,uTypeFlags)	\
    (This)->lpVtbl -> SetTypeFlags(This,uTypeFlags)

#define ICreateTypeInfo2_SetDocString(This,pStrDoc)	\
    (This)->lpVtbl -> SetDocString(This,pStrDoc)

#define ICreateTypeInfo2_SetHelpContext(This,dwHelpContext)	\
    (This)->lpVtbl -> SetHelpContext(This,dwHelpContext)

#define ICreateTypeInfo2_SetVersion(This,wMajorVerNum,wMinorVerNum)	\
    (This)->lpVtbl -> SetVersion(This,wMajorVerNum,wMinorVerNum)

#define ICreateTypeInfo2_AddRefTypeInfo(This,pTInfo,phRefType)	\
    (This)->lpVtbl -> AddRefTypeInfo(This,pTInfo,phRefType)

#define ICreateTypeInfo2_AddFuncDesc(This,index,pFuncDesc)	\
    (This)->lpVtbl -> AddFuncDesc(This,index,pFuncDesc)

#define ICreateTypeInfo2_AddImplType(This,index,hRefType)	\
    (This)->lpVtbl -> AddImplType(This,index,hRefType)

#define ICreateTypeInfo2_SetImplTypeFlags(This,index,implTypeFlags)	\
    (This)->lpVtbl -> SetImplTypeFlags(This,index,implTypeFlags)

#define ICreateTypeInfo2_SetAlignment(This,cbAlignment)	\
    (This)->lpVtbl -> SetAlignment(This,cbAlignment)

#define ICreateTypeInfo2_SetSchema(This,pStrSchema)	\
    (This)->lpVtbl -> SetSchema(This,pStrSchema)

#define ICreateTypeInfo2_AddVarDesc(This,index,pVarDesc)	\
    (This)->lpVtbl -> AddVarDesc(This,index,pVarDesc)

#define ICreateTypeInfo2_SetFuncAndParamNames(This,index,rgszNames,cNames)	\
    (This)->lpVtbl -> SetFuncAndParamNames(This,index,rgszNames,cNames)

#define ICreateTypeInfo2_SetVarName(This,index,szName)	\
    (This)->lpVtbl -> SetVarName(This,index,szName)

#define ICreateTypeInfo2_SetTypeDescAlias(This,pTDescAlias)	\
    (This)->lpVtbl -> SetTypeDescAlias(This,pTDescAlias)

#define ICreateTypeInfo2_DefineFuncAsDllEntry(This,index,szDllName,szProcName)	\
    (This)->lpVtbl -> DefineFuncAsDllEntry(This,index,szDllName,szProcName)

#define ICreateTypeInfo2_SetFuncDocString(This,index,szDocString)	\
    (This)->lpVtbl -> SetFuncDocString(This,index,szDocString)

#define ICreateTypeInfo2_SetVarDocString(This,index,szDocString)	\
    (This)->lpVtbl -> SetVarDocString(This,index,szDocString)

#define ICreateTypeInfo2_SetFuncHelpContext(This,index,dwHelpContext)	\
    (This)->lpVtbl -> SetFuncHelpContext(This,index,dwHelpContext)

#define ICreateTypeInfo2_SetVarHelpContext(This,index,dwHelpContext)	\
    (This)->lpVtbl -> SetVarHelpContext(This,index,dwHelpContext)

#define ICreateTypeInfo2_SetMops(This,index,bstrMops)	\
    (This)->lpVtbl -> SetMops(This,index,bstrMops)

#define ICreateTypeInfo2_SetTypeIdldesc(This,pIdlDesc)	\
    (This)->lpVtbl -> SetTypeIdldesc(This,pIdlDesc)

#define ICreateTypeInfo2_LayOut(This)	\
    (This)->lpVtbl -> LayOut(This)

#define ICreateTypeInfo2_DeleteFuncDesc(This,index)	\
    (This)->lpVtbl -> DeleteFuncDesc(This,index)

#define ICreateTypeInfo2_DeleteFuncDescByMemId(This,memid,invKind)	\
    (This)->lpVtbl -> DeleteFuncDescByMemId(This,memid,invKind)

#define ICreateTypeInfo2_DeleteVarDesc(This,index)	\
    (This)->lpVtbl -> DeleteVarDesc(This,index)

#define ICreateTypeInfo2_DeleteVarDescByMemId(This,memid)	\
    (This)->lpVtbl -> DeleteVarDescByMemId(This,memid)

#define ICreateTypeInfo2_DeleteImplType(This,index)	\
    (This)->lpVtbl -> DeleteImplType(This,index)

#define ICreateTypeInfo2_SetCustData(This,guid,pVarVal)	\
    (This)->lpVtbl -> SetCustData(This,guid,pVarVal)

#define ICreateTypeInfo2_SetFuncCustData(This,index,guid,pVarVal)	\
    (This)->lpVtbl -> SetFuncCustData(This,index,guid,pVarVal)

#define ICreateTypeInfo2_SetParamCustData(This,indexFunc,indexParam,guid,pVarVal)	\
    (This)->lpVtbl -> SetParamCustData(This,indexFunc,indexParam,guid,pVarVal)

#define ICreateTypeInfo2_SetVarCustData(This,index,guid,pVarVal)	\
    (This)->lpVtbl -> SetVarCustData(This,index,guid,pVarVal)

#define ICreateTypeInfo2_SetImplTypeCustData(This,index,guid,pVarVal)	\
    (This)->lpVtbl -> SetImplTypeCustData(This,index,guid,pVarVal)

#define ICreateTypeInfo2_SetHelpStringContext(This,dwHelpStringContext)	\
    (This)->lpVtbl -> SetHelpStringContext(This,dwHelpStringContext)

#define ICreateTypeInfo2_SetFuncHelpStringContext(This,index,dwHelpStringContext)	\
    (This)->lpVtbl -> SetFuncHelpStringContext(This,index,dwHelpStringContext)

#define ICreateTypeInfo2_SetVarHelpStringContext(This,index,dwHelpStringContext)	\
    (This)->lpVtbl -> SetVarHelpStringContext(This,index,dwHelpStringContext)

#define ICreateTypeInfo2_Invalidate(This)	\
    (This)->lpVtbl -> Invalidate(This)

#define ICreateTypeInfo2_SetName(This,szName)	\
    (This)->lpVtbl -> SetName(This,szName)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_DeleteFuncDesc_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index);

void __RPC_STUB ICreateTypeInfo2_DeleteFuncDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_DeleteFuncDescByMemId_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    MEMBERID memid,
    INVOKEKIND invKind);

void __RPC_STUB ICreateTypeInfo2_DeleteFuncDescByMemId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_DeleteVarDesc_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index);

void __RPC_STUB ICreateTypeInfo2_DeleteVarDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_DeleteVarDescByMemId_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    MEMBERID memid);

void __RPC_STUB ICreateTypeInfo2_DeleteVarDescByMemId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_DeleteImplType_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index);

void __RPC_STUB ICreateTypeInfo2_DeleteImplType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetCustData_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ICreateTypeInfo2_SetCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetFuncCustData_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ICreateTypeInfo2_SetFuncCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetParamCustData_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT indexFunc,
    UINT indexParam,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ICreateTypeInfo2_SetParamCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetVarCustData_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ICreateTypeInfo2_SetVarCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetImplTypeCustData_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ICreateTypeInfo2_SetImplTypeCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetHelpStringContext_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    ULONG dwHelpStringContext);

void __RPC_STUB ICreateTypeInfo2_SetHelpStringContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetFuncHelpStringContext_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index,
    ULONG dwHelpStringContext);

void __RPC_STUB ICreateTypeInfo2_SetFuncHelpStringContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetVarHelpStringContext_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    UINT index,
    ULONG dwHelpStringContext);

void __RPC_STUB ICreateTypeInfo2_SetVarHelpStringContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_Invalidate_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This);

void __RPC_STUB ICreateTypeInfo2_Invalidate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeInfo2_SetName_Proxy( 
    ICreateTypeInfo2 __RPC_FAR * This,
    LPOLESTR szName);

void __RPC_STUB ICreateTypeInfo2_SetName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ICreateTypeInfo2_INTERFACE_DEFINED__ */

#ifndef __ICreateTypeLib_INTERFACE_DEFINED__
#define __ICreateTypeLib_INTERFACE_DEFINED__

typedef ICreateTypeLib __RPC_FAR *LPCREATETYPELIB;

EXTERN_C const IID IID_ICreateTypeLib;

    typedef struct ICreateTypeLibVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICreateTypeLib __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICreateTypeLib __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICreateTypeLib __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateTypeInfo )( 
            ICreateTypeLib __RPC_FAR * This,
            LPOLESTR szName,
            TYPEKIND tkind,
            ICreateTypeInfo __RPC_FAR *__RPC_FAR *ppCTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetName )( 
            ICreateTypeLib __RPC_FAR * This,
            LPOLESTR szName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVersion )( 
            ICreateTypeLib __RPC_FAR * This,
            WORD wMajorVerNum,
            WORD wMinorVerNum);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetGuid )( 
            ICreateTypeLib __RPC_FAR * This,
            REFGUID guid);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDocString )( 
            ICreateTypeLib __RPC_FAR * This,
            LPOLESTR szDoc);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpFileName )( 
            ICreateTypeLib __RPC_FAR * This,
            LPOLESTR szHelpFileName);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpContext )( 
            ICreateTypeLib __RPC_FAR * This,
            DWORD dwHelpContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetLcid )( 
            ICreateTypeLib __RPC_FAR * This,
            LCID lcid);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetLibFlags )( 
            ICreateTypeLib __RPC_FAR * This,
            UINT uLibFlags);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveAllChanges )( 
            ICreateTypeLib __RPC_FAR * This);
        
        END_INTERFACE
    } ICreateTypeLibVtbl;

    interface ICreateTypeLib
    {
        CONST_VTBL struct ICreateTypeLibVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ICreateTypeLib_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICreateTypeLib_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICreateTypeLib_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ICreateTypeLib_CreateTypeInfo(This,szName,tkind,ppCTInfo)	\
    (This)->lpVtbl -> CreateTypeInfo(This,szName,tkind,ppCTInfo)

#define ICreateTypeLib_SetName(This,szName)	\
    (This)->lpVtbl -> SetName(This,szName)

#define ICreateTypeLib_SetVersion(This,wMajorVerNum,wMinorVerNum)	\
    (This)->lpVtbl -> SetVersion(This,wMajorVerNum,wMinorVerNum)

#define ICreateTypeLib_SetGuid(This,guid)	\
    (This)->lpVtbl -> SetGuid(This,guid)

#define ICreateTypeLib_SetDocString(This,szDoc)	\
    (This)->lpVtbl -> SetDocString(This,szDoc)

#define ICreateTypeLib_SetHelpFileName(This,szHelpFileName)	\
    (This)->lpVtbl -> SetHelpFileName(This,szHelpFileName)

#define ICreateTypeLib_SetHelpContext(This,dwHelpContext)	\
    (This)->lpVtbl -> SetHelpContext(This,dwHelpContext)

#define ICreateTypeLib_SetLcid(This,lcid)	\
    (This)->lpVtbl -> SetLcid(This,lcid)

#define ICreateTypeLib_SetLibFlags(This,uLibFlags)	\
    (This)->lpVtbl -> SetLibFlags(This,uLibFlags)

#define ICreateTypeLib_SaveAllChanges(This)	\
    (This)->lpVtbl -> SaveAllChanges(This)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ICreateTypeLib_CreateTypeInfo_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    LPOLESTR szName,
    TYPEKIND tkind,
    ICreateTypeInfo __RPC_FAR *__RPC_FAR *ppCTInfo);

void __RPC_STUB ICreateTypeLib_CreateTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetName_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    LPOLESTR szName);

void __RPC_STUB ICreateTypeLib_SetName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetVersion_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    WORD wMajorVerNum,
    WORD wMinorVerNum);

void __RPC_STUB ICreateTypeLib_SetVersion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetGuid_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    REFGUID guid);

void __RPC_STUB ICreateTypeLib_SetGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetDocString_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    LPOLESTR szDoc);

void __RPC_STUB ICreateTypeLib_SetDocString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetHelpFileName_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    LPOLESTR szHelpFileName);

void __RPC_STUB ICreateTypeLib_SetHelpFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetHelpContext_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    DWORD dwHelpContext);

void __RPC_STUB ICreateTypeLib_SetHelpContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetLcid_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    LCID lcid);

void __RPC_STUB ICreateTypeLib_SetLcid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SetLibFlags_Proxy( 
    ICreateTypeLib __RPC_FAR * This,
    UINT uLibFlags);

void __RPC_STUB ICreateTypeLib_SetLibFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib_SaveAllChanges_Proxy( 
    ICreateTypeLib __RPC_FAR * This);

void __RPC_STUB ICreateTypeLib_SaveAllChanges_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ICreateTypeLib_INTERFACE_DEFINED__ */

#ifndef __ICreateTypeLib2_INTERFACE_DEFINED__
#define __ICreateTypeLib2_INTERFACE_DEFINED__

typedef ICreateTypeLib2 __RPC_FAR *LPCREATETYPELIB2;

EXTERN_C const IID IID_ICreateTypeLib2;

typedef struct ICreateTypeLib2Vtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICreateTypeLib2 __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICreateTypeLib2 __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICreateTypeLib2 __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateTypeInfo )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LPOLESTR szName,
            TYPEKIND tkind,
            ICreateTypeInfo __RPC_FAR *__RPC_FAR *ppCTInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetName )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LPOLESTR szName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetVersion )( 
            ICreateTypeLib2 __RPC_FAR * This,
            WORD wMajorVerNum,
            WORD wMinorVerNum);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetGuid )( 
            ICreateTypeLib2 __RPC_FAR * This,
            REFGUID guid);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDocString )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LPOLESTR szDoc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpFileName )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LPOLESTR szHelpFileName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpContext )( 
            ICreateTypeLib2 __RPC_FAR * This,
            DWORD dwHelpContext);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetLcid )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LCID lcid);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetLibFlags )( 
            ICreateTypeLib2 __RPC_FAR * This,
            UINT uLibFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SaveAllChanges )( 
            ICreateTypeLib2 __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteTypeInfo )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LPOLESTR szName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCustData )( 
            ICreateTypeLib2 __RPC_FAR * This,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpStringContext )( 
            ICreateTypeLib2 __RPC_FAR * This,
            ULONG dwHelpStringContext);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpStringDll )( 
            ICreateTypeLib2 __RPC_FAR * This,
            LPOLESTR szFileName);
        
        END_INTERFACE
    } ICreateTypeLib2Vtbl;

    interface ICreateTypeLib2
    {
        CONST_VTBL struct ICreateTypeLib2Vtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ICreateTypeLib2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICreateTypeLib2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICreateTypeLib2_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ICreateTypeLib2_CreateTypeInfo(This,szName,tkind,ppCTInfo)	\
    (This)->lpVtbl -> CreateTypeInfo(This,szName,tkind,ppCTInfo)

#define ICreateTypeLib2_SetName(This,szName)	\
    (This)->lpVtbl -> SetName(This,szName)

#define ICreateTypeLib2_SetVersion(This,wMajorVerNum,wMinorVerNum)	\
    (This)->lpVtbl -> SetVersion(This,wMajorVerNum,wMinorVerNum)

#define ICreateTypeLib2_SetGuid(This,guid)	\
    (This)->lpVtbl -> SetGuid(This,guid)

#define ICreateTypeLib2_SetDocString(This,szDoc)	\
    (This)->lpVtbl -> SetDocString(This,szDoc)

#define ICreateTypeLib2_SetHelpFileName(This,szHelpFileName)	\
    (This)->lpVtbl -> SetHelpFileName(This,szHelpFileName)

#define ICreateTypeLib2_SetHelpContext(This,dwHelpContext)	\
    (This)->lpVtbl -> SetHelpContext(This,dwHelpContext)

#define ICreateTypeLib2_SetLcid(This,lcid)	\
    (This)->lpVtbl -> SetLcid(This,lcid)

#define ICreateTypeLib2_SetLibFlags(This,uLibFlags)	\
    (This)->lpVtbl -> SetLibFlags(This,uLibFlags)

#define ICreateTypeLib2_SaveAllChanges(This)	\
    (This)->lpVtbl -> SaveAllChanges(This)

#define ICreateTypeLib2_DeleteTypeInfo(This,szName)	\
    (This)->lpVtbl -> DeleteTypeInfo(This,szName)

#define ICreateTypeLib2_SetCustData(This,guid,pVarVal)	\
    (This)->lpVtbl -> SetCustData(This,guid,pVarVal)

#define ICreateTypeLib2_SetHelpStringContext(This,dwHelpStringContext)	\
    (This)->lpVtbl -> SetHelpStringContext(This,dwHelpStringContext)

#define ICreateTypeLib2_SetHelpStringDll(This,szFileName)	\
    (This)->lpVtbl -> SetHelpStringDll(This,szFileName)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ICreateTypeLib2_DeleteTypeInfo_Proxy( 
    ICreateTypeLib2 __RPC_FAR * This,
    LPOLESTR szName);

void __RPC_STUB ICreateTypeLib2_DeleteTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib2_SetCustData_Proxy( 
    ICreateTypeLib2 __RPC_FAR * This,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ICreateTypeLib2_SetCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib2_SetHelpStringContext_Proxy( 
    ICreateTypeLib2 __RPC_FAR * This,
    ULONG dwHelpStringContext);

void __RPC_STUB ICreateTypeLib2_SetHelpStringContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateTypeLib2_SetHelpStringDll_Proxy( 
    ICreateTypeLib2 __RPC_FAR * This,
    LPOLESTR szFileName);

void __RPC_STUB ICreateTypeLib2_SetHelpStringDll_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ICreateTypeLib2_INTERFACE_DEFINED__ */

#ifndef __IDispatch_INTERFACE_DEFINED__
#define __IDispatch_INTERFACE_DEFINED__
typedef IDispatch __RPC_FAR *LPDISPATCH;

#define	DISPID_UNKNOWN	( -1 )
#define	DISPID_VALUE	( 0 )
#define	DISPID_PROPERTYPUT	( -3 )
#define	DISPID_NEWENUM	( -4 )
#define	DISPID_EVALUATE	( -5 )
#define	DISPID_CONSTRUCTOR	( -6 )
#define	DISPID_DESTRUCTOR	( -7 )
#define	DISPID_COLLECT	( -8 )

EXTERN_C const IID IID_IDispatch;

typedef struct IDispatchVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDispatch __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDispatch __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDispatch __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDispatch __RPC_FAR * This,
            UINT __RPC_FAR *pctinfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDispatch __RPC_FAR * This,
            UINT iTInfo,
            LCID lcid,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDispatch __RPC_FAR * This,
            REFIID riid,
            LPOLESTR __RPC_FAR *rgszNames,
            UINT cNames,
            LCID lcid,
            DISPID __RPC_FAR *rgDispId);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDispatch __RPC_FAR * This,
            DISPID dispIdMember,
            REFIID riid,
            LCID lcid,
            WORD wFlags,
            DISPPARAMS __RPC_FAR *pDispParams,
            VARIANT __RPC_FAR *pVarResult,
            EXCEPINFO __RPC_FAR *pExcepInfo,
            UINT __RPC_FAR *puArgErr);
        
	END_INTERFACE
    } IDispatchVtbl;

    interface IDispatch
    {
        CONST_VTBL struct IDispatchVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IDispatch_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDispatch_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDispatch_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IDispatch_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDispatch_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDispatch_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDispatch_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IDispatch_GetTypeInfoCount_Proxy( 
    IDispatch __RPC_FAR * This,
    UINT __RPC_FAR *pctinfo);

void __RPC_STUB IDispatch_GetTypeInfoCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IDispatch_GetTypeInfo_Proxy( 
    IDispatch __RPC_FAR * This,
    UINT iTInfo,
    LCID lcid,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

void __RPC_STUB IDispatch_GetTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IDispatch_GetIDsOfNames_Proxy( 
    IDispatch __RPC_FAR * This,
    REFIID riid,
    LPOLESTR __RPC_FAR *rgszNames,
    UINT cNames,
    LCID lcid,
    DISPID __RPC_FAR *rgDispId);

void __RPC_STUB IDispatch_GetIDsOfNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IDispatch_RemoteInvoke_Proxy( 
    IDispatch __RPC_FAR * This,
    DISPID dispIdMember,
    REFIID riid,
    LCID lcid,
    DWORD dwFlags,
    DISPPARAMS __RPC_FAR *pDispParams,
    VARIANT __RPC_FAR *pVarResult,
    EXCEPINFO __RPC_FAR *pExcepInfo,
    UINT __RPC_FAR *pArgErr,
    UINT cVarRef,
    UINT __RPC_FAR *rgVarRefIdx,
    VARIANTARG __RPC_FAR *rgVarRef);

void __RPC_STUB IDispatch_RemoteInvoke_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IDispatch_INTERFACE_DEFINED__ */

#ifndef __IEnumVARIANT_INTERFACE_DEFINED__
#define __IEnumVARIANT_INTERFACE_DEFINED__

typedef IEnumVARIANT __RPC_FAR *LPENUMVARIANT;

EXTERN_C const IID IID_IEnumVARIANT;

typedef struct IEnumVARIANTVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IEnumVARIANT __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IEnumVARIANT __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IEnumVARIANT __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Next )( 
            IEnumVARIANT __RPC_FAR * This,
            ULONG celt,
            VARIANT __RPC_FAR *rgVar,
            ULONG __RPC_FAR *pCeltFetched);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Skip )( 
            IEnumVARIANT __RPC_FAR * This,
            ULONG celt);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Reset )( 
            IEnumVARIANT __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clone )( 
            IEnumVARIANT __RPC_FAR * This,
            IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum);
        
	END_INTERFACE
    } IEnumVARIANTVtbl;

    interface IEnumVARIANT
    {
        CONST_VTBL struct IEnumVARIANTVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IEnumVARIANT_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEnumVARIANT_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEnumVARIANT_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IEnumVARIANT_Next(This,celt,rgVar,pCeltFetched)	\
    (This)->lpVtbl -> Next(This,celt,rgVar,pCeltFetched)

#define IEnumVARIANT_Skip(This,celt)	\
    (This)->lpVtbl -> Skip(This,celt)

#define IEnumVARIANT_Reset(This)	\
    (This)->lpVtbl -> Reset(This)

#define IEnumVARIANT_Clone(This,ppEnum)	\
    (This)->lpVtbl -> Clone(This,ppEnum)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IEnumVARIANT_RemoteNext_Proxy( 
    IEnumVARIANT __RPC_FAR * This,
    ULONG celt,
    VARIANT __RPC_FAR *rgVar,
    ULONG __RPC_FAR *pCeltFetched);

void __RPC_STUB IEnumVARIANT_RemoteNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumVARIANT_Skip_Proxy( 
    IEnumVARIANT __RPC_FAR * This,
    ULONG celt);

void __RPC_STUB IEnumVARIANT_Skip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumVARIANT_Reset_Proxy( 
    IEnumVARIANT __RPC_FAR * This);

void __RPC_STUB IEnumVARIANT_Reset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumVARIANT_Clone_Proxy( 
    IEnumVARIANT __RPC_FAR * This,
    IEnumVARIANT __RPC_FAR *__RPC_FAR *ppEnum);

void __RPC_STUB IEnumVARIANT_Clone_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IEnumVARIANT_INTERFACE_DEFINED__ */

#ifndef __ITypeComp_INTERFACE_DEFINED__
#define __ITypeComp_INTERFACE_DEFINED__

typedef ITypeComp __RPC_FAR *LPTYPECOMP;

typedef 
enum tagDESCKIND
{	DESCKIND_NONE	= 0,
	DESCKIND_FUNCDESC	= DESCKIND_NONE + 1,
	DESCKIND_VARDESC	= DESCKIND_FUNCDESC + 1,
	DESCKIND_TYPECOMP	= DESCKIND_VARDESC + 1,
	DESCKIND_IMPLICITAPPOBJ	= DESCKIND_TYPECOMP + 1,
	DESCKIND_MAX	= DESCKIND_IMPLICITAPPOBJ + 1
}	DESCKIND;

typedef union tagBINDPTR
{
    FUNCDESC __RPC_FAR *lpfuncdesc;
    VARDESC __RPC_FAR *lpvardesc;
    ITypeComp __RPC_FAR *lptcomp;
}	BINDPTR;

typedef union tagBINDPTR __RPC_FAR *LPBINDPTR;

EXTERN_C const IID IID_ITypeComp;

typedef struct ITypeCompVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeComp __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeComp __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeComp __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Bind )( 
            ITypeComp __RPC_FAR * This,
            LPOLESTR szName,
            ULONG lHashVal,
            WORD wFlags,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
            DESCKIND __RPC_FAR *pDescKind,
            BINDPTR __RPC_FAR *pBindPtr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *BindType )( 
            ITypeComp __RPC_FAR * This,
            LPOLESTR szName,
            ULONG lHashVal,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
            ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);
        
	END_INTERFACE
    } ITypeCompVtbl;

    interface ITypeComp
    {
        CONST_VTBL struct ITypeCompVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ITypeComp_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeComp_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeComp_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeComp_Bind(This,szName,lHashVal,wFlags,ppTInfo,pDescKind,pBindPtr)	\
    (This)->lpVtbl -> Bind(This,szName,lHashVal,wFlags,ppTInfo,pDescKind,pBindPtr)

#define ITypeComp_BindType(This,szName,lHashVal,ppTInfo,ppTComp)	\
    (This)->lpVtbl -> BindType(This,szName,lHashVal,ppTInfo,ppTComp)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeComp_RemoteBind_Proxy( 
    ITypeComp __RPC_FAR * This,
    LPOLESTR szName,
    ULONG lHashVal,
    WORD wFlags,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    DESCKIND __RPC_FAR *pDescKind,
    LPFUNCDESC __RPC_FAR *ppFuncDesc,
    LPVARDESC __RPC_FAR *ppVarDesc,
    ITypeComp __RPC_FAR *__RPC_FAR *ppTypeComp,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

void __RPC_STUB ITypeComp_RemoteBind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeComp_RemoteBindType_Proxy( 
    ITypeComp __RPC_FAR * This,
    LPOLESTR szName,
    ULONG lHashVal,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

void __RPC_STUB ITypeComp_RemoteBindType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeComp_INTERFACE_DEFINED__ */

#ifndef __ITypeInfo_INTERFACE_DEFINED__
#define __ITypeInfo_INTERFACE_DEFINED__

typedef ITypeInfo __RPC_FAR *LPTYPEINFO;

EXTERN_C const IID IID_ITypeInfo;

typedef struct ITypeInfoVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeInfo __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeInfo __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeAttr )( 
            ITypeInfo __RPC_FAR * This,
            TYPEATTR __RPC_FAR *__RPC_FAR *ppTypeAttr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeComp )( 
            ITypeInfo __RPC_FAR * This,
            ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFuncDesc )( 
            ITypeInfo __RPC_FAR * This,
            UINT index,
            FUNCDESC __RPC_FAR *__RPC_FAR *ppFuncDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetVarDesc )( 
            ITypeInfo __RPC_FAR * This,
            UINT index,
            VARDESC __RPC_FAR *__RPC_FAR *ppVarDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNames )( 
            ITypeInfo __RPC_FAR * This,
            MEMBERID memid,
            BSTR __RPC_FAR *rgBstrNames,
            UINT cMaxNames,
            UINT __RPC_FAR *pcNames);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRefTypeOfImplType )( 
            ITypeInfo __RPC_FAR * This,
            UINT index,
            HREFTYPE __RPC_FAR *pRefType);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetImplTypeFlags )( 
            ITypeInfo __RPC_FAR * This,
            UINT index,
            INT __RPC_FAR *pImplTypeFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITypeInfo __RPC_FAR * This,
            LPOLESTR __RPC_FAR *rgszNames,
            UINT cNames,
            MEMBERID __RPC_FAR *pMemId);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITypeInfo __RPC_FAR * This,
            PVOID pvInstance,
            MEMBERID memid,
            WORD wFlags,
            DISPPARAMS __RPC_FAR *pDispParams,
            VARIANT __RPC_FAR *pVarResult,
            EXCEPINFO __RPC_FAR *pExcepInfo,
            UINT __RPC_FAR *puArgErr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDocumentation )( 
            ITypeInfo __RPC_FAR * This,
            MEMBERID memid,
            BSTR __RPC_FAR *pBstrName,
            BSTR __RPC_FAR *pBstrDocString,
            DWORD __RPC_FAR *pdwHelpContext,
            BSTR __RPC_FAR *pBstrHelpFile);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDllEntry )( 
            ITypeInfo __RPC_FAR * This,
            MEMBERID memid,
            INVOKEKIND invKind,
            BSTR __RPC_FAR *pBstrDllName,
            BSTR __RPC_FAR *pBstrName,
            WORD __RPC_FAR *pwOrdinal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRefTypeInfo )( 
            ITypeInfo __RPC_FAR * This,
            HREFTYPE hRefType,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddressOfMember )( 
            ITypeInfo __RPC_FAR * This,
            MEMBERID memid,
            INVOKEKIND invKind,
            PVOID __RPC_FAR *ppv);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateInstance )( 
            ITypeInfo __RPC_FAR * This,
            IUnknown __RPC_FAR *pUnkOuter,
            REFIID riid,
            PVOID __RPC_FAR *ppvObj);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMops )( 
            ITypeInfo __RPC_FAR * This,
            MEMBERID memid,
            BSTR __RPC_FAR *pBstrMops);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetContainingTypeLib )( 
            ITypeInfo __RPC_FAR * This,
            ITypeLib __RPC_FAR *__RPC_FAR *ppTLib,
            UINT __RPC_FAR *pIndex);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseTypeAttr )( 
            ITypeInfo __RPC_FAR * This,
            TYPEATTR __RPC_FAR *pTypeAttr);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseFuncDesc )( 
            ITypeInfo __RPC_FAR * This,
            FUNCDESC __RPC_FAR *pFuncDesc);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseVarDesc )( 
            ITypeInfo __RPC_FAR * This,
            VARDESC __RPC_FAR *pVarDesc);
        
	END_INTERFACE
    } ITypeInfoVtbl;

    interface ITypeInfo
    {
        CONST_VTBL struct ITypeInfoVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ITypeInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeInfo_GetTypeAttr(This,ppTypeAttr)	\
    (This)->lpVtbl -> GetTypeAttr(This,ppTypeAttr)

#define ITypeInfo_GetTypeComp(This,ppTComp)	\
    (This)->lpVtbl -> GetTypeComp(This,ppTComp)

#define ITypeInfo_GetFuncDesc(This,index,ppFuncDesc)	\
    (This)->lpVtbl -> GetFuncDesc(This,index,ppFuncDesc)

#define ITypeInfo_GetVarDesc(This,index,ppVarDesc)	\
    (This)->lpVtbl -> GetVarDesc(This,index,ppVarDesc)

#define ITypeInfo_GetNames(This,memid,rgBstrNames,cMaxNames,pcNames)	\
    (This)->lpVtbl -> GetNames(This,memid,rgBstrNames,cMaxNames,pcNames)

#define ITypeInfo_GetRefTypeOfImplType(This,index,pRefType)	\
    (This)->lpVtbl -> GetRefTypeOfImplType(This,index,pRefType)

#define ITypeInfo_GetImplTypeFlags(This,index,pImplTypeFlags)	\
    (This)->lpVtbl -> GetImplTypeFlags(This,index,pImplTypeFlags)

#define ITypeInfo_GetIDsOfNames(This,rgszNames,cNames,pMemId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,rgszNames,cNames,pMemId)

#define ITypeInfo_Invoke(This,pvInstance,memid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,pvInstance,memid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#define ITypeInfo_GetDocumentation(This,memid,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)	\
    (This)->lpVtbl -> GetDocumentation(This,memid,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)

#define ITypeInfo_GetDllEntry(This,memid,invKind,pBstrDllName,pBstrName,pwOrdinal)	\
    (This)->lpVtbl -> GetDllEntry(This,memid,invKind,pBstrDllName,pBstrName,pwOrdinal)

#define ITypeInfo_GetRefTypeInfo(This,hRefType,ppTInfo)	\
    (This)->lpVtbl -> GetRefTypeInfo(This,hRefType,ppTInfo)

#define ITypeInfo_AddressOfMember(This,memid,invKind,ppv)	\
    (This)->lpVtbl -> AddressOfMember(This,memid,invKind,ppv)

#define ITypeInfo_CreateInstance(This,pUnkOuter,riid,ppvObj)	\
    (This)->lpVtbl -> CreateInstance(This,pUnkOuter,riid,ppvObj)

#define ITypeInfo_GetMops(This,memid,pBstrMops)	\
    (This)->lpVtbl -> GetMops(This,memid,pBstrMops)

#define ITypeInfo_GetContainingTypeLib(This,ppTLib,pIndex)	\
    (This)->lpVtbl -> GetContainingTypeLib(This,ppTLib,pIndex)

#define ITypeInfo_ReleaseTypeAttr(This,pTypeAttr)	\
    (This)->lpVtbl -> ReleaseTypeAttr(This,pTypeAttr)

#define ITypeInfo_ReleaseFuncDesc(This,pFuncDesc)	\
    (This)->lpVtbl -> ReleaseFuncDesc(This,pFuncDesc)

#define ITypeInfo_ReleaseVarDesc(This,pVarDesc)	\
    (This)->lpVtbl -> ReleaseVarDesc(This,pVarDesc)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetTypeAttr_Proxy( 
    ITypeInfo __RPC_FAR * This,
    LPTYPEATTR __RPC_FAR *ppTypeAttr,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

void __RPC_STUB ITypeInfo_RemoteGetTypeAttr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetTypeComp_Proxy( 
    ITypeInfo __RPC_FAR * This,
    ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);

void __RPC_STUB ITypeInfo_GetTypeComp_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetFuncDesc_Proxy( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    LPFUNCDESC __RPC_FAR *ppFuncDesc,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

void __RPC_STUB ITypeInfo_RemoteGetFuncDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetVarDesc_Proxy( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    LPVARDESC __RPC_FAR *ppVarDesc,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

void __RPC_STUB ITypeInfo_RemoteGetVarDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetNames_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    BSTR __RPC_FAR *rgBstrNames,
    UINT cMaxNames,
    UINT __RPC_FAR *pcNames);

void __RPC_STUB ITypeInfo_RemoteGetNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetRefTypeOfImplType_Proxy( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    HREFTYPE __RPC_FAR *pRefType);

void __RPC_STUB ITypeInfo_GetRefTypeOfImplType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetImplTypeFlags_Proxy( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    INT __RPC_FAR *pImplTypeFlags);

void __RPC_STUB ITypeInfo_GetImplTypeFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_LocalGetIDsOfNames_Proxy( 
    ITypeInfo __RPC_FAR * This);

void __RPC_STUB ITypeInfo_LocalGetIDsOfNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_LocalInvoke_Proxy( 
    ITypeInfo __RPC_FAR * This);

void __RPC_STUB ITypeInfo_LocalInvoke_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetDocumentation_Proxy( 
    ITypeInfo __RPC_FAR * This,
	MEMBERID memid,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pBstrName,
    BSTR __RPC_FAR *pBstrDocString,
    DWORD __RPC_FAR *pdwHelpContext,
    BSTR __RPC_FAR *pBstrHelpFile);

void __RPC_STUB ITypeInfo_RemoteGetDocumentation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetDllEntry_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    INVOKEKIND invKind,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pBstrDllName,
    BSTR __RPC_FAR *pBstrName,
    WORD __RPC_FAR *pwOrdinal);

void __RPC_STUB ITypeInfo_RemoteGetDllEntry_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetRefTypeInfo_Proxy( 
    ITypeInfo __RPC_FAR * This,
    HREFTYPE hRefType,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

void __RPC_STUB ITypeInfo_GetRefTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_LocalAddressOfMember_Proxy( 
    ITypeInfo __RPC_FAR * This);

void __RPC_STUB ITypeInfo_LocalAddressOfMember_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteCreateInstance_Proxy( 
    ITypeInfo __RPC_FAR * This,
    REFIID riid,
    IUnknown __RPC_FAR *__RPC_FAR *ppvObj);

void __RPC_STUB ITypeInfo_RemoteCreateInstance_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetMops_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    BSTR __RPC_FAR *pBstrMops);

void __RPC_STUB ITypeInfo_GetMops_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_RemoteGetContainingTypeLib_Proxy( 
    ITypeInfo __RPC_FAR * This,
    ITypeLib __RPC_FAR *__RPC_FAR *ppTLib,
    UINT __RPC_FAR *pIndex);

void __RPC_STUB ITypeInfo_RemoteGetContainingTypeLib_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_LocalReleaseTypeAttr_Proxy( 
    ITypeInfo __RPC_FAR * This);

void __RPC_STUB ITypeInfo_LocalReleaseTypeAttr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_LocalReleaseFuncDesc_Proxy( 
    ITypeInfo __RPC_FAR * This);

void __RPC_STUB ITypeInfo_LocalReleaseFuncDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo_LocalReleaseVarDesc_Proxy( 
    ITypeInfo __RPC_FAR * This);

void __RPC_STUB ITypeInfo_LocalReleaseVarDesc_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeInfo_INTERFACE_DEFINED__ */

#ifndef __ITypeInfo2_INTERFACE_DEFINED__
#define __ITypeInfo2_INTERFACE_DEFINED__

typedef ITypeInfo2 __RPC_FAR *LPTYPEINFO2;

EXTERN_C const IID IID_ITypeInfo2;

typedef struct ITypeInfo2Vtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeInfo2 __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeInfo2 __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeInfo2 __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeAttr )( 
            ITypeInfo2 __RPC_FAR * This,
            TYPEATTR __RPC_FAR *__RPC_FAR *ppTypeAttr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeComp )( 
            ITypeInfo2 __RPC_FAR * This,
            ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFuncDesc )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            FUNCDESC __RPC_FAR *__RPC_FAR *ppFuncDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetVarDesc )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            VARDESC __RPC_FAR *__RPC_FAR *ppVarDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetNames )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            BSTR __RPC_FAR *rgBstrNames,
            UINT cMaxNames,
            UINT __RPC_FAR *pcNames);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRefTypeOfImplType )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            HREFTYPE __RPC_FAR *pRefType);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetImplTypeFlags )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            INT __RPC_FAR *pImplTypeFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ITypeInfo2 __RPC_FAR * This,
            LPOLESTR __RPC_FAR *rgszNames,
            UINT cNames,
            MEMBERID __RPC_FAR *pMemId);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ITypeInfo2 __RPC_FAR * This,
            PVOID pvInstance,
            MEMBERID memid,
            WORD wFlags,
            DISPPARAMS __RPC_FAR *pDispParams,
            VARIANT __RPC_FAR *pVarResult,
            EXCEPINFO __RPC_FAR *pExcepInfo,
            UINT __RPC_FAR *puArgErr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDocumentation )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            BSTR __RPC_FAR *pBstrName,
            BSTR __RPC_FAR *pBstrDocString,
            DWORD __RPC_FAR *pdwHelpContext,
            BSTR __RPC_FAR *pBstrHelpFile);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDllEntry )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            INVOKEKIND invKind,
            BSTR __RPC_FAR *pBstrDllName,
            BSTR __RPC_FAR *pBstrName,
            WORD __RPC_FAR *pwOrdinal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetRefTypeInfo )( 
            ITypeInfo2 __RPC_FAR * This,
            HREFTYPE hRefType,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddressOfMember )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            INVOKEKIND invKind,
            PVOID __RPC_FAR *ppv);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateInstance )( 
            ITypeInfo2 __RPC_FAR * This,
            IUnknown __RPC_FAR *pUnkOuter,
            REFIID riid,
            PVOID __RPC_FAR *ppvObj);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMops )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            BSTR __RPC_FAR *pBstrMops);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetContainingTypeLib )( 
            ITypeInfo2 __RPC_FAR * This,
            ITypeLib __RPC_FAR *__RPC_FAR *ppTLib,
            UINT __RPC_FAR *pIndex);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseTypeAttr )( 
            ITypeInfo2 __RPC_FAR * This,
            TYPEATTR __RPC_FAR *pTypeAttr);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseFuncDesc )( 
            ITypeInfo2 __RPC_FAR * This,
            FUNCDESC __RPC_FAR *pFuncDesc);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseVarDesc )( 
            ITypeInfo2 __RPC_FAR * This,
            VARDESC __RPC_FAR *pVarDesc);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeKind )( 
            ITypeInfo2 __RPC_FAR * This,
            TYPEKIND __RPC_FAR *pTypeKind);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeFlags )( 
            ITypeInfo2 __RPC_FAR * This,
            ULONG __RPC_FAR *pTypeFlags);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFuncIndexOfMemId )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            INVOKEKIND invKind,
            UINT __RPC_FAR *pFuncIndex);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetVarIndexOfMemId )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            UINT __RPC_FAR *pVarIndex);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFuncCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetParamCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT indexFunc,
            UINT indexParam,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetVarCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetImplTypeCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDocumentation2 )( 
            ITypeInfo2 __RPC_FAR * This,
            MEMBERID memid,
            LCID lcid,
            BSTR __RPC_FAR *pbstrHelpString,
            DWORD __RPC_FAR *pdwHelpStringContext,
            BSTR __RPC_FAR *pbstrHelpStringDll);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            CUSTDATA __RPC_FAR *pCustData);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllFuncCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            CUSTDATA __RPC_FAR *pCustData);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllParamCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT indexFunc,
            UINT indexParam,
            CUSTDATA __RPC_FAR *pCustData);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllVarCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            CUSTDATA __RPC_FAR *pCustData);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllImplTypeCustData )( 
            ITypeInfo2 __RPC_FAR * This,
            UINT index,
            CUSTDATA __RPC_FAR *pCustData);
        
	END_INTERFACE
} ITypeInfo2Vtbl;

    interface ITypeInfo2
    {
        CONST_VTBL struct ITypeInfo2Vtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define ITypeInfo2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeInfo2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeInfo2_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeInfo2_GetTypeAttr(This,ppTypeAttr)	\
    (This)->lpVtbl -> GetTypeAttr(This,ppTypeAttr)

#define ITypeInfo2_GetTypeComp(This,ppTComp)	\
    (This)->lpVtbl -> GetTypeComp(This,ppTComp)

#define ITypeInfo2_GetFuncDesc(This,index,ppFuncDesc)	\
    (This)->lpVtbl -> GetFuncDesc(This,index,ppFuncDesc)

#define ITypeInfo2_GetVarDesc(This,index,ppVarDesc)	\
    (This)->lpVtbl -> GetVarDesc(This,index,ppVarDesc)

#define ITypeInfo2_GetNames(This,memid,rgBstrNames,cMaxNames,pcNames)	\
    (This)->lpVtbl -> GetNames(This,memid,rgBstrNames,cMaxNames,pcNames)

#define ITypeInfo2_GetRefTypeOfImplType(This,index,pRefType)	\
    (This)->lpVtbl -> GetRefTypeOfImplType(This,index,pRefType)

#define ITypeInfo2_GetImplTypeFlags(This,index,pImplTypeFlags)	\
    (This)->lpVtbl -> GetImplTypeFlags(This,index,pImplTypeFlags)

#define ITypeInfo2_GetIDsOfNames(This,rgszNames,cNames,pMemId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,rgszNames,cNames,pMemId)

#define ITypeInfo2_Invoke(This,pvInstance,memid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,pvInstance,memid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#define ITypeInfo2_GetDocumentation(This,memid,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)	\
    (This)->lpVtbl -> GetDocumentation(This,memid,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)

#define ITypeInfo2_GetDllEntry(This,memid,invKind,pBstrDllName,pBstrName,pwOrdinal)	\
    (This)->lpVtbl -> GetDllEntry(This,memid,invKind,pBstrDllName,pBstrName,pwOrdinal)

#define ITypeInfo2_GetRefTypeInfo(This,hRefType,ppTInfo)	\
    (This)->lpVtbl -> GetRefTypeInfo(This,hRefType,ppTInfo)

#define ITypeInfo2_AddressOfMember(This,memid,invKind,ppv)	\
    (This)->lpVtbl -> AddressOfMember(This,memid,invKind,ppv)

#define ITypeInfo2_CreateInstance(This,pUnkOuter,riid,ppvObj)	\
    (This)->lpVtbl -> CreateInstance(This,pUnkOuter,riid,ppvObj)

#define ITypeInfo2_GetMops(This,memid,pBstrMops)	\
    (This)->lpVtbl -> GetMops(This,memid,pBstrMops)

#define ITypeInfo2_GetContainingTypeLib(This,ppTLib,pIndex)	\
    (This)->lpVtbl -> GetContainingTypeLib(This,ppTLib,pIndex)

#define ITypeInfo2_ReleaseTypeAttr(This,pTypeAttr)	\
    (This)->lpVtbl -> ReleaseTypeAttr(This,pTypeAttr)

#define ITypeInfo2_ReleaseFuncDesc(This,pFuncDesc)	\
    (This)->lpVtbl -> ReleaseFuncDesc(This,pFuncDesc)

#define ITypeInfo2_ReleaseVarDesc(This,pVarDesc)	\
    (This)->lpVtbl -> ReleaseVarDesc(This,pVarDesc)

#define ITypeInfo2_GetTypeKind(This,pTypeKind)	\
    (This)->lpVtbl -> GetTypeKind(This,pTypeKind)

#define ITypeInfo2_GetTypeFlags(This,pTypeFlags)	\
    (This)->lpVtbl -> GetTypeFlags(This,pTypeFlags)

#define ITypeInfo2_GetFuncIndexOfMemId(This,memid,invKind,pFuncIndex)	\
    (This)->lpVtbl -> GetFuncIndexOfMemId(This,memid,invKind,pFuncIndex)

#define ITypeInfo2_GetVarIndexOfMemId(This,memid,pVarIndex)	\
    (This)->lpVtbl -> GetVarIndexOfMemId(This,memid,pVarIndex)

#define ITypeInfo2_GetCustData(This,guid,pVarVal)	\
    (This)->lpVtbl -> GetCustData(This,guid,pVarVal)

#define ITypeInfo2_GetFuncCustData(This,index,guid,pVarVal)	\
    (This)->lpVtbl -> GetFuncCustData(This,index,guid,pVarVal)

#define ITypeInfo2_GetParamCustData(This,indexFunc,indexParam,guid,pVarVal)	\
    (This)->lpVtbl -> GetParamCustData(This,indexFunc,indexParam,guid,pVarVal)

#define ITypeInfo2_GetVarCustData(This,index,guid,pVarVal)	\
    (This)->lpVtbl -> GetVarCustData(This,index,guid,pVarVal)

#define ITypeInfo2_GetImplTypeCustData(This,index,guid,pVarVal)	\
    (This)->lpVtbl -> GetImplTypeCustData(This,index,guid,pVarVal)

#define ITypeInfo2_GetDocumentation2(This,memid,lcid,pbstrHelpString,pdwHelpStringContext,pbstrHelpStringDll)	\
    (This)->lpVtbl -> GetDocumentation2(This,memid,lcid,pbstrHelpString,pdwHelpStringContext,pbstrHelpStringDll)

#define ITypeInfo2_GetAllCustData(This,pCustData)	\
    (This)->lpVtbl -> GetAllCustData(This,pCustData)

#define ITypeInfo2_GetAllFuncCustData(This,index,pCustData)	\
    (This)->lpVtbl -> GetAllFuncCustData(This,index,pCustData)

#define ITypeInfo2_GetAllParamCustData(This,indexFunc,indexParam,pCustData)	\
    (This)->lpVtbl -> GetAllParamCustData(This,indexFunc,indexParam,pCustData)

#define ITypeInfo2_GetAllVarCustData(This,index,pCustData)	\
    (This)->lpVtbl -> GetAllVarCustData(This,index,pCustData)

#define ITypeInfo2_GetAllImplTypeCustData(This,index,pCustData)	\
    (This)->lpVtbl -> GetAllImplTypeCustData(This,index,pCustData)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetTypeKind_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    TYPEKIND __RPC_FAR *pTypeKind);

void __RPC_STUB ITypeInfo2_GetTypeKind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetTypeFlags_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    ULONG __RPC_FAR *pTypeFlags);

void __RPC_STUB ITypeInfo2_GetTypeFlags_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetFuncIndexOfMemId_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    MEMBERID memid,
    INVOKEKIND invKind,
    UINT __RPC_FAR *pFuncIndex);

void __RPC_STUB ITypeInfo2_GetFuncIndexOfMemId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetVarIndexOfMemId_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    MEMBERID memid,
    UINT __RPC_FAR *pVarIndex);

void __RPC_STUB ITypeInfo2_GetVarIndexOfMemId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ITypeInfo2_GetCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetFuncCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT index,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ITypeInfo2_GetFuncCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetParamCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT indexFunc,
    UINT indexParam,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ITypeInfo2_GetParamCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetVarCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT index,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ITypeInfo2_GetVarCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetImplTypeCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT index,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ITypeInfo2_GetImplTypeCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_RemoteGetDocumentation2_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    MEMBERID memid,
    LCID lcid,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pbstrHelpString,
    DWORD __RPC_FAR *pdwHelpStringContext,
    BSTR __RPC_FAR *pbstrHelpStringDll);

void __RPC_STUB ITypeInfo2_RemoteGetDocumentation2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetAllCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    CUSTDATA __RPC_FAR *pCustData);

void __RPC_STUB ITypeInfo2_GetAllCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetAllFuncCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT index,
    CUSTDATA __RPC_FAR *pCustData);

void __RPC_STUB ITypeInfo2_GetAllFuncCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetAllParamCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT indexFunc,
    UINT indexParam,
    CUSTDATA __RPC_FAR *pCustData);

void __RPC_STUB ITypeInfo2_GetAllParamCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetAllVarCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT index,
    CUSTDATA __RPC_FAR *pCustData);

void __RPC_STUB ITypeInfo2_GetAllVarCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetAllImplTypeCustData_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    UINT index,
    CUSTDATA __RPC_FAR *pCustData);

void __RPC_STUB ITypeInfo2_GetAllImplTypeCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeInfo2_INTERFACE_DEFINED__ */

#ifndef __ITypeLib_INTERFACE_DEFINED__
#define __ITypeLib_INTERFACE_DEFINED__

typedef
enum tagSYSKIND
    {
	SYS_WIN16	= 0,
	SYS_WIN32	= SYS_WIN16 + 1,
	SYS_MAC	= SYS_WIN32 + 1,
	SYS_WIN64	= SYS_WIN32
    }	SYSKIND;

typedef
enum tagLIBFLAGS
    {
	LIBFLAG_FRESTRICTED	= 0x1,
	LIBFLAG_FCONTROL	= 0x2,
	LIBFLAG_FHIDDEN	= 0x4,
	LIBFLAG_FHASDISKIMAGE	= 0x8
    }	LIBFLAGS;

typedef ITypeLib __RPC_FAR *LPTYPELIB;

typedef struct tagTLIBATTR
    {
    GUID guid;
    LCID lcid;
    SYSKIND syskind;
    WORD wMajorVerNum;
    WORD wMinorVerNum;
    WORD wLibFlags;
    }	TLIBATTR;

typedef struct tagTLIBATTR __RPC_FAR *LPTLIBATTR;

EXTERN_C const IID IID_ITypeLib;

typedef struct ITypeLibVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeLib __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeLib __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeLib __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITypeLib __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITypeLib __RPC_FAR * This,
            UINT index,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoType )( 
            ITypeLib __RPC_FAR * This,
            UINT index,
            TYPEKIND __RPC_FAR *pTKind);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoOfGuid )( 
            ITypeLib __RPC_FAR * This,
            REFGUID guid,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTinfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetLibAttr )( 
            ITypeLib __RPC_FAR * This,
            TLIBATTR __RPC_FAR *__RPC_FAR *ppTLibAttr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeComp )( 
            ITypeLib __RPC_FAR * This,
            ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDocumentation )( 
            ITypeLib __RPC_FAR * This,
            INT index,
            BSTR __RPC_FAR *pBstrName,
            BSTR __RPC_FAR *pBstrDocString,
            DWORD __RPC_FAR *pdwHelpContext,
            BSTR __RPC_FAR *pBstrHelpFile);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IsName )( 
            ITypeLib __RPC_FAR * This,
            LPOLESTR szNameBuf,
            ULONG lHashVal,
            BOOL __RPC_FAR *pfName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindName )( 
            ITypeLib __RPC_FAR * This,
            LPOLESTR szNameBuf,
            ULONG lHashVal,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
            MEMBERID __RPC_FAR *rgMemId,
            USHORT __RPC_FAR *pcFound);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseTLibAttr )( 
            ITypeLib __RPC_FAR * This,
            TLIBATTR __RPC_FAR *pTLibAttr);
        
        END_INTERFACE
} ITypeLibVtbl;

interface ITypeLib
{
	CONST_VTBL struct ITypeLibVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ITypeLib_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeLib_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeLib_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeLib_GetTypeInfoCount(This)	\
    (This)->lpVtbl -> GetTypeInfoCount(This)

#define ITypeLib_GetTypeInfo(This,index,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,index,ppTInfo)

#define ITypeLib_GetTypeInfoType(This,index,pTKind)	\
    (This)->lpVtbl -> GetTypeInfoType(This,index,pTKind)

#define ITypeLib_GetTypeInfoOfGuid(This,guid,ppTinfo)	\
    (This)->lpVtbl -> GetTypeInfoOfGuid(This,guid,ppTinfo)

#define ITypeLib_GetLibAttr(This,ppTLibAttr)	\
    (This)->lpVtbl -> GetLibAttr(This,ppTLibAttr)

#define ITypeLib_GetTypeComp(This,ppTComp)	\
    (This)->lpVtbl -> GetTypeComp(This,ppTComp)

#define ITypeLib_GetDocumentation(This,index,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)	\
    (This)->lpVtbl -> GetDocumentation(This,index,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)

#define ITypeLib_IsName(This,szNameBuf,lHashVal,pfName)	\
    (This)->lpVtbl -> IsName(This,szNameBuf,lHashVal,pfName)

#define ITypeLib_FindName(This,szNameBuf,lHashVal,ppTInfo,rgMemId,pcFound)	\
    (This)->lpVtbl -> FindName(This,szNameBuf,lHashVal,ppTInfo,rgMemId,pcFound)

#define ITypeLib_ReleaseTLibAttr(This,pTLibAttr)	\
    (This)->lpVtbl -> ReleaseTLibAttr(This,pTLibAttr)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeLib_RemoteGetTypeInfoCount_Proxy( 
    ITypeLib __RPC_FAR * This,
    UINT __RPC_FAR *pcTInfo);

void __RPC_STUB ITypeLib_RemoteGetTypeInfoCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_GetTypeInfo_Proxy( 
    ITypeLib __RPC_FAR * This,
    UINT index,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

void __RPC_STUB ITypeLib_GetTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_GetTypeInfoType_Proxy( 
    ITypeLib __RPC_FAR * This,
    UINT index,
    TYPEKIND __RPC_FAR *pTKind);

void __RPC_STUB ITypeLib_GetTypeInfoType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_GetTypeInfoOfGuid_Proxy( 
    ITypeLib __RPC_FAR * This,
    REFGUID guid,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTinfo);

void __RPC_STUB ITypeLib_GetTypeInfoOfGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_RemoteGetLibAttr_Proxy( 
    ITypeLib __RPC_FAR * This,
    LPTLIBATTR __RPC_FAR *ppTLibAttr,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

void __RPC_STUB ITypeLib_RemoteGetLibAttr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_GetTypeComp_Proxy( 
    ITypeLib __RPC_FAR * This,
    ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);

void __RPC_STUB ITypeLib_GetTypeComp_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_RemoteGetDocumentation_Proxy( 
    ITypeLib __RPC_FAR * This,
    INT index,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pBstrName,
    BSTR __RPC_FAR *pBstrDocString,
    DWORD __RPC_FAR *pdwHelpContext,
    BSTR __RPC_FAR *pBstrHelpFile);

void __RPC_STUB ITypeLib_RemoteGetDocumentation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_RemoteIsName_Proxy( 
    ITypeLib __RPC_FAR * This,
    LPOLESTR szNameBuf,
    ULONG lHashVal,
    BOOL __RPC_FAR *pfName,
    BSTR __RPC_FAR *pBstrLibName);

void __RPC_STUB ITypeLib_RemoteIsName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_RemoteFindName_Proxy( 
    ITypeLib __RPC_FAR * This,
    LPOLESTR szNameBuf,
    ULONG lHashVal,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    MEMBERID __RPC_FAR *rgMemId,
    USHORT __RPC_FAR *pcFound,
    BSTR __RPC_FAR *pBstrLibName);

void __RPC_STUB ITypeLib_RemoteFindName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib_LocalReleaseTLibAttr_Proxy( 
    ITypeLib __RPC_FAR * This);

void __RPC_STUB ITypeLib_LocalReleaseTLibAttr_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeLib_INTERFACE_DEFINED__ */

#ifndef __ITypeLib2_INTERFACE_DEFINED__
#define __ITypeLib2_INTERFACE_DEFINED__

typedef ITypeLib2 __RPC_FAR *LPTYPELIB2;

EXTERN_C const IID IID_ITypeLib2;

typedef struct ITypeLib2Vtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeLib2 __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeLib2 __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeLib2 __RPC_FAR * This);
        
	UINT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ITypeLib2 __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ITypeLib2 __RPC_FAR * This,
            UINT index,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoType )( 
            ITypeLib2 __RPC_FAR * This,
            UINT index,
            TYPEKIND __RPC_FAR *pTKind);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoOfGuid )( 
            ITypeLib2 __RPC_FAR * This,
            REFGUID guid,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTinfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetLibAttr )( 
            ITypeLib2 __RPC_FAR * This,
            TLIBATTR __RPC_FAR *__RPC_FAR *ppTLibAttr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeComp )( 
            ITypeLib2 __RPC_FAR * This,
            ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDocumentation )( 
            ITypeLib2 __RPC_FAR * This,
            INT index,
            BSTR __RPC_FAR *pBstrName,
            BSTR __RPC_FAR *pBstrDocString,
            DWORD __RPC_FAR *pdwHelpContext,
            BSTR __RPC_FAR *pBstrHelpFile);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IsName )( 
            ITypeLib2 __RPC_FAR * This,
            LPOLESTR szNameBuf,
            ULONG lHashVal,
            BOOL __RPC_FAR *pfName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *FindName )( 
            ITypeLib2 __RPC_FAR * This,
            LPOLESTR szNameBuf,
            ULONG lHashVal,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
            MEMBERID __RPC_FAR *rgMemId,
            USHORT __RPC_FAR *pcFound);
        
	void ( STDMETHODCALLTYPE __RPC_FAR *ReleaseTLibAttr )( 
            ITypeLib2 __RPC_FAR * This,
            TLIBATTR __RPC_FAR *pTLibAttr);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCustData )( 
            ITypeLib2 __RPC_FAR * This,
            REFGUID guid,
            VARIANT __RPC_FAR *pVarVal);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetLibStatistics )( 
            ITypeLib2 __RPC_FAR * This,
            ULONG __RPC_FAR *pcUniqueNames,
            ULONG __RPC_FAR *pcchUniqueNames);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDocumentation2 )( 
            ITypeLib2 __RPC_FAR * This,
            INT index,
            LCID lcid,
            BSTR __RPC_FAR *pbstrHelpString,
            DWORD __RPC_FAR *pdwHelpStringContext,
            BSTR __RPC_FAR *pbstrHelpStringDll);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetAllCustData )( 
            ITypeLib2 __RPC_FAR * This,
            CUSTDATA __RPC_FAR *pCustData);
        
	END_INTERFACE
} ITypeLib2Vtbl;

interface ITypeLib2
{
	CONST_VTBL struct ITypeLib2Vtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ITypeLib2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeLib2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeLib2_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeLib2_GetTypeInfoCount(This)	\
    (This)->lpVtbl -> GetTypeInfoCount(This)

#define ITypeLib2_GetTypeInfo(This,index,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,index,ppTInfo)

#define ITypeLib2_GetTypeInfoType(This,index,pTKind)	\
    (This)->lpVtbl -> GetTypeInfoType(This,index,pTKind)

#define ITypeLib2_GetTypeInfoOfGuid(This,guid,ppTinfo)	\
    (This)->lpVtbl -> GetTypeInfoOfGuid(This,guid,ppTinfo)

#define ITypeLib2_GetLibAttr(This,ppTLibAttr)	\
    (This)->lpVtbl -> GetLibAttr(This,ppTLibAttr)

#define ITypeLib2_GetTypeComp(This,ppTComp)	\
    (This)->lpVtbl -> GetTypeComp(This,ppTComp)

#define ITypeLib2_GetDocumentation(This,index,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)	\
    (This)->lpVtbl -> GetDocumentation(This,index,pBstrName,pBstrDocString,pdwHelpContext,pBstrHelpFile)

#define ITypeLib2_IsName(This,szNameBuf,lHashVal,pfName)	\
    (This)->lpVtbl -> IsName(This,szNameBuf,lHashVal,pfName)

#define ITypeLib2_FindName(This,szNameBuf,lHashVal,ppTInfo,rgMemId,pcFound)	\
    (This)->lpVtbl -> FindName(This,szNameBuf,lHashVal,ppTInfo,rgMemId,pcFound)

#define ITypeLib2_ReleaseTLibAttr(This,pTLibAttr)	\
    (This)->lpVtbl -> ReleaseTLibAttr(This,pTLibAttr)

#define ITypeLib2_GetCustData(This,guid,pVarVal)	\
    (This)->lpVtbl -> GetCustData(This,guid,pVarVal)

#define ITypeLib2_GetLibStatistics(This,pcUniqueNames,pcchUniqueNames)	\
    (This)->lpVtbl -> GetLibStatistics(This,pcUniqueNames,pcchUniqueNames)

#define ITypeLib2_GetDocumentation2(This,index,lcid,pbstrHelpString,pdwHelpStringContext,pbstrHelpStringDll)	\
    (This)->lpVtbl -> GetDocumentation2(This,index,lcid,pbstrHelpString,pdwHelpStringContext,pbstrHelpStringDll)

#define ITypeLib2_GetAllCustData(This,pCustData)	\
    (This)->lpVtbl -> GetAllCustData(This,pCustData)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeLib2_GetCustData_Proxy( 
    ITypeLib2 __RPC_FAR * This,
    REFGUID guid,
    VARIANT __RPC_FAR *pVarVal);

void __RPC_STUB ITypeLib2_GetCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib2_RemoteGetLibStatistics_Proxy( 
    ITypeLib2 __RPC_FAR * This,
    ULONG __RPC_FAR *pcUniqueNames,
    ULONG __RPC_FAR *pcchUniqueNames);

void __RPC_STUB ITypeLib2_RemoteGetLibStatistics_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib2_RemoteGetDocumentation2_Proxy( 
    ITypeLib2 __RPC_FAR * This,
    INT index,
    LCID lcid,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pbstrHelpString,
    DWORD __RPC_FAR *pdwHelpStringContext,
    BSTR __RPC_FAR *pbstrHelpStringDll);

void __RPC_STUB ITypeLib2_RemoteGetDocumentation2_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeLib2_GetAllCustData_Proxy( 
    ITypeLib2 __RPC_FAR * This,
    CUSTDATA __RPC_FAR *pCustData);

void __RPC_STUB ITypeLib2_GetAllCustData_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeLib2_INTERFACE_DEFINED__ */

#ifndef __ITypeChangeEvents_INTERFACE_DEFINED__
#define __ITypeChangeEvents_INTERFACE_DEFINED__

typedef ITypeChangeEvents __RPC_FAR *LPTYPECHANGEEVENTS;

typedef 
enum tagCHANGEKIND
{
	CHANGEKIND_ADDMEMBER	= 0,
	CHANGEKIND_DELETEMEMBER	= CHANGEKIND_ADDMEMBER + 1,
	CHANGEKIND_SETNAMES	= CHANGEKIND_DELETEMEMBER + 1,
	CHANGEKIND_SETDOCUMENTATION	= CHANGEKIND_SETNAMES + 1,
	CHANGEKIND_GENERAL	= CHANGEKIND_SETDOCUMENTATION + 1,
	CHANGEKIND_INVALIDATE	= CHANGEKIND_GENERAL + 1,
	CHANGEKIND_CHANGEFAILED	= CHANGEKIND_INVALIDATE + 1,
	CHANGEKIND_MAX	= CHANGEKIND_CHANGEFAILED + 1
}	CHANGEKIND;

EXTERN_C const IID IID_ITypeChangeEvents;

typedef struct ITypeChangeEventsVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeChangeEvents __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeChangeEvents __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeChangeEvents __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RequestTypeChange )( 
            ITypeChangeEvents __RPC_FAR * This,
            CHANGEKIND changeKind,
            ITypeInfo __RPC_FAR *pTInfoBefore,
            LPOLESTR pStrName,
            INT __RPC_FAR *pfCancel);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AfterTypeChange )( 
            ITypeChangeEvents __RPC_FAR * This,
            CHANGEKIND changeKind,
            ITypeInfo __RPC_FAR *pTInfoAfter,
            LPOLESTR pStrName);
        
	END_INTERFACE
} ITypeChangeEventsVtbl;

interface ITypeChangeEvents
{
	CONST_VTBL struct ITypeChangeEventsVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ITypeChangeEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeChangeEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeChangeEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeChangeEvents_RequestTypeChange(This,changeKind,pTInfoBefore,pStrName,pfCancel)	\
    (This)->lpVtbl -> RequestTypeChange(This,changeKind,pTInfoBefore,pStrName,pfCancel)

#define ITypeChangeEvents_AfterTypeChange(This,changeKind,pTInfoAfter,pStrName)	\
    (This)->lpVtbl -> AfterTypeChange(This,changeKind,pTInfoAfter,pStrName)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeChangeEvents_RequestTypeChange_Proxy( 
    ITypeChangeEvents __RPC_FAR * This,
    CHANGEKIND changeKind,
    ITypeInfo __RPC_FAR *pTInfoBefore,
    LPOLESTR pStrName,
    INT __RPC_FAR *pfCancel);

void __RPC_STUB ITypeChangeEvents_RequestTypeChange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeChangeEvents_AfterTypeChange_Proxy( 
    ITypeChangeEvents __RPC_FAR * This,
    CHANGEKIND changeKind,
    ITypeInfo __RPC_FAR *pTInfoAfter,
    LPOLESTR pStrName);

void __RPC_STUB ITypeChangeEvents_AfterTypeChange_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeChangeEvents_INTERFACE_DEFINED__ */

#ifndef __IErrorInfo_INTERFACE_DEFINED__
#define __IErrorInfo_INTERFACE_DEFINED__

typedef IErrorInfo __RPC_FAR *LPERRORINFO;

EXTERN_C const IID IID_IErrorInfo;

typedef struct IErrorInfoVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IErrorInfo __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IErrorInfo __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IErrorInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetGUID )( 
            IErrorInfo __RPC_FAR * This,
            GUID __RPC_FAR *pGUID);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSource )( 
            IErrorInfo __RPC_FAR * This,
            BSTR __RPC_FAR *pBstrSource);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDescription )( 
            IErrorInfo __RPC_FAR * This,
            BSTR __RPC_FAR *pBstrDescription);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHelpFile )( 
            IErrorInfo __RPC_FAR * This,
            BSTR __RPC_FAR *pBstrHelpFile);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetHelpContext )( 
            IErrorInfo __RPC_FAR * This,
            DWORD __RPC_FAR *pdwHelpContext);
        
	END_INTERFACE
} IErrorInfoVtbl;

interface IErrorInfo
{
	CONST_VTBL struct IErrorInfoVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS


#define IErrorInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IErrorInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IErrorInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IErrorInfo_GetGUID(This,pGUID)	\
    (This)->lpVtbl -> GetGUID(This,pGUID)

#define IErrorInfo_GetSource(This,pBstrSource)	\
    (This)->lpVtbl -> GetSource(This,pBstrSource)

#define IErrorInfo_GetDescription(This,pBstrDescription)	\
    (This)->lpVtbl -> GetDescription(This,pBstrDescription)

#define IErrorInfo_GetHelpFile(This,pBstrHelpFile)	\
    (This)->lpVtbl -> GetHelpFile(This,pBstrHelpFile)

#define IErrorInfo_GetHelpContext(This,pdwHelpContext)	\
    (This)->lpVtbl -> GetHelpContext(This,pdwHelpContext)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IErrorInfo_GetGUID_Proxy( 
    IErrorInfo __RPC_FAR * This,
    GUID __RPC_FAR *pGUID);

void __RPC_STUB IErrorInfo_GetGUID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IErrorInfo_GetSource_Proxy( 
    IErrorInfo __RPC_FAR * This,
    BSTR __RPC_FAR *pBstrSource);

void __RPC_STUB IErrorInfo_GetSource_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IErrorInfo_GetDescription_Proxy( 
    IErrorInfo __RPC_FAR * This,
    BSTR __RPC_FAR *pBstrDescription);

void __RPC_STUB IErrorInfo_GetDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IErrorInfo_GetHelpFile_Proxy( 
    IErrorInfo __RPC_FAR * This,
    BSTR __RPC_FAR *pBstrHelpFile);

void __RPC_STUB IErrorInfo_GetHelpFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IErrorInfo_GetHelpContext_Proxy( 
    IErrorInfo __RPC_FAR * This,
    DWORD __RPC_FAR *pdwHelpContext);

void __RPC_STUB IErrorInfo_GetHelpContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IErrorInfo_INTERFACE_DEFINED__ */

#ifndef __ICreateErrorInfo_INTERFACE_DEFINED__
#define __ICreateErrorInfo_INTERFACE_DEFINED__

typedef ICreateErrorInfo __RPC_FAR *LPCREATEERRORINFO;

EXTERN_C const IID IID_ICreateErrorInfo;

typedef struct ICreateErrorInfoVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICreateErrorInfo __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICreateErrorInfo __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICreateErrorInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetGUID )( 
            ICreateErrorInfo __RPC_FAR * This,
            REFGUID rguid);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSource )( 
            ICreateErrorInfo __RPC_FAR * This,
            LPOLESTR szSource);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetDescription )( 
            ICreateErrorInfo __RPC_FAR * This,
            LPOLESTR szDescription);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpFile )( 
            ICreateErrorInfo __RPC_FAR * This,
            LPOLESTR szHelpFile);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetHelpContext )( 
            ICreateErrorInfo __RPC_FAR * This,
            DWORD dwHelpContext);
        
	END_INTERFACE
} ICreateErrorInfoVtbl;

interface ICreateErrorInfo
{
	CONST_VTBL struct ICreateErrorInfoVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ICreateErrorInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICreateErrorInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICreateErrorInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ICreateErrorInfo_SetGUID(This,rguid)	\
    (This)->lpVtbl -> SetGUID(This,rguid)

#define ICreateErrorInfo_SetSource(This,szSource)	\
    (This)->lpVtbl -> SetSource(This,szSource)

#define ICreateErrorInfo_SetDescription(This,szDescription)	\
    (This)->lpVtbl -> SetDescription(This,szDescription)

#define ICreateErrorInfo_SetHelpFile(This,szHelpFile)	\
    (This)->lpVtbl -> SetHelpFile(This,szHelpFile)

#define ICreateErrorInfo_SetHelpContext(This,dwHelpContext)	\
    (This)->lpVtbl -> SetHelpContext(This,dwHelpContext)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ICreateErrorInfo_SetGUID_Proxy( 
    ICreateErrorInfo __RPC_FAR * This,
    REFGUID rguid);

void __RPC_STUB ICreateErrorInfo_SetGUID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateErrorInfo_SetSource_Proxy( 
    ICreateErrorInfo __RPC_FAR * This,
    LPOLESTR szSource);

void __RPC_STUB ICreateErrorInfo_SetSource_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateErrorInfo_SetDescription_Proxy( 
    ICreateErrorInfo __RPC_FAR * This,
    LPOLESTR szDescription);

void __RPC_STUB ICreateErrorInfo_SetDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateErrorInfo_SetHelpFile_Proxy( 
    ICreateErrorInfo __RPC_FAR * This,
    LPOLESTR szHelpFile);

void __RPC_STUB ICreateErrorInfo_SetHelpFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ICreateErrorInfo_SetHelpContext_Proxy( 
    ICreateErrorInfo __RPC_FAR * This,
    DWORD dwHelpContext);

void __RPC_STUB ICreateErrorInfo_SetHelpContext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ICreateErrorInfo_INTERFACE_DEFINED__ */

#ifndef __ISupportErrorInfo_INTERFACE_DEFINED__
#define __ISupportErrorInfo_INTERFACE_DEFINED__

typedef ISupportErrorInfo __RPC_FAR *LPSUPPORTERRORINFO;

EXTERN_C const IID IID_ISupportErrorInfo;

typedef struct ISupportErrorInfoVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISupportErrorInfo __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISupportErrorInfo __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISupportErrorInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *InterfaceSupportsErrorInfo )( 
            ISupportErrorInfo __RPC_FAR * This,
            REFIID riid);
        
	END_INTERFACE
} ISupportErrorInfoVtbl;

interface ISupportErrorInfo
{
	CONST_VTBL struct ISupportErrorInfoVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ISupportErrorInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISupportErrorInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISupportErrorInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ISupportErrorInfo_InterfaceSupportsErrorInfo(This,riid)	\
    (This)->lpVtbl -> InterfaceSupportsErrorInfo(This,riid)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ISupportErrorInfo_InterfaceSupportsErrorInfo_Proxy( 
    ISupportErrorInfo __RPC_FAR * This,
    REFIID riid);

void __RPC_STUB ISupportErrorInfo_InterfaceSupportsErrorInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ISupportErrorInfo_INTERFACE_DEFINED__ */

#ifndef __ITypeFactory_INTERFACE_DEFINED__
#define __ITypeFactory_INTERFACE_DEFINED__

EXTERN_C const IID IID_ITypeFactory;

typedef struct ITypeFactoryVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeFactory __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeFactory __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeFactory __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateFromTypeInfo )( 
            ITypeFactory __RPC_FAR * This,
            ITypeInfo __RPC_FAR *pTypeInfo,
            REFIID riid,
            IUnknown __RPC_FAR *__RPC_FAR *ppv);
        
	END_INTERFACE
} ITypeFactoryVtbl;

interface ITypeFactory
{
	CONST_VTBL struct ITypeFactoryVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ITypeFactory_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeFactory_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeFactory_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeFactory_CreateFromTypeInfo(This,pTypeInfo,riid,ppv)	\
    (This)->lpVtbl -> CreateFromTypeInfo(This,pTypeInfo,riid,ppv)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeFactory_CreateFromTypeInfo_Proxy( 
    ITypeFactory __RPC_FAR * This,
    ITypeInfo __RPC_FAR *pTypeInfo,
    REFIID riid,
    IUnknown __RPC_FAR *__RPC_FAR *ppv);

void __RPC_STUB ITypeFactory_CreateFromTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeFactory_INTERFACE_DEFINED__ */

#ifndef __ITypeMarshal_INTERFACE_DEFINED__
#define __ITypeMarshal_INTERFACE_DEFINED__

EXTERN_C const IID IID_ITypeMarshal;

typedef struct ITypeMarshalVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ITypeMarshal __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ITypeMarshal __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ITypeMarshal __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Size )( 
            ITypeMarshal __RPC_FAR * This,
            PVOID pvType,
            DWORD dwDestContext,
            PVOID pvDestContext,
            ULONG __RPC_FAR *pSize);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Marshal )( 
            ITypeMarshal __RPC_FAR * This,
            PVOID pvType,
            DWORD dwDestContext,
            PVOID pvDestContext,
            ULONG cbBufferLength,
            BYTE __RPC_FAR *pBuffer,
            ULONG __RPC_FAR *pcbWritten);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Unmarshal )( 
            ITypeMarshal __RPC_FAR * This,
            PVOID pvType,
            DWORD dwFlags,
            ULONG cbBufferLength,
            BYTE __RPC_FAR *pBuffer,
            ULONG __RPC_FAR *pcbRead);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Free )( 
            ITypeMarshal __RPC_FAR * This,
            PVOID pvType);
        
	END_INTERFACE
} ITypeMarshalVtbl;

interface ITypeMarshal
{
	 CONST_VTBL struct ITypeMarshalVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define ITypeMarshal_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ITypeMarshal_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ITypeMarshal_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define ITypeMarshal_Size(This,pvType,dwDestContext,pvDestContext,pSize)	\
    (This)->lpVtbl -> Size(This,pvType,dwDestContext,pvDestContext,pSize)

#define ITypeMarshal_Marshal(This,pvType,dwDestContext,pvDestContext,cbBufferLength,pBuffer,pcbWritten)	\
    (This)->lpVtbl -> Marshal(This,pvType,dwDestContext,pvDestContext,cbBufferLength,pBuffer,pcbWritten)

#define ITypeMarshal_Unmarshal(This,pvType,dwFlags,cbBufferLength,pBuffer,pcbRead)	\
    (This)->lpVtbl -> Unmarshal(This,pvType,dwFlags,cbBufferLength,pBuffer,pcbRead)

#define ITypeMarshal_Free(This,pvType)	\
    (This)->lpVtbl -> Free(This,pvType)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE ITypeMarshal_Size_Proxy( 
    ITypeMarshal __RPC_FAR * This,
    PVOID pvType,
    DWORD dwDestContext,
    PVOID pvDestContext,
    ULONG __RPC_FAR *pSize);

void __RPC_STUB ITypeMarshal_Size_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeMarshal_Marshal_Proxy( 
    ITypeMarshal __RPC_FAR * This,
    PVOID pvType,
    DWORD dwDestContext,
    PVOID pvDestContext,
    ULONG cbBufferLength,
    BYTE __RPC_FAR *pBuffer,
    ULONG __RPC_FAR *pcbWritten);

void __RPC_STUB ITypeMarshal_Marshal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeMarshal_Unmarshal_Proxy( 
    ITypeMarshal __RPC_FAR * This,
    PVOID pvType,
    DWORD dwFlags,
    ULONG cbBufferLength,
    BYTE __RPC_FAR *pBuffer,
    ULONG __RPC_FAR *pcbRead);

void __RPC_STUB ITypeMarshal_Unmarshal_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE ITypeMarshal_Free_Proxy( 
    ITypeMarshal __RPC_FAR * This,
    PVOID pvType);

void __RPC_STUB ITypeMarshal_Free_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __ITypeMarshal_INTERFACE_DEFINED__ */

#ifndef __IRecordInfo_INTERFACE_DEFINED__
#define __IRecordInfo_INTERFACE_DEFINED__

typedef IRecordInfo __RPC_FAR *LPRECORDINFO;

EXTERN_C const IID IID_IRecordInfo;

typedef struct IRecordInfoVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRecordInfo __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRecordInfo __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRecordInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordInit )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvNew);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordClear )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvExisting);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordCopy )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvExisting,
            PVOID pvNew);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetGuid )( 
            IRecordInfo __RPC_FAR * This,
            GUID __RPC_FAR *pguid);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetName )( 
            IRecordInfo __RPC_FAR * This,
            BSTR __RPC_FAR *pbstrName);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSize )( 
            IRecordInfo __RPC_FAR * This,
            ULONG __RPC_FAR *pcbSize);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRecordInfo __RPC_FAR * This,
            ITypeInfo __RPC_FAR *__RPC_FAR *ppTypeInfo);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetField )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvData,
            LPCOLESTR szFieldName,
            VARIANT __RPC_FAR *pvarField);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFieldNoCopy )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvData,
            LPCOLESTR szFieldName,
            VARIANT __RPC_FAR *pvarField,
            PVOID __RPC_FAR *ppvDataCArray);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PutField )( 
            IRecordInfo __RPC_FAR * This,
            ULONG wFlags,
            PVOID pvData,
            LPCOLESTR szFieldName,
            VARIANT __RPC_FAR *pvarField);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *PutFieldNoCopy )( 
            IRecordInfo __RPC_FAR * This,
            ULONG wFlags,
            PVOID pvData,
            LPCOLESTR szFieldName,
            VARIANT __RPC_FAR *pvarField);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetFieldNames )( 
            IRecordInfo __RPC_FAR * This,
            ULONG __RPC_FAR *pcNames,
            BSTR __RPC_FAR *rgBstrNames);
        
	BOOL ( STDMETHODCALLTYPE __RPC_FAR *IsMatchingType )( 
            IRecordInfo __RPC_FAR * This,
            IRecordInfo __RPC_FAR *pRecordInfo);
        
	PVOID ( STDMETHODCALLTYPE __RPC_FAR *RecordCreate )( 
            IRecordInfo __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordCreateCopy )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvSource,
            PVOID __RPC_FAR *ppvDest);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RecordDestroy )( 
            IRecordInfo __RPC_FAR * This,
            PVOID pvRecord);
        
	END_INTERFACE
} IRecordInfoVtbl;

interface IRecordInfo
{
	CONST_VTBL struct IRecordInfoVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define IRecordInfo_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRecordInfo_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRecordInfo_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IRecordInfo_RecordInit(This,pvNew)	\
    (This)->lpVtbl -> RecordInit(This,pvNew)

#define IRecordInfo_RecordClear(This,pvExisting)	\
    (This)->lpVtbl -> RecordClear(This,pvExisting)

#define IRecordInfo_RecordCopy(This,pvExisting,pvNew)	\
    (This)->lpVtbl -> RecordCopy(This,pvExisting,pvNew)

#define IRecordInfo_GetGuid(This,pguid)	\
    (This)->lpVtbl -> GetGuid(This,pguid)

#define IRecordInfo_GetName(This,pbstrName)	\
    (This)->lpVtbl -> GetName(This,pbstrName)

#define IRecordInfo_GetSize(This,pcbSize)	\
    (This)->lpVtbl -> GetSize(This,pcbSize)

#define IRecordInfo_GetTypeInfo(This,ppTypeInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,ppTypeInfo)

#define IRecordInfo_GetField(This,pvData,szFieldName,pvarField)	\
    (This)->lpVtbl -> GetField(This,pvData,szFieldName,pvarField)

#define IRecordInfo_GetFieldNoCopy(This,pvData,szFieldName,pvarField,ppvDataCArray)	\
    (This)->lpVtbl -> GetFieldNoCopy(This,pvData,szFieldName,pvarField,ppvDataCArray)

#define IRecordInfo_PutField(This,wFlags,pvData,szFieldName,pvarField)	\
    (This)->lpVtbl -> PutField(This,wFlags,pvData,szFieldName,pvarField)

#define IRecordInfo_PutFieldNoCopy(This,wFlags,pvData,szFieldName,pvarField)	\
    (This)->lpVtbl -> PutFieldNoCopy(This,wFlags,pvData,szFieldName,pvarField)

#define IRecordInfo_GetFieldNames(This,pcNames,rgBstrNames)	\
    (This)->lpVtbl -> GetFieldNames(This,pcNames,rgBstrNames)

#define IRecordInfo_IsMatchingType(This,pRecordInfo)	\
    (This)->lpVtbl -> IsMatchingType(This,pRecordInfo)

#define IRecordInfo_RecordCreate(This)	\
    (This)->lpVtbl -> RecordCreate(This)

#define IRecordInfo_RecordCreateCopy(This,pvSource,ppvDest)	\
    (This)->lpVtbl -> RecordCreateCopy(This,pvSource,ppvDest)

#define IRecordInfo_RecordDestroy(This,pvRecord)	\
    (This)->lpVtbl -> RecordDestroy(This,pvRecord)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IRecordInfo_RecordInit_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvNew);


void __RPC_STUB IRecordInfo_RecordInit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_RecordClear_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvExisting);

void __RPC_STUB IRecordInfo_RecordClear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_RecordCopy_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvExisting,
    PVOID pvNew);

void __RPC_STUB IRecordInfo_RecordCopy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_GetGuid_Proxy( 
    IRecordInfo __RPC_FAR * This,
    GUID __RPC_FAR *pguid);

void __RPC_STUB IRecordInfo_GetGuid_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_GetName_Proxy( 
    IRecordInfo __RPC_FAR * This,
    BSTR __RPC_FAR *pbstrName);

void __RPC_STUB IRecordInfo_GetName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRecordInfo_GetSize_Proxy( 
    IRecordInfo __RPC_FAR * This,
    ULONG __RPC_FAR *pcbSize);

void __RPC_STUB IRecordInfo_GetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


HRESULT STDMETHODCALLTYPE IRecordInfo_GetTypeInfo_Proxy( 
    IRecordInfo __RPC_FAR * This,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTypeInfo);

void __RPC_STUB IRecordInfo_GetTypeInfo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_GetField_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvData,
    LPCOLESTR szFieldName,
    VARIANT __RPC_FAR *pvarField);

void __RPC_STUB IRecordInfo_GetField_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_GetFieldNoCopy_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvData,
    LPCOLESTR szFieldName,
    VARIANT __RPC_FAR *pvarField,
    PVOID __RPC_FAR *ppvDataCArray);

void __RPC_STUB IRecordInfo_GetFieldNoCopy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_PutField_Proxy( 
    IRecordInfo __RPC_FAR * This,
    ULONG wFlags,
   PVOID pvData,
    LPCOLESTR szFieldName,
    VARIANT __RPC_FAR *pvarField);

void __RPC_STUB IRecordInfo_PutField_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_PutFieldNoCopy_Proxy( 
    IRecordInfo __RPC_FAR * This,
    ULONG wFlags,
    PVOID pvData,
    LPCOLESTR szFieldName,
    VARIANT __RPC_FAR *pvarField);

void __RPC_STUB IRecordInfo_PutFieldNoCopy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_GetFieldNames_Proxy( 
    IRecordInfo __RPC_FAR * This,
    ULONG __RPC_FAR *pcNames,
    BSTR __RPC_FAR *rgBstrNames);

void __RPC_STUB IRecordInfo_GetFieldNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

BOOL STDMETHODCALLTYPE IRecordInfo_IsMatchingType_Proxy( 
    IRecordInfo __RPC_FAR * This,
    IRecordInfo __RPC_FAR *pRecordInfo);

void __RPC_STUB IRecordInfo_IsMatchingType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

PVOID STDMETHODCALLTYPE IRecordInfo_RecordCreate_Proxy( 
    IRecordInfo __RPC_FAR * This);

void __RPC_STUB IRecordInfo_RecordCreate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_RecordCreateCopy_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvSource,
    PVOID __RPC_FAR *ppvDest);

void __RPC_STUB IRecordInfo_RecordCreateCopy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IRecordInfo_RecordDestroy_Proxy( 
    IRecordInfo __RPC_FAR * This,
    PVOID pvRecord);

void __RPC_STUB IRecordInfo_RecordDestroy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IRecordInfo_INTERFACE_DEFINED__ */

#ifndef __IErrorLog_INTERFACE_DEFINED__
#define __IErrorLog_INTERFACE_DEFINED__

typedef IErrorLog __RPC_FAR *LPERRORLOG;

EXTERN_C const IID IID_IErrorLog;

typedef struct IErrorLogVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IErrorLog __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IErrorLog __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IErrorLog __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddError )( 
            IErrorLog __RPC_FAR * This,
            LPCOLESTR pszPropName,
            EXCEPINFO __RPC_FAR *pExcepInfo);
        
	END_INTERFACE
} IErrorLogVtbl;

interface IErrorLog
{
	CONST_VTBL struct IErrorLogVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define IErrorLog_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IErrorLog_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IErrorLog_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IErrorLog_AddError(This,pszPropName,pExcepInfo)	\
    (This)->lpVtbl -> AddError(This,pszPropName,pExcepInfo)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IErrorLog_AddError_Proxy( 
    IErrorLog __RPC_FAR * This,
    LPCOLESTR pszPropName,
    EXCEPINFO __RPC_FAR *pExcepInfo);

void __RPC_STUB IErrorLog_AddError_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IErrorLog_INTERFACE_DEFINED__ */

#ifndef __IPropertyBag_INTERFACE_DEFINED__
#define __IPropertyBag_INTERFACE_DEFINED__

typedef IPropertyBag __RPC_FAR *LPPROPERTYBAG;

EXTERN_C const IID IID_IPropertyBag;

typedef struct IPropertyBagVtbl
{
	BEGIN_INTERFACE
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPropertyBag __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPropertyBag __RPC_FAR * This);
        
	ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPropertyBag __RPC_FAR * This);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Read )( 
            IPropertyBag __RPC_FAR * This,
            LPCOLESTR pszPropName,
            VARIANT __RPC_FAR *pVar,
            IErrorLog __RPC_FAR *pErrorLog);
        
	HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Write )( 
            IPropertyBag __RPC_FAR * This,
            LPCOLESTR pszPropName,
            VARIANT __RPC_FAR *pVar);
        
	END_INTERFACE
} IPropertyBagVtbl;

interface IPropertyBag
{
	CONST_VTBL struct IPropertyBagVtbl __RPC_FAR *lpVtbl;
};

#ifdef COBJMACROS

#define IPropertyBag_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPropertyBag_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPropertyBag_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IPropertyBag_Read(This,pszPropName,pVar,pErrorLog)	\
    (This)->lpVtbl -> Read(This,pszPropName,pVar,pErrorLog)

#define IPropertyBag_Write(This,pszPropName,pVar)	\
    (This)->lpVtbl -> Write(This,pszPropName,pVar)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IPropertyBag_RemoteRead_Proxy( 
    IPropertyBag __RPC_FAR * This,
    LPCOLESTR pszPropName,
    VARIANT __RPC_FAR *pVar,
    IErrorLog __RPC_FAR *pErrorLog,
    DWORD varType,
    IUnknown __RPC_FAR *pUnkObj);

void __RPC_STUB IPropertyBag_RemoteRead_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyBag_Write_Proxy( 
    IPropertyBag __RPC_FAR * This,
    LPCOLESTR pszPropName,
    VARIANT __RPC_FAR *pVar);

void __RPC_STUB IPropertyBag_Write_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IPropertyBag_INTERFACE_DEFINED__ */

#pragma warning(pop)

extern RPC_IF_HANDLE __MIDL_itf_oaidl_0103_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_oaidl_0103_v0_0_s_ifspec;

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned long             __RPC_USER  CLEANLOCALSTORAGE_UserSize(     unsigned long __RPC_FAR *, unsigned long            , CLEANLOCALSTORAGE __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  CLEANLOCALSTORAGE_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, CLEANLOCALSTORAGE __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  CLEANLOCALSTORAGE_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, CLEANLOCALSTORAGE __RPC_FAR * ); 
void                      __RPC_USER  CLEANLOCALSTORAGE_UserFree(     unsigned long __RPC_FAR *, CLEANLOCALSTORAGE __RPC_FAR * ); 
unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 
HRESULT STDMETHODCALLTYPE IDispatch_Invoke_Proxy( 
    IDispatch __RPC_FAR * This,
    DISPID dispIdMember,
    REFIID riid,
    LCID lcid,
    WORD wFlags,
    DISPPARAMS __RPC_FAR *pDispParams,
    VARIANT __RPC_FAR *pVarResult,
    EXCEPINFO __RPC_FAR *pExcepInfo,
    UINT __RPC_FAR *puArgErr);

HRESULT STDMETHODCALLTYPE IDispatch_Invoke_Stub( 
    IDispatch __RPC_FAR * This,
    DISPID dispIdMember,
    REFIID riid,
    LCID lcid,
    DWORD dwFlags,
    DISPPARAMS __RPC_FAR *pDispParams,
    VARIANT __RPC_FAR *pVarResult,
    EXCEPINFO __RPC_FAR *pExcepInfo,
    UINT __RPC_FAR *pArgErr,
    UINT cVarRef,
    UINT __RPC_FAR *rgVarRefIdx,
    VARIANTARG __RPC_FAR *rgVarRef);

HRESULT STDMETHODCALLTYPE IEnumVARIANT_Next_Proxy( 
    IEnumVARIANT __RPC_FAR * This,
    ULONG celt,
    VARIANT __RPC_FAR *rgVar,
    ULONG __RPC_FAR *pCeltFetched);

HRESULT STDMETHODCALLTYPE IEnumVARIANT_Next_Stub( 
    IEnumVARIANT __RPC_FAR * This,
    ULONG celt,
    VARIANT __RPC_FAR *rgVar,
    ULONG __RPC_FAR *pCeltFetched);

HRESULT STDMETHODCALLTYPE ITypeComp_Bind_Proxy( 
    ITypeComp __RPC_FAR * This,
    LPOLESTR szName,
    ULONG lHashVal,
    WORD wFlags,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    DESCKIND __RPC_FAR *pDescKind,
    BINDPTR __RPC_FAR *pBindPtr);

HRESULT STDMETHODCALLTYPE ITypeComp_Bind_Stub( 
    ITypeComp __RPC_FAR * This,
	LPOLESTR szName,
    ULONG lHashVal,
    WORD wFlags,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    DESCKIND __RPC_FAR *pDescKind,
    LPFUNCDESC __RPC_FAR *ppFuncDesc,
    LPVARDESC __RPC_FAR *ppVarDesc,
    ITypeComp __RPC_FAR *__RPC_FAR *ppTypeComp,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

HRESULT STDMETHODCALLTYPE ITypeComp_BindType_Proxy( 
    ITypeComp __RPC_FAR * This,
    LPOLESTR szName,
    ULONG lHashVal,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    ITypeComp __RPC_FAR *__RPC_FAR *ppTComp);

HRESULT STDMETHODCALLTYPE ITypeComp_BindType_Stub( 
    ITypeComp __RPC_FAR * This,
    LPOLESTR szName,
    ULONG lHashVal,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetTypeAttr_Proxy( 
    ITypeInfo __RPC_FAR * This,
    TYPEATTR __RPC_FAR *__RPC_FAR *ppTypeAttr);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetTypeAttr_Stub( 
    ITypeInfo __RPC_FAR * This,
    LPTYPEATTR __RPC_FAR *ppTypeAttr,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetFuncDesc_Proxy( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    FUNCDESC __RPC_FAR *__RPC_FAR *ppFuncDesc);


HRESULT STDMETHODCALLTYPE ITypeInfo_GetFuncDesc_Stub( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    LPFUNCDESC __RPC_FAR *ppFuncDesc,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetVarDesc_Proxy( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    VARDESC __RPC_FAR *__RPC_FAR *ppVarDesc);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetVarDesc_Stub( 
    ITypeInfo __RPC_FAR * This,
    UINT index,
    LPVARDESC __RPC_FAR *ppVarDesc,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetNames_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    BSTR __RPC_FAR *rgBstrNames,
    UINT cMaxNames,
    UINT __RPC_FAR *pcNames);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetNames_Stub( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    BSTR __RPC_FAR *rgBstrNames,
    UINT cMaxNames,
    UINT __RPC_FAR *pcNames);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetIDsOfNames_Proxy( 
    ITypeInfo __RPC_FAR * This,
    LPOLESTR __RPC_FAR *rgszNames,
    UINT cNames,
    MEMBERID __RPC_FAR *pMemId);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetIDsOfNames_Stub( 
    ITypeInfo __RPC_FAR * This);

HRESULT STDMETHODCALLTYPE ITypeInfo_Invoke_Proxy( 
    ITypeInfo __RPC_FAR * This,
    PVOID pvInstance,
    MEMBERID memid,
    WORD wFlags,
    DISPPARAMS __RPC_FAR *pDispParams,
    VARIANT __RPC_FAR *pVarResult,
    EXCEPINFO __RPC_FAR *pExcepInfo,
    UINT __RPC_FAR *puArgErr);

HRESULT STDMETHODCALLTYPE ITypeInfo_Invoke_Stub( 
    ITypeInfo __RPC_FAR * This);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetDocumentation_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    BSTR __RPC_FAR *pBstrName,
    BSTR __RPC_FAR *pBstrDocString,
    DWORD __RPC_FAR *pdwHelpContext,
    BSTR __RPC_FAR *pBstrHelpFile);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetDocumentation_Stub( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pBstrName,
    BSTR __RPC_FAR *pBstrDocString,
    DWORD __RPC_FAR *pdwHelpContext,
    BSTR __RPC_FAR *pBstrHelpFile);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetDllEntry_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    INVOKEKIND invKind,
    BSTR __RPC_FAR *pBstrDllName,
    BSTR __RPC_FAR *pBstrName,
    WORD __RPC_FAR *pwOrdinal);


HRESULT STDMETHODCALLTYPE ITypeInfo_GetDllEntry_Stub( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    INVOKEKIND invKind,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pBstrDllName,
    BSTR __RPC_FAR *pBstrName,
    WORD __RPC_FAR *pwOrdinal);

HRESULT STDMETHODCALLTYPE ITypeInfo_AddressOfMember_Proxy( 
    ITypeInfo __RPC_FAR * This,
    MEMBERID memid,
    INVOKEKIND invKind,
    PVOID __RPC_FAR *ppv);

HRESULT STDMETHODCALLTYPE ITypeInfo_AddressOfMember_Stub( 
    ITypeInfo __RPC_FAR * This);

HRESULT STDMETHODCALLTYPE ITypeInfo_CreateInstance_Proxy( 
    ITypeInfo __RPC_FAR * This,
    IUnknown __RPC_FAR *pUnkOuter,
    REFIID riid,
    PVOID __RPC_FAR *ppvObj);

HRESULT STDMETHODCALLTYPE ITypeInfo_CreateInstance_Stub( 
    ITypeInfo __RPC_FAR * This,
    REFIID riid,
    IUnknown __RPC_FAR *__RPC_FAR *ppvObj);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetContainingTypeLib_Proxy( 
    ITypeInfo __RPC_FAR * This,
    ITypeLib __RPC_FAR *__RPC_FAR *ppTLib,
    UINT __RPC_FAR *pIndex);

HRESULT STDMETHODCALLTYPE ITypeInfo_GetContainingTypeLib_Stub( 
    ITypeInfo __RPC_FAR * This,
    ITypeLib __RPC_FAR *__RPC_FAR *ppTLib,
    UINT __RPC_FAR *pIndex);

void STDMETHODCALLTYPE ITypeInfo_ReleaseTypeAttr_Proxy( 
    ITypeInfo __RPC_FAR * This,
    TYPEATTR __RPC_FAR *pTypeAttr);

HRESULT STDMETHODCALLTYPE ITypeInfo_ReleaseTypeAttr_Stub( 
    ITypeInfo __RPC_FAR * This);

void STDMETHODCALLTYPE ITypeInfo_ReleaseFuncDesc_Proxy( 
    ITypeInfo __RPC_FAR * This,
    FUNCDESC __RPC_FAR *pFuncDesc);

HRESULT STDMETHODCALLTYPE ITypeInfo_ReleaseFuncDesc_Stub( 
    ITypeInfo __RPC_FAR * This);

void STDMETHODCALLTYPE ITypeInfo_ReleaseVarDesc_Proxy( 
    ITypeInfo __RPC_FAR * This,
    VARDESC __RPC_FAR *pVarDesc);

HRESULT STDMETHODCALLTYPE ITypeInfo_ReleaseVarDesc_Stub( 
    ITypeInfo __RPC_FAR * This);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetDocumentation2_Proxy( 
    ITypeInfo2 __RPC_FAR * This,
    MEMBERID memid,
    LCID lcid,
    BSTR __RPC_FAR *pbstrHelpString,
    DWORD __RPC_FAR *pdwHelpStringContext,
    BSTR __RPC_FAR *pbstrHelpStringDll);

HRESULT STDMETHODCALLTYPE ITypeInfo2_GetDocumentation2_Stub( 
    ITypeInfo2 __RPC_FAR * This,
    MEMBERID memid,
    LCID lcid,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pbstrHelpString,
    DWORD __RPC_FAR *pdwHelpStringContext,
    BSTR __RPC_FAR *pbstrHelpStringDll);

UINT STDMETHODCALLTYPE ITypeLib_GetTypeInfoCount_Proxy( 
    ITypeLib __RPC_FAR * This);

HRESULT STDMETHODCALLTYPE ITypeLib_GetTypeInfoCount_Stub( 
    ITypeLib __RPC_FAR * This,
    UINT __RPC_FAR *pcTInfo);

HRESULT STDMETHODCALLTYPE ITypeLib_GetLibAttr_Proxy( 
    ITypeLib __RPC_FAR * This,
    TLIBATTR __RPC_FAR *__RPC_FAR *ppTLibAttr);

HRESULT STDMETHODCALLTYPE ITypeLib_GetLibAttr_Stub( 
    ITypeLib __RPC_FAR * This,
    LPTLIBATTR __RPC_FAR *ppTLibAttr,
    CLEANLOCALSTORAGE __RPC_FAR *pDummy);

HRESULT STDMETHODCALLTYPE ITypeLib_GetDocumentation_Proxy( 
    ITypeLib __RPC_FAR * This,
    INT index,
    BSTR __RPC_FAR *pBstrName,
    BSTR __RPC_FAR *pBstrDocString,
    DWORD __RPC_FAR *pdwHelpContext,
    BSTR __RPC_FAR *pBstrHelpFile);

HRESULT STDMETHODCALLTYPE ITypeLib_GetDocumentation_Stub( 
    ITypeLib __RPC_FAR * This,
    INT index,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pBstrName,
    BSTR __RPC_FAR *pBstrDocString,
    DWORD __RPC_FAR *pdwHelpContext,
    BSTR __RPC_FAR *pBstrHelpFile);

HRESULT STDMETHODCALLTYPE ITypeLib_IsName_Proxy( 
    ITypeLib __RPC_FAR * This,
    LPOLESTR szNameBuf,
    ULONG lHashVal,
    BOOL __RPC_FAR *pfName);

HRESULT STDMETHODCALLTYPE ITypeLib_IsName_Stub( 
    ITypeLib __RPC_FAR * This,
    LPOLESTR szNameBuf,
    ULONG lHashVal,
    BOOL __RPC_FAR *pfName,
    BSTR __RPC_FAR *pBstrLibName);

HRESULT STDMETHODCALLTYPE ITypeLib_FindName_Proxy( 
    ITypeLib __RPC_FAR * This,
    LPOLESTR szNameBuf,
    ULONG lHashVal,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    MEMBERID __RPC_FAR *rgMemId,
    USHORT __RPC_FAR *pcFound);

HRESULT STDMETHODCALLTYPE ITypeLib_FindName_Stub( 
    ITypeLib __RPC_FAR * This,
    LPOLESTR szNameBuf,
    ULONG lHashVal,
    ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo,
    MEMBERID __RPC_FAR *rgMemId,
    USHORT __RPC_FAR *pcFound,
    BSTR __RPC_FAR *pBstrLibName);

void STDMETHODCALLTYPE ITypeLib_ReleaseTLibAttr_Proxy( 
    ITypeLib __RPC_FAR * This,
    TLIBATTR __RPC_FAR *pTLibAttr);

HRESULT STDMETHODCALLTYPE ITypeLib_ReleaseTLibAttr_Stub( 
    ITypeLib __RPC_FAR * This);

HRESULT STDMETHODCALLTYPE ITypeLib2_GetLibStatistics_Proxy( 
    ITypeLib2 __RPC_FAR * This,
    ULONG __RPC_FAR *pcUniqueNames,
    ULONG __RPC_FAR *pcchUniqueNames);

HRESULT STDMETHODCALLTYPE ITypeLib2_GetLibStatistics_Stub( 
    ITypeLib2 __RPC_FAR * This,
    ULONG __RPC_FAR *pcUniqueNames,
    ULONG __RPC_FAR *pcchUniqueNames);

HRESULT STDMETHODCALLTYPE ITypeLib2_GetDocumentation2_Proxy( 
    ITypeLib2 __RPC_FAR * This,
    INT index,
    LCID lcid,
    BSTR __RPC_FAR *pbstrHelpString,
    DWORD __RPC_FAR *pdwHelpStringContext,
    BSTR __RPC_FAR *pbstrHelpStringDll);

HRESULT STDMETHODCALLTYPE ITypeLib2_GetDocumentation2_Stub( 
    ITypeLib2 __RPC_FAR * This,
    INT index,
    LCID lcid,
    DWORD refPtrFlags,
    BSTR __RPC_FAR *pbstrHelpString,
    DWORD __RPC_FAR *pdwHelpStringContext,
    BSTR __RPC_FAR *pbstrHelpStringDll);

HRESULT STDMETHODCALLTYPE IPropertyBag_Read_Proxy( 
    IPropertyBag __RPC_FAR * This,
    LPCOLESTR pszPropName,
    VARIANT __RPC_FAR *pVar,
    IErrorLog __RPC_FAR *pErrorLog);

HRESULT STDMETHODCALLTYPE IPropertyBag_Read_Stub( 
    IPropertyBag __RPC_FAR * This,
    LPCOLESTR pszPropName,
    VARIANT __RPC_FAR *pVar,
    IErrorLog __RPC_FAR *pErrorLog,
    DWORD varType,
    IUnknown __RPC_FAR *pUnkObj);

#endif



