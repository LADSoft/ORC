/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#if !defined( RPC_NO_WINDOWS_H )
#include <windows.h>
#endif // RPC_NO_WINDOWS_H

#ifndef __RPC_H__
#define __RPC_H__

#pragma once

#include <basetsd.h>

#define __RPC_WIN32__
typedef void * I_RPC_HANDLE;
typedef long RPC_STATUS;

#if defined(__RPC_WIN32__))
#define RPC_UNICODE_SUPPORTED
#endif

#define __RPC_API  __stdcall
#define __RPC_USER __stdcall
#define __RPC_STUB __stdcall
#define  RPC_ENTRY __stdcall
#define __RPC_FAR

#if !defined(DECLSPEC_IMPORT)
#if (defined(_M_IX86) || defined(_M_PPC))
#define DECLSPEC_IMPORT __declspec(dllimport)
#else
#define DECLSPEC_IMPORT
#endif
#endif

#if !defined(_RPCRT4_)
#define RPCRTAPI DECLSPEC_IMPORT
#else
#define RPCRTAPI
#endif

#if !defined(_RPCNS4_)
#define RPCNSAPI DECLSPEC_IMPORT
#else
#define RPCNSAPI
#endif

#include <rpcdce.h>
#include <rpcnsi.h>
#include <rpcnterr.h>
#include <excpt.h>
#include <winerror.h>

#define RpcTryExcept \
    __try \
        {

#define RpcExcept(expr) \
        } \
    __except (expr) \
        {

#define RpcEndExcept \
        }

#define RpcTryFinally \
    __try \
        {

#define RpcFinally \
        } \
    __finally \
        {

#define RpcEndFinally \
        }

#define RpcExceptionCode() GetExceptionCode()
#define RpcAbnormalTermination() AbnormalTermination()

#if !defined( RPC_NO_WINDOWS_H ) && !defined(__RPC_MAC__)

#include <rpcasync.h>

#endif // RPC_NO_WINDOWS_H

#endif // __RPC_H__


