/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#if defined(RC_INVOKED)
#pragma pack(push,4)
#endif // defined(RC_INVOKED))

