/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#pragma warning( disable: 4049 )

#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __propidl_h__
#define __propidl_h__

#ifndef __IPropertyStorage_FWD_DEFINED__
#define __IPropertyStorage_FWD_DEFINED__
typedef interface IPropertyStorage IPropertyStorage;
#endif 	/* __IPropertyStorage_FWD_DEFINED__ */

#ifndef __IPropertySetStorage_FWD_DEFINED__
#define __IPropertySetStorage_FWD_DEFINED__
typedef interface IPropertySetStorage IPropertySetStorage;
#endif 	/* __IPropertySetStorage_FWD_DEFINED__ */

#ifndef __IEnumSTATPROPSTG_FWD_DEFINED__
#define __IEnumSTATPROPSTG_FWD_DEFINED__
typedef interface IEnumSTATPROPSTG IEnumSTATPROPSTG;
#endif 	/* __IEnumSTATPROPSTG_FWD_DEFINED__ */

#ifndef __IEnumSTATPROPSETSTG_FWD_DEFINED__
#define __IEnumSTATPROPSETSTG_FWD_DEFINED__
typedef interface IEnumSTATPROPSETSTG IEnumSTATPROPSETSTG;
#endif 	/* __IEnumSTATPROPSETSTG_FWD_DEFINED__ */

#include "objidl.h"
#include "oaidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#if ( _MSC_VER >= 800 )
#if _MSC_VER >= 1200
#pragma warning(push)
#endif
#pragma warning(disable:4201)
#pragma warning(disable:4237)
#endif
#if ( _MSC_VER >= 1020 )
#pragma once
#endif

typedef struct tagVersionedStream
    {
    GUID guidVersion;
    IStream __RPC_FAR *pStream;
    }	VERSIONEDSTREAM;

typedef struct tagVersionedStream __RPC_FAR *LPVERSIONEDSTREAM;

#define	PROPSETFLAG_DEFAULT	( 0 )
#define	PROPSETFLAG_NONSIMPLE	( 1 )
#define	PROPSETFLAG_ANSI	( 2 )
#define	PROPSETFLAG_UNBUFFERED	( 4 )
#define	PROPSETFLAG_CASE_SENSITIVE	( 8 )
#define	PROPSET_BEHAVIOR_CASE_SENSITIVE	( 1 )

#ifdef MIDL_PASS
typedef struct tag_inner_PROPVARIANT PROPVARIANT;
#else
typedef struct tagPROPVARIANT PROPVARIANT;
#endif

typedef struct tagCAC
    {
    ULONG cElems;
    CHAR __RPC_FAR *pElems;
    }	CAC;

typedef struct tagCAUB
    {
    ULONG cElems;
    UCHAR __RPC_FAR *pElems;
    }	CAUB;

typedef struct tagCAI
    {
    ULONG cElems;
    SHORT __RPC_FAR *pElems;
    }	CAI;

typedef struct tagCAUI
    {
    ULONG cElems;
    USHORT __RPC_FAR *pElems;
    }	CAUI;

typedef struct tagCAL
    {
    ULONG cElems;
    LONG __RPC_FAR *pElems;
    }	CAL;

typedef struct tagCAUL
    {
    ULONG cElems;
    ULONG __RPC_FAR *pElems;
    }	CAUL;

typedef struct tagCAFLT
    {
    ULONG cElems;
    FLOAT __RPC_FAR *pElems;
    }	CAFLT;

typedef struct tagCADBL
    {
    ULONG cElems;
    DOUBLE __RPC_FAR *pElems;
    }	CADBL;

typedef struct tagCACY
    {
    ULONG cElems;
    CY __RPC_FAR *pElems;
    }	CACY;

typedef struct tagCADATE
    {
    ULONG cElems;
    DATE __RPC_FAR *pElems;
    }	CADATE;

typedef struct tagCABSTR
    {
    ULONG cElems;
    BSTR __RPC_FAR *pElems;
    }	CABSTR;

typedef struct tagCABSTRBLOB
    {
    ULONG cElems;
    BSTRBLOB __RPC_FAR *pElems;
    }	CABSTRBLOB;

typedef struct tagCABOOL
    {
    ULONG cElems;
    VARIANT_BOOL __RPC_FAR *pElems;
    }	CABOOL;

typedef struct tagCASCODE
    {
    ULONG cElems;
    SCODE __RPC_FAR *pElems;
    }	CASCODE;

typedef struct tagCAPROPVARIANT
    {
    ULONG cElems;
    PROPVARIANT __RPC_FAR *pElems;
    }	CAPROPVARIANT;

typedef struct tagCAH
    {
    ULONG cElems;
    LARGE_INTEGER __RPC_FAR *pElems;
    }	CAH;

typedef struct tagCAUH
    {
    ULONG cElems;
    ULARGE_INTEGER __RPC_FAR *pElems;
    }	CAUH;

typedef struct tagCALPSTR
    {
    ULONG cElems;
    LPSTR __RPC_FAR *pElems;
    }	CALPSTR;

typedef struct tagCALPWSTR
    {
    ULONG cElems;
    LPWSTR __RPC_FAR *pElems;
    }	CALPWSTR;

typedef struct tagCAFILETIME
    {
    ULONG cElems;
    FILETIME __RPC_FAR *pElems;
    }	CAFILETIME;

typedef struct tagCACLIPDATA
    {
    ULONG cElems;
    CLIPDATA __RPC_FAR *pElems;
    }	CACLIPDATA;

typedef struct tagCACLSID
    {
    ULONG cElems;
    CLSID __RPC_FAR *pElems;
    }	CACLSID;

#ifdef MIDL_PASS
typedef BYTE PROPVAR_PAD1;
typedef BYTE PROPVAR_PAD2;
typedef ULONG PROPVAR_PAD3;
#else
typedef WORD PROPVAR_PAD1;
typedef WORD PROPVAR_PAD2;
typedef WORD PROPVAR_PAD3;
#define tag_inner_PROPVARIANT
#endif
#ifndef MIDL_PASS
struct tagPROPVARIANT {
  union {
#endif

struct tag_inner_PROPVARIANT
    {
    VARTYPE vt;
    PROPVAR_PAD1 wReserved1;
    PROPVAR_PAD2 wReserved2;
    PROPVAR_PAD3 wReserved3;
    union 
        {
        CHAR cVal;
        UCHAR bVal;
        SHORT iVal;
        USHORT uiVal;
        LONG lVal;
        ULONG ulVal;
        INT intVal;
        UINT uintVal;
        LARGE_INTEGER hVal;
        ULARGE_INTEGER uhVal;
        FLOAT fltVal;
        DOUBLE dblVal;
        VARIANT_BOOL boolVal;
        VARIANT_BOOL bool;
        SCODE scode;
        CY cyVal;
        DATE date;
        FILETIME filetime;
        CLSID __RPC_FAR *puuid;
        CLIPDATA __RPC_FAR *pclipdata;
        BSTR bstrVal;
        BSTRBLOB bstrblobVal;
        BLOB blob;
        LPSTR pszVal;
        LPWSTR pwszVal;
        IUnknown __RPC_FAR *punkVal;
        IDispatch __RPC_FAR *pdispVal;
        IStream __RPC_FAR *pStream;
        IStorage __RPC_FAR *pStorage;
        LPVERSIONEDSTREAM pVersionedStream;
        LPSAFEARRAY parray;
        CAC cac;
        CAUB caub;
        CAI cai;
        CAUI caui;
        CAL cal;
        CAUL caul;
        CAH cah;
        CAUH cauh;
        CAFLT caflt;
        CADBL cadbl;
        CABOOL cabool;
        CASCODE cascode;
        CACY cacy;
        CADATE cadate;
        CAFILETIME cafiletime;
        CACLSID cauuid;
        CACLIPDATA caclipdata;
        CABSTR cabstr;
        CABSTRBLOB cabstrblob;
        CALPSTR calpstr;
        CALPWSTR calpwstr;
        CAPROPVARIANT capropvar;
        CHAR __RPC_FAR *pcVal;
        UCHAR __RPC_FAR *pbVal;
        SHORT __RPC_FAR *piVal;
        USHORT __RPC_FAR *puiVal;
        LONG __RPC_FAR *plVal;
        ULONG __RPC_FAR *pulVal;
        INT __RPC_FAR *pintVal;
        UINT __RPC_FAR *puintVal;
        FLOAT __RPC_FAR *pfltVal;
        DOUBLE __RPC_FAR *pdblVal;
        VARIANT_BOOL __RPC_FAR *pboolVal;
        DECIMAL __RPC_FAR *pdecVal;
        SCODE __RPC_FAR *pscode;
        CY __RPC_FAR *pcyVal;
        DATE __RPC_FAR *pdate;
        BSTR __RPC_FAR *pbstrVal;
        IUnknown __RPC_FAR *__RPC_FAR *ppunkVal;
        IDispatch __RPC_FAR *__RPC_FAR *ppdispVal;
        LPSAFEARRAY __RPC_FAR *pparray;
        PROPVARIANT __RPC_FAR *pvarVal;
        }	;
    };
#ifndef MIDL_PASS
    DECIMAL decVal;
  };
};
#endif
#ifdef MIDL_PASS
typedef struct tag_inner_PROPVARIANT __RPC_FAR *LPPROPVARIANT;
#else
typedef struct tagPROPVARIANT * LPPROPVARIANT;
#endif

#define	PID_DICTIONARY	( 0 )
#define	PID_CODEPAGE	( 0x1 )
#define	PID_FIRST_USABLE	( 0x2 )
#define	PID_FIRST_NAME_DEFAULT	( 0xfff )
#define	PID_LOCALE	( 0x80000000 )
#define	PID_MODIFY_TIME	( 0x80000001 )
#define	PID_SECURITY	( 0x80000002 )
#define	PID_BEHAVIOR	( 0x80000003 )
#define	PID_ILLEGAL	( 0xffffffff )
#define	PID_MIN_READONLY	( 0x80000000 )
#define	PID_MAX_READONLY	( 0xbfffffff )
#define PIDDI_THUMBNAIL          0x00000002L
#define PIDSI_TITLE               0x00000002L
#define PIDSI_SUBJECT             0x00000003L
#define PIDSI_AUTHOR              0x00000004L
#define PIDSI_KEYWORDS            0x00000005L
#define PIDSI_COMMENTS            0x00000006L
#define PIDSI_TEMPLATE            0x00000007L
#define PIDSI_LASTAUTHOR          0x00000008L
#define PIDSI_REVNUMBER           0x00000009L
#define PIDSI_EDITTIME            0x0000000aL
#define PIDSI_LASTPRINTED         0x0000000bL
#define PIDSI_CREATE_DTM          0x0000000cL
#define PIDSI_LASTSAVE_DTM        0x0000000dL
#define PIDSI_PAGECOUNT           0x0000000eL
#define PIDSI_WORDCOUNT           0x0000000fL
#define PIDSI_CHARCOUNT           0x00000010L
#define PIDSI_THUMBNAIL           0x00000011L
#define PIDSI_APPNAME             0x00000012L
#define PIDSI_DOC_SECURITY        0x00000013L
#define PIDDSI_CATEGORY          0x00000002
#define PIDDSI_PRESFORMAT        0x00000003
#define PIDDSI_BYTECOUNT         0x00000004
#define PIDDSI_LINECOUNT         0x00000005
#define PIDDSI_PARCOUNT          0x00000006
#define PIDDSI_SLIDECOUNT        0x00000007
#define PIDDSI_NOTECOUNT         0x00000008
#define PIDDSI_HIDDENCOUNT       0x00000009
#define PIDDSI_MMCLIPCOUNT       0x0000000A
#define PIDDSI_SCALE             0x0000000B
#define PIDDSI_HEADINGPAIR       0x0000000C
#define PIDDSI_DOCPARTS          0x0000000D
#define PIDDSI_MANAGER           0x0000000E
#define PIDDSI_COMPANY           0x0000000F
#define PIDDSI_LINKSDIRTY        0x00000010
#define PIDMSI_EDITOR                   0x00000002L
#define PIDMSI_SUPPLIER                 0x00000003L
#define PIDMSI_SOURCE                   0x00000004L
#define PIDMSI_SEQUENCE_NO              0x00000005L
#define PIDMSI_PROJECT                  0x00000006L
#define PIDMSI_STATUS                   0x00000007L
#define PIDMSI_OWNER                    0x00000008L
#define PIDMSI_RATING                   0x00000009L
#define PIDMSI_PRODUCTION               0x0000000AL
#define PIDMSI_COPYRIGHT                0x0000000BL

enum PIDMSI_STATUS_VALUE
    {	PIDMSI_STATUS_NORMAL	= 0,
	PIDMSI_STATUS_NEW	= PIDMSI_STATUS_NORMAL + 1,
	PIDMSI_STATUS_PRELIM	= PIDMSI_STATUS_NEW + 1,
	PIDMSI_STATUS_DRAFT	= PIDMSI_STATUS_PRELIM + 1,
	PIDMSI_STATUS_INPROGRESS	= PIDMSI_STATUS_DRAFT + 1,
	PIDMSI_STATUS_EDIT	= PIDMSI_STATUS_INPROGRESS + 1,
	PIDMSI_STATUS_REVIEW	= PIDMSI_STATUS_EDIT + 1,
	PIDMSI_STATUS_PROOF	= PIDMSI_STATUS_REVIEW + 1,
	PIDMSI_STATUS_FINAL	= PIDMSI_STATUS_PROOF + 1,
	PIDMSI_STATUS_OTHER	= 0x7fff
    };
#define	PRSPEC_INVALID	( 0xffffffff )
#define	PRSPEC_LPWSTR	( 0 )
#define	PRSPEC_PROPID	( 1 )

typedef struct tagPROPSPEC
    {
    ULONG ulKind;
    union 
        {
        PROPID propid;
        LPOLESTR lpwstr;
        }	;
    }	PROPSPEC;

typedef struct tagSTATPROPSTG
    {
    LPOLESTR lpwstrName;
    PROPID propid;
    VARTYPE vt;
    }	STATPROPSTG;

#define PROPSETHDR_OSVER_KIND(dwOSVer)      HIWORD( (dwOSVer) )
#define PROPSETHDR_OSVER_MAJOR(dwOSVer)     LOBYTE(LOWORD( (dwOSVer) ))
#define PROPSETHDR_OSVER_MINOR(dwOSVer)     HIBYTE(LOWORD( (dwOSVer) ))
#define PROPSETHDR_OSVERSION_UNKNOWN        0xFFFFFFFF
typedef struct tagSTATPROPSETSTG
    {
    FMTID fmtid;
    CLSID clsid;
    DWORD grfFlags;
    FILETIME mtime;
    FILETIME ctime;
    FILETIME atime;
    DWORD dwOSVersion;
    }	STATPROPSETSTG;

extern RPC_IF_HANDLE __MIDL_itf_propidl_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_propidl_0000_v0_0_s_ifspec;

#ifndef __IPropertyStorage_INTERFACE_DEFINED__
#define __IPropertyStorage_INTERFACE_DEFINED__

EXTERN_C const IID IID_IPropertyStorage;

    typedef struct IPropertyStorageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPropertyStorage __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPropertyStorage __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPropertyStorage __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadMultiple )( 
            IPropertyStorage __RPC_FAR * This,
            ULONG cpspec,
            const PROPSPEC __RPC_FAR rgpspec[  ],
            PROPVARIANT __RPC_FAR rgpropvar[  ]);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteMultiple )( 
            IPropertyStorage __RPC_FAR * This,
            ULONG cpspec,
            const PROPSPEC __RPC_FAR rgpspec[  ],
            const PROPVARIANT __RPC_FAR rgpropvar[  ],
            PROPID propidNameFirst);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeleteMultiple )( 
            IPropertyStorage __RPC_FAR * This,
            ULONG cpspec,
            const PROPSPEC __RPC_FAR rgpspec[  ]);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadPropertyNames )( 
            IPropertyStorage __RPC_FAR * This,
            ULONG cpropid,
            const PROPID __RPC_FAR rgpropid[  ],
            LPOLESTR __RPC_FAR rglpwstrName[  ]);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WritePropertyNames )( 
            IPropertyStorage __RPC_FAR * This,
            ULONG cpropid,
            const PROPID __RPC_FAR rgpropid[  ],
            const LPOLESTR __RPC_FAR rglpwstrName[  ]);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeletePropertyNames )( 
            IPropertyStorage __RPC_FAR * This,
            ULONG cpropid,
            const PROPID __RPC_FAR rgpropid[  ]);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Commit )( 
            IPropertyStorage __RPC_FAR * This,
            DWORD grfCommitFlags);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Revert )( 
            IPropertyStorage __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Enum )( 
            IPropertyStorage __RPC_FAR * This,
            IEnumSTATPROPSTG __RPC_FAR *__RPC_FAR *ppenum);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTimes )( 
            IPropertyStorage __RPC_FAR * This,
            const FILETIME __RPC_FAR *pctime,
            const FILETIME __RPC_FAR *patime,
            const FILETIME __RPC_FAR *pmtime);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClass )( 
            IPropertyStorage __RPC_FAR * This,
            REFCLSID clsid);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Stat )( 
            IPropertyStorage __RPC_FAR * This,
            STATPROPSETSTG __RPC_FAR *pstatpsstg);
        
        END_INTERFACE
    } IPropertyStorageVtbl;

    interface IPropertyStorage
    {
        CONST_VTBL struct IPropertyStorageVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IPropertyStorage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPropertyStorage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPropertyStorage_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IPropertyStorage_ReadMultiple(This,cpspec,rgpspec,rgpropvar)	\
    (This)->lpVtbl -> ReadMultiple(This,cpspec,rgpspec,rgpropvar)

#define IPropertyStorage_WriteMultiple(This,cpspec,rgpspec,rgpropvar,propidNameFirst)	\
    (This)->lpVtbl -> WriteMultiple(This,cpspec,rgpspec,rgpropvar,propidNameFirst)

#define IPropertyStorage_DeleteMultiple(This,cpspec,rgpspec)	\
    (This)->lpVtbl -> DeleteMultiple(This,cpspec,rgpspec)

#define IPropertyStorage_ReadPropertyNames(This,cpropid,rgpropid,rglpwstrName)	\
    (This)->lpVtbl -> ReadPropertyNames(This,cpropid,rgpropid,rglpwstrName)

#define IPropertyStorage_WritePropertyNames(This,cpropid,rgpropid,rglpwstrName)	\
    (This)->lpVtbl -> WritePropertyNames(This,cpropid,rgpropid,rglpwstrName)

#define IPropertyStorage_DeletePropertyNames(This,cpropid,rgpropid)	\
    (This)->lpVtbl -> DeletePropertyNames(This,cpropid,rgpropid)

#define IPropertyStorage_Commit(This,grfCommitFlags)	\
    (This)->lpVtbl -> Commit(This,grfCommitFlags)

#define IPropertyStorage_Revert(This)	\
    (This)->lpVtbl -> Revert(This)

#define IPropertyStorage_Enum(This,ppenum)	\
    (This)->lpVtbl -> Enum(This,ppenum)

#define IPropertyStorage_SetTimes(This,pctime,patime,pmtime)	\
    (This)->lpVtbl -> SetTimes(This,pctime,patime,pmtime)

#define IPropertyStorage_SetClass(This,clsid)	\
    (This)->lpVtbl -> SetClass(This,clsid)

#define IPropertyStorage_Stat(This,pstatpsstg)	\
    (This)->lpVtbl -> Stat(This,pstatpsstg)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IPropertyStorage_ReadMultiple_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    ULONG cpspec,
    const PROPSPEC __RPC_FAR rgpspec[  ],
    PROPVARIANT __RPC_FAR rgpropvar[  ]);

void __RPC_STUB IPropertyStorage_ReadMultiple_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_WriteMultiple_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    ULONG cpspec,
    const PROPSPEC __RPC_FAR rgpspec[  ],
    const PROPVARIANT __RPC_FAR rgpropvar[  ],
    PROPID propidNameFirst);

void __RPC_STUB IPropertyStorage_WriteMultiple_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_DeleteMultiple_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    ULONG cpspec,
    const PROPSPEC __RPC_FAR rgpspec[  ]);

void __RPC_STUB IPropertyStorage_DeleteMultiple_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_ReadPropertyNames_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    ULONG cpropid,
    const PROPID __RPC_FAR rgpropid[  ],
    LPOLESTR __RPC_FAR rglpwstrName[  ]);

void __RPC_STUB IPropertyStorage_ReadPropertyNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_WritePropertyNames_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    ULONG cpropid,
    const PROPID __RPC_FAR rgpropid[  ],
    const LPOLESTR __RPC_FAR rglpwstrName[  ]);

void __RPC_STUB IPropertyStorage_WritePropertyNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_DeletePropertyNames_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    ULONG cpropid,
    const PROPID __RPC_FAR rgpropid[  ]);

void __RPC_STUB IPropertyStorage_DeletePropertyNames_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_Commit_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    DWORD grfCommitFlags);

void __RPC_STUB IPropertyStorage_Commit_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_Revert_Proxy( 
    IPropertyStorage __RPC_FAR * This);

void __RPC_STUB IPropertyStorage_Revert_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_Enum_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    IEnumSTATPROPSTG __RPC_FAR *__RPC_FAR *ppenum);

void __RPC_STUB IPropertyStorage_Enum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_SetTimes_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    const FILETIME __RPC_FAR *pctime,
    const FILETIME __RPC_FAR *patime,
    const FILETIME __RPC_FAR *pmtime);

void __RPC_STUB IPropertyStorage_SetTimes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_SetClass_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    REFCLSID clsid);

void __RPC_STUB IPropertyStorage_SetClass_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertyStorage_Stat_Proxy( 
    IPropertyStorage __RPC_FAR * This,
    STATPROPSETSTG __RPC_FAR *pstatpsstg);

void __RPC_STUB IPropertyStorage_Stat_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IPropertyStorage_INTERFACE_DEFINED__ */

#ifndef __IPropertySetStorage_INTERFACE_DEFINED__
#define __IPropertySetStorage_INTERFACE_DEFINED__

typedef IPropertySetStorage __RPC_FAR *LPPROPERTYSETSTORAGE;

EXTERN_C const IID IID_IPropertySetStorage;

    typedef struct IPropertySetStorageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IPropertySetStorage __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IPropertySetStorage __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IPropertySetStorage __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Create )( 
            IPropertySetStorage __RPC_FAR * This,
            REFFMTID rfmtid,
            const CLSID __RPC_FAR *pclsid,
            DWORD grfFlags,
            DWORD grfMode,
            IPropertyStorage __RPC_FAR *__RPC_FAR *ppprstg);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Open )( 
            IPropertySetStorage __RPC_FAR * This,
            REFFMTID rfmtid,
            DWORD grfMode,
            IPropertyStorage __RPC_FAR *__RPC_FAR *ppprstg);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Delete )( 
            IPropertySetStorage __RPC_FAR * This,
            REFFMTID rfmtid);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Enum )( 
            IPropertySetStorage __RPC_FAR * This,
            IEnumSTATPROPSETSTG __RPC_FAR *__RPC_FAR *ppenum);
        
        END_INTERFACE
    } IPropertySetStorageVtbl;

    interface IPropertySetStorage
    {
        CONST_VTBL struct IPropertySetStorageVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IPropertySetStorage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IPropertySetStorage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IPropertySetStorage_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IPropertySetStorage_Create(This,rfmtid,pclsid,grfFlags,grfMode,ppprstg)	\
    (This)->lpVtbl -> Create(This,rfmtid,pclsid,grfFlags,grfMode,ppprstg)

#define IPropertySetStorage_Open(This,rfmtid,grfMode,ppprstg)	\
    (This)->lpVtbl -> Open(This,rfmtid,grfMode,ppprstg)

#define IPropertySetStorage_Delete(This,rfmtid)	\
    (This)->lpVtbl -> Delete(This,rfmtid)

#define IPropertySetStorage_Enum(This,ppenum)	\
    (This)->lpVtbl -> Enum(This,ppenum)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IPropertySetStorage_Create_Proxy( 
    IPropertySetStorage __RPC_FAR * This,
    REFFMTID rfmtid,
    const CLSID __RPC_FAR *pclsid,
    DWORD grfFlags,
    DWORD grfMode,
    IPropertyStorage __RPC_FAR *__RPC_FAR *ppprstg);

void __RPC_STUB IPropertySetStorage_Create_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertySetStorage_Open_Proxy( 
    IPropertySetStorage __RPC_FAR * This,
    REFFMTID rfmtid,
    DWORD grfMode,
    IPropertyStorage __RPC_FAR *__RPC_FAR *ppprstg);

void __RPC_STUB IPropertySetStorage_Open_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertySetStorage_Delete_Proxy( 
    IPropertySetStorage __RPC_FAR * This,
    REFFMTID rfmtid);

void __RPC_STUB IPropertySetStorage_Delete_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IPropertySetStorage_Enum_Proxy( 
    IPropertySetStorage __RPC_FAR * This,
    IEnumSTATPROPSETSTG __RPC_FAR *__RPC_FAR *ppenum);

void __RPC_STUB IPropertySetStorage_Enum_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IPropertySetStorage_INTERFACE_DEFINED__ */

#ifndef __IEnumSTATPROPSTG_INTERFACE_DEFINED__
#define __IEnumSTATPROPSTG_INTERFACE_DEFINED__

typedef IEnumSTATPROPSTG __RPC_FAR *LPENUMSTATPROPSTG;

EXTERN_C const IID IID_IEnumSTATPROPSTG;

    typedef struct IEnumSTATPROPSTGVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IEnumSTATPROPSTG __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IEnumSTATPROPSTG __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IEnumSTATPROPSTG __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Next )( 
            IEnumSTATPROPSTG __RPC_FAR * This,
            ULONG celt,
            STATPROPSTG __RPC_FAR *rgelt,
            ULONG __RPC_FAR *pceltFetched);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Skip )( 
            IEnumSTATPROPSTG __RPC_FAR * This,
            ULONG celt);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Reset )( 
            IEnumSTATPROPSTG __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clone )( 
            IEnumSTATPROPSTG __RPC_FAR * This,
            IEnumSTATPROPSTG __RPC_FAR *__RPC_FAR *ppenum);
        
        END_INTERFACE
    } IEnumSTATPROPSTGVtbl;

    interface IEnumSTATPROPSTG
    {
        CONST_VTBL struct IEnumSTATPROPSTGVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IEnumSTATPROPSTG_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEnumSTATPROPSTG_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEnumSTATPROPSTG_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IEnumSTATPROPSTG_Next(This,celt,rgelt,pceltFetched)	\
    (This)->lpVtbl -> Next(This,celt,rgelt,pceltFetched)

#define IEnumSTATPROPSTG_Skip(This,celt)	\
    (This)->lpVtbl -> Skip(This,celt)

#define IEnumSTATPROPSTG_Reset(This)	\
    (This)->lpVtbl -> Reset(This)

#define IEnumSTATPROPSTG_Clone(This,ppenum)	\
    (This)->lpVtbl -> Clone(This,ppenum)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSTG_RemoteNext_Proxy( 
    IEnumSTATPROPSTG __RPC_FAR * This,
    ULONG celt,
    STATPROPSTG __RPC_FAR *rgelt,
    ULONG __RPC_FAR *pceltFetched);

void __RPC_STUB IEnumSTATPROPSTG_RemoteNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSTG_Skip_Proxy( 
    IEnumSTATPROPSTG __RPC_FAR * This,
    ULONG celt);

void __RPC_STUB IEnumSTATPROPSTG_Skip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSTG_Reset_Proxy( 
    IEnumSTATPROPSTG __RPC_FAR * This);

void __RPC_STUB IEnumSTATPROPSTG_Reset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSTG_Clone_Proxy( 
    IEnumSTATPROPSTG __RPC_FAR * This,
    IEnumSTATPROPSTG __RPC_FAR *__RPC_FAR *ppenum);

void __RPC_STUB IEnumSTATPROPSTG_Clone_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IEnumSTATPROPSTG_INTERFACE_DEFINED__ */

#ifndef __IEnumSTATPROPSETSTG_INTERFACE_DEFINED__
#define __IEnumSTATPROPSETSTG_INTERFACE_DEFINED__

typedef IEnumSTATPROPSETSTG __RPC_FAR *LPENUMSTATPROPSETSTG;

EXTERN_C const IID IID_IEnumSTATPROPSETSTG;

    typedef struct IEnumSTATPROPSETSTGVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This,
            REFIID riid,
            void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Next )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This,
            ULONG celt,
            STATPROPSETSTG __RPC_FAR *rgelt,
            ULONG __RPC_FAR *pceltFetched);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Skip )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This,
            ULONG celt);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Reset )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clone )( 
            IEnumSTATPROPSETSTG __RPC_FAR * This,
            IEnumSTATPROPSETSTG __RPC_FAR *__RPC_FAR *ppenum);
        
        END_INTERFACE
    } IEnumSTATPROPSETSTGVtbl;

    interface IEnumSTATPROPSETSTG
    {
        CONST_VTBL struct IEnumSTATPROPSETSTGVtbl __RPC_FAR *lpVtbl;
    };

#ifdef COBJMACROS

#define IEnumSTATPROPSETSTG_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEnumSTATPROPSETSTG_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEnumSTATPROPSETSTG_Release(This)	\
    (This)->lpVtbl -> Release(This)

#define IEnumSTATPROPSETSTG_Next(This,celt,rgelt,pceltFetched)	\
    (This)->lpVtbl -> Next(This,celt,rgelt,pceltFetched)

#define IEnumSTATPROPSETSTG_Skip(This,celt)	\
    (This)->lpVtbl -> Skip(This,celt)

#define IEnumSTATPROPSETSTG_Reset(This)	\
    (This)->lpVtbl -> Reset(This)

#define IEnumSTATPROPSETSTG_Clone(This,ppenum)	\
    (This)->lpVtbl -> Clone(This,ppenum)

#endif /* COBJMACROS */

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSETSTG_RemoteNext_Proxy( 
    IEnumSTATPROPSETSTG __RPC_FAR * This,
    ULONG celt,
    STATPROPSETSTG __RPC_FAR *rgelt,
    ULONG __RPC_FAR *pceltFetched);

void __RPC_STUB IEnumSTATPROPSETSTG_RemoteNext_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSETSTG_Skip_Proxy( 
    IEnumSTATPROPSETSTG __RPC_FAR * This,
    ULONG celt);

void __RPC_STUB IEnumSTATPROPSETSTG_Skip_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSETSTG_Reset_Proxy( 
    IEnumSTATPROPSETSTG __RPC_FAR * This);

void __RPC_STUB IEnumSTATPROPSETSTG_Reset_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSETSTG_Clone_Proxy( 
    IEnumSTATPROPSETSTG __RPC_FAR * This,
    IEnumSTATPROPSETSTG __RPC_FAR *__RPC_FAR *ppenum);

void __RPC_STUB IEnumSTATPROPSETSTG_Clone_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);

#endif 	/* __IEnumSTATPROPSETSTG_INTERFACE_DEFINED__ */

typedef IPropertyStorage __RPC_FAR *LPPROPERTYSTORAGE;

WINOLEAPI PropVariantCopy ( PROPVARIANT * pvarDest, const PROPVARIANT * pvarSrc );
WINOLEAPI PropVariantClear ( PROPVARIANT * pvar );
WINOLEAPI FreePropVariantArray ( ULONG cVariants, PROPVARIANT * rgvars );

#define _PROPVARIANTINIT_DEFINED_
#define PropVariantInit(pvar) memset ( (pvar), 0, sizeof(PROPVARIANT) )

#ifndef _STGCREATEPROPSTG_DEFINED_
WINOLEAPI StgCreatePropStg( IUnknown* pUnk, REFFMTID fmtid, const CLSID *pclsid, DWORD grfFlags, DWORD dwReserved, IPropertyStorage **ppPropStg );
WINOLEAPI StgOpenPropStg( IUnknown* pUnk, REFFMTID fmtid, DWORD grfFlags, DWORD dwReserved, IPropertyStorage **ppPropStg );
WINOLEAPI StgCreatePropSetStg( IStorage *pStorage, DWORD dwReserved, IPropertySetStorage **ppPropSetStg);

#define CCH_MAX_PROPSTG_NAME    31
WINOLEAPI FmtIdToPropStgName( const FMTID *pfmtid, LPOLESTR oszName );
WINOLEAPI PropStgNameToFmtId( const LPOLESTR oszName, FMTID *pfmtid );
#endif

#if _MSC_VER >= 1200
#pragma warning(pop)
#else
#pragma warning(default:4201)
#pragma warning(default:4237)
#endif

extern RPC_IF_HANDLE __MIDL_itf_propidl_0109_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_propidl_0109_v0_0_s_ifspec;

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long __RPC_FAR *, unsigned long            , LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSTG_Next_Proxy( 
    IEnumSTATPROPSTG __RPC_FAR * This,
    ULONG celt,
    STATPROPSTG __RPC_FAR *rgelt,
    ULONG __RPC_FAR *pceltFetched);


HRESULT STDMETHODCALLTYPE IEnumSTATPROPSTG_Next_Stub( 
    IEnumSTATPROPSTG __RPC_FAR * This,
    ULONG celt,
    STATPROPSTG __RPC_FAR *rgelt,
    ULONG __RPC_FAR *pceltFetched);

HRESULT STDMETHODCALLTYPE IEnumSTATPROPSETSTG_Next_Proxy( 
    IEnumSTATPROPSETSTG __RPC_FAR * This,
    ULONG celt,
    STATPROPSETSTG __RPC_FAR *rgelt,
    ULONG __RPC_FAR *pceltFetched);


HRESULT STDMETHODCALLTYPE IEnumSTATPROPSETSTG_Next_Stub( 
    IEnumSTATPROPSETSTG __RPC_FAR * This,
    ULONG celt,
    STATPROPSETSTG __RPC_FAR *rgelt,
    ULONG __RPC_FAR *pceltFetched);

#endif



