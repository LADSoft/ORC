/* 
 * This file is adapted to be compatible with
 * wcc32 C compiler and Windows 32 bit.
 */

#define RESTRICTED_POINTER
#define UNALIGNED
#define UNALIGNED64
#define MAX_NATURAL_ALIGNMENT sizeof(DWORD)

#define PROBE_ALIGNMENT( _s ) TYPE_ALIGNMENT( DWORD )
#define C_ASSERT(e) typedef char __C_ASSERT__[(e)?1:-1]
#define POINTER_64
#define POINTER_32
#define FIRMWARE_PTR POINTER_32

#include <basetsd.h>

#define DECLSPEC_IMPORT     __declspec(dllimport)

#define DECLSPEC_NORETURN
#define DECLSPEC_ALIGN(x)
#define DECLSPEC_UUID(x)
#define DECLSPEC_NOVTABLE
#define DECLSPEC_SELECTANY
#define NOP_FUNCTION (void)0
#define DECLSPEC_ADDRSAFE
#define FORCEINLINE __inline

typedef void *PVOID;
typedef void * POINTER_64 PVOID64;

#define NTAPI __stdcall

#define NTSYSAPI     DECLSPEC_IMPORT
#define NTSYSCALLAPI DECLSPEC_IMPORT
