#define IDR_ICO_MAIN			2
#define IDR_ICO_SMALL			3

#define IDB_TOOLBAR		  	  100
#define IDB_TOOLBAR_GRAY	  101

#define DLG_ABOUT		 	 1001
#define IDR_MNU_MAIN	 	 2001
#define IDR_MDI			 	 2002

#define IDC_STATUS		 	 3000
#define IDC_TOOLBAR		 	 3001

#define IDM_FILE_OPEN		 6001
#define IDM_FILE_NEW		 6002
#define IDM_FILE_SAVE		 6003
#define IDM_FILE_PRINT		 6004
#define IDM_FILE_EXIT		 6005
#define IDM_EDIT_CUT		 6006
#define IDM_EDIT_COPY		 6007
#define IDM_EDIT_PASTE		 6008

#define IDM_CASCADE		 	 6009
#define IDM_TILE_HORZ	 	 6010
#define IDM_TILE_VERT	 	 6011
#define IDM_HELP_ABOUT		 6012

#define ID_DEFAULT_PANE		32849
#define ID_INDICATOR_POS	32850
#define ID_INDICATOR_CAPS	32851
#define ID_INDICATOR_NUM	32852
#define ID_INDICATOR_SCRL	32853

#define IDM_FIRSTCHILD		50000
#define IDM_LASTCHILD		50999

#define IDC_STATIC			-1
#define IDOK  1
